# APK STUDIO — Android SDK, JDK & Gradle Setup Guide

To compile native `.apk` binaries directly on your host machine (outside Docker), install the following components:

## 1. Install OpenJDK 17 (Full JDK with `javac`)

### Ubuntu / Debian
```bash
sudo apt-get update
sudo apt-get install -y openjdk-17-jdk
java -version
javac -version
```

### macOS (Homebrew)
```bash
brew install openjdk@17
```

## 2. Install Android Command Line Tools & SDK Platform 34

```bash
export ANDROID_HOME=/opt/android-sdk
sudo mkdir -p $ANDROID_HOME/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/cmdline-tools.zip
sudo unzip -q /tmp/cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
sudo mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest

yes | sudo $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
sudo $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0"
```

## 3. Install Gradle 8.5+

```bash
wget https://services.gradle.org/distributions/gradle-8.5-bin.zip -O /tmp/gradle.zip
sudo unzip -q /tmp/gradle.zip -d /opt
sudo ln -s /opt/gradle-8.5/bin/gradle /usr/local/bin/gradle
gradle -v
```

## 4. Verify Readiness

Run the included diagnostic script from the `APK-STUDIO` root:

```bash
npm run check:android
```

## 5. Optional Release Signing Configuration

By default, both `debug` and `release` builds fall back to standard Android debug signing so they can be installed immediately on test devices. To sign `release` APKs with your production keystore, configure the following variables in `.env`:

```ini
ANDROID_KEYSTORE_PATH=/path/to/release-key.jks
ANDROID_KEYSTORE_PASSWORD=your_store_password
ANDROID_KEY_ALIAS=your_key_alias
ANDROID_KEY_PASSWORD=your_key_password
```
