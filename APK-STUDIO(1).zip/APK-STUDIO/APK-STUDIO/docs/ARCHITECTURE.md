# APK STUDIO — System Architecture Overview

## 1. Layered Architecture

1. **Frontend (`frontend/`)**:
   - React + TypeScript application styled with the original **Liquid Glass UI** (`styles/index.css`).
   - Responsive CSS grid layouts supporting desktop workstations and mobile phone screens.
   - Communicates with the backend via `frontend/src/services/api.ts` and listens to `window.postMessage` events from the `/preview/:projectId` sandbox iframe to display real-time console logs and runtime errors.
2. **Backend (`backend/`)**:
   - REST API organized into `routes/`, `controllers/`, `services/`, `validators/`, `middleware/`, and `database/`.
   - Persists project metadata, customization settings, Animation Studio presets, and build history in SQLite (`data/apk_studio.sqlite`).
   - Isolates each project's source files under `data/projects/<projectId>/` and each build's generated Android Gradle project under `data/builds/<buildId>/`.
3. **Build Engine (`build-engine/`)**:
   - Contains the parameterized Android Gradle project template (`android-template/`), starter project scaffolds (`templates/`), environment diagnostics (`scripts/check-android-env.sh`), and binary APK verification (`services/apkVerifier.ts`).
4. **Python Support (`python-support/`)**:
   - `project_analyzer.py`: Parses all `.py` files using Python's `ast` module and inspects `requirements.txt` to classify projects into `supported`, `requires_modification`, or `unsupported`.
   - `webview_bridge_generator.py`: Generates an HTML5 WebView bridge (`index.html`) for Python projects.
