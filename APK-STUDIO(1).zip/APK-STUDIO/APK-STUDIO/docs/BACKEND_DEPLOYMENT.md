# APK STUDIO — Backend Deployment & Remote APK Generation Guide

## 1. Architectural Overview: Standalone Mode vs. Remote Build Backend

APK STUDIO is designed with a dual-mode architecture (`frontend/src/services/api.ts` and `frontend/src/services/localEngine.ts`):

1. **On-Device Standalone Mode (`file:///android_asset/webapp/index.html`)**:
   - When you install the compiled **APK STUDIO** Android app on your phone and open it without a connected backend server, it runs against its embedded **On-Device LocalEngine**.
   - You can create HTML5 and Python projects, import `.html` and `.zip` websites, edit multi-file source trees, run the Live Preview with console capture, customize icons/permissions/themes/animations, and export the configured **Android Studio Gradle Project (`.zip`)** directly to your phone's `Downloads` folder.
   - Because Android phones cannot execute the 15 GB desktop Android SDK, `aapt2`, and Gradle compiler locally inside a WebView, compiling user projects directly into binary `.apk` files from the app requires connecting the app to a deployed **APK STUDIO Build Backend**.

2. **Connected Build Backend Mode (`http://<host>:4000`)**:
   - When the app is served by or connected to the **APK STUDIO Backend** (running on a workstation, LAN host, or cloud Docker server with OpenJDK 17, Android SDK 34, and Gradle 8.5), clicking **Compile Android APK** executes the full 7-stage native Gradle build (`./gradlew assembleDebug` or `assembleRelease`) and streams the verified `.apk` back to your device.

---

## 2. Deploying the APK STUDIO Build Backend

### Option A: Docker / Docker Compose (Recommended for Cloud or Workstation)
The included `Dockerfile` and `docker-compose.yml` provision Ubuntu 22.04 with **OpenJDK 17**, **Android SDK Platform 34 (`platforms;android-34`)**, **Android Build-Tools 34.0.0 (`build-tools;34.0.0`)**, **Gradle 8.5**, **Python 3**, **SQLite 3**, and **Node.js 20**:

```bash
docker-compose up -d --build
```
The backend and web studio will listen on port `4000` (`http://<your-server-ip>:4000`).

### Option B: Cloud Container Hosting (Render / Railway / Fly.io / DigitalOcean / AWS)
1. Push the `APK-STUDIO` repository to GitHub.
2. Create a new **Web Service** (using the root `Dockerfile`) on a container host with at least **4 GB RAM** (recommended for Gradle JVM `-Xmx2048m`).
3. Set the following environment variables (matching `.env.example`):
   - `PORT=4000`
   - `NODE_ENV=production`
   - `DATA_DIR=/app/data`
   - `ANDROID_HOME=/opt/android-sdk`
   - `ANDROID_SDK_ROOT=/opt/android-sdk`
   - `JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64`
4. Mount a persistent volume at `/app/data` so your SQLite database (`apk_studio.sqlite`), project files, and compiled APK artifacts persist across restarts.

---

## 3. Connecting the Mobile App to Your Backend API URL

Once your backend is running (for example at `http://192.168.1.50:4000` on your local Wi-Fi network or `https://apk-studio-builder.example.com` in the cloud):

1. Open the **APK STUDIO** app on your Android phone.
2. Tap the **Engine Config** (`Settings`) button in the top navigation bar.
3. Enter your **Remote Build Server URL** without a trailing slash:
   - Local Wi-Fi example: `http://192.168.1.50:4000`
   - Cloud HTTPS example: `https://apk-studio-builder.example.com`
   *(Note: If you enter `http://192.168.1.50:4000`, the frontend automatically prefixes API requests with `http://192.168.1.50:4000/api`.)*
4. Tap **Save Configuration**.

### Required REST API Endpoints Used for APK Generation
When a Remote Build Server URL is configured, the frontend calls the following endpoints on that host:
- `GET /api/system/diagnostics` — Verifies that `java`, `javac`, `ANDROID_HOME` (`platforms;android-34`, `build-tools;34.0.0`), and `gradle` are ready on the build host.
- `GET /api/projects` & `POST /api/projects` — Lists and creates HTML5/Python projects on the build server.
- `PUT /api/projects/:id/customization` & `PUT /api/projects/:id/animations` — Synchronizes package ID, version, icons, permissions, splash screen, and CSS animations.
- `POST /api/projects/:projectId/builds` — Triggers asynchronous Gradle compilation (`{ "buildType": "debug" | "release" }`).
- `GET /api/builds/:buildId` — Polls real-time stage progress (`validating_project` $\rightarrow$ `preparing_template` $\rightarrow$ `applying_customization` $\rightarrow$ `bundling_assets` $\rightarrow$ `checking_toolchain` $\rightarrow$ `compiling_gradle` $\rightarrow$ `verifying_apk` $\rightarrow$ `completed`) and Gradle console output.
- `GET /api/builds/:buildId/download` — Downloads the binary-verified `.apk` file once `status === "success"`.
- `GET /api/builds/:buildId/export-project` — Downloads a `.zip` archive of the prepared Android Studio Gradle project.
