#!/usr/bin/env python3
"""
APK STUDIO — Python Project Analyzer & Android Packaging Classifier
Inspects a project directory and classifies Python projects into:
- 'supported': Ready to package into an Android WebView/hybrid runtime
- 'requires_modification': Can be packaged after specific adjustments (e.g. adding HTML bridge, replacing input(), or configuring Chaquopy wheels)
- 'unsupported': Uses desktop/OS-specific modules (tkinter, turtle, win32api, curses, etc.) or has syntax errors
"""
import sys
import os
import json
import ast

PROHIBITED_MODULES = {
    "tkinter": "Desktop Tk GUI cannot render inside an Android WebView.",
    "_tkinter": "Internal Tk C-extension is unavailable on Android.",
    "turtle": "Turtle graphics depends on a desktop X11/Tk window server.",
    "win32api": "Windows native Win32 APIs cannot execute on Linux/Android.",
    "win32con": "Windows native constants/APIs are incompatible with Android.",
    "winreg": "Windows Registry API is unavailable on Android.",
    "msvcrt": "Microsoft Visual C++ runtime console I/O is Windows-only.",
    "curses": "Terminal ncurses interfaces cannot render directly in Android WebView.",
    "pygame": "Pygame requires an SDL2 surface; use HTML5 Canvas or an SDL2 Android port.",
    "pyqt5": "Desktop Qt5 bindings are not supported in WebView hybrid containers.",
    "pyqt6": "Desktop Qt6 bindings are not supported in WebView hybrid containers.",
    "pyside2": "Desktop Qt bindings are not supported in WebView hybrid containers.",
    "pyside6": "Desktop Qt bindings are not supported in WebView hybrid containers.",
    "wx": "wxPython desktop GUI requires native desktop windowing.",
    "gtk": "GTK desktop bindings are not supported on Android."
}

NATIVE_WHEEL_PACKAGES = {
    "numpy": "Requires Chaquopy or Pyodide prebuilt native Android wheel.",
    "pandas": "Requires Chaquopy/Pyodide native wheel; increases APK size.",
    "scipy": "Heavy Fortran/C++ extensions; verify Chaquopy wheel availability.",
    "cv2": "OpenCV requires native Android .so libraries or OpenCV.js.",
    "opencv-python": "OpenCV requires native Android .so libraries or OpenCV.js.",
    "PIL": "Pillow requires native image codecs (supported via Chaquopy/Pyodide).",
    "pillow": "Pillow requires native image codecs (supported via Chaquopy/Pyodide).",
    "cryptography": "Requires Rust/OpenSSL prebuilt Android binaries.",
    "torch": "PyTorch Mobile / ExecuTorch required instead of desktop torch.",
    "tensorflow": "TensorFlow Lite required on Android instead of full tensorflow."
}

WEB_FRAMEWORKS = {
    "flask": "Local WSGI web framework detected; runs via local loopback server or Chaquopy.",
    "fastapi": "ASGI web framework detected; requires uvicorn loopback server on Android.",
    "django": "Full Django stack detected; ensure SQLite storage is pointed to app data dir.",
    "bottle": "Lightweight WSGI server; compatible with local loopback WebView."
}


def inspect_python_project(directory: str) -> dict:
    if not os.path.exists(directory) or not os.path.isdir(directory):
        return {
            "supported": False,
            "classification": "unsupported",
            "entrypoint": None,
            "has_html_bridge": False,
            "python_files": [],
            "detected_imports": [],
            "declared_dependencies": [],
            "native_or_heavy_dependencies": [],
            "modification_reasons": [],
            "unsupported_modules": [],
            "recommendations": ["Provide a valid project directory."],
            "error": "Target project directory does not exist."
        }

    entrypoints = ["main.py", "app.py", "index.py", "server.py"]
    detected_entry = None
    for entry in entrypoints:
        if os.path.exists(os.path.join(directory, entry)):
            detected_entry = entry
            break

    python_files = []
    for root, _, files in os.walk(directory):
        for f in files:
            if f.endswith(".py") and not f.startswith("."):
                rel = os.path.relpath(os.path.join(root, f), directory).replace("\\", "/")
                python_files.append(rel)

    python_files.sort()
    has_html_bridge = os.path.exists(os.path.join(directory, "index.html"))

    if not detected_entry:
        return {
            "supported": False,
            "classification": "unsupported",
            "entrypoint": None,
            "has_html_bridge": has_html_bridge,
            "python_files": python_files,
            "detected_imports": [],
            "declared_dependencies": [],
            "native_or_heavy_dependencies": [],
            "modification_reasons": [],
            "unsupported_modules": [],
            "recommendations": [
                "Create or rename your primary Python file to main.py or app.py."
            ],
            "error": "Missing main entrypoint. Provide main.py, app.py, index.py, or server.py."
        }

    imports = set()
    uses_blocking_input = False
    unsupported = []

    files_to_scan = python_files if python_files else [detected_entry]

    for rel_file in files_to_scan:
        full_path = os.path.join(directory, rel_file)
        try:
            with open(full_path, "r", encoding="utf-8") as f:
                source = f.read()
            tree = ast.parse(source, filename=rel_file)
        except Exception as e:
            return {
                "supported": False,
                "classification": "unsupported",
                "entrypoint": detected_entry,
                "has_html_bridge": has_html_bridge,
                "python_files": python_files,
                "detected_imports": sorted(list(imports)),
                "declared_dependencies": [],
                "native_or_heavy_dependencies": [],
                "modification_reasons": [],
                "unsupported_modules": [],
                "recommendations": [f"Fix the Python syntax error in {rel_file} before packaging."],
                "error": f"Syntax error in {rel_file}: {str(e)}"
            }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for n in node.names:
                    root_mod = n.name.split(".")[0]
                    imports.add(root_mod)
                    lower_mod = root_mod.lower()
                    if lower_mod in PROHIBITED_MODULES:
                        unsupported.append({
                            "module": root_mod,
                            "reason": PROHIBITED_MODULES[lower_mod],
                            "file": rel_file
                        })
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_mod = node.module.split(".")[0]
                    imports.add(root_mod)
                    lower_mod = root_mod.lower()
                    if lower_mod in PROHIBITED_MODULES:
                        unsupported.append({
                            "module": root_mod,
                            "reason": PROHIBITED_MODULES[lower_mod],
                            "file": rel_file
                        })
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id == "input":
                    uses_blocking_input = True

    # Inspect requirements.txt if present
    req_file = os.path.join(directory, "requirements.txt")
    dependencies = []
    if os.path.exists(req_file):
        with open(req_file, "r", encoding="utf-8") as rf:
            for line in rf:
                cleaned = line.strip()
                if cleaned and not cleaned.startswith("#"):
                    dependencies.append(cleaned)

    # Deduplicate unsupported modules
    seen_unsupported = set()
    unique_unsupported = []
    for item in unsupported:
        if item["module"] not in seen_unsupported:
            seen_unsupported.add(item["module"])
            unique_unsupported.append(item)

    if unique_unsupported:
        return {
            "supported": False,
            "classification": "unsupported",
            "entrypoint": detected_entry,
            "has_html_bridge": has_html_bridge,
            "python_files": python_files,
            "detected_imports": sorted(list(imports)),
            "declared_dependencies": dependencies,
            "native_or_heavy_dependencies": [],
            "modification_reasons": [],
            "unsupported_modules": unique_unsupported,
            "recommendations": [
                f"Replace {u['module']} ({u['reason']})" for u in unique_unsupported
            ],
            "error": "Incompatible desktop/native modules detected."
        }

    # Check for native/heavy dependencies or missing HTML bridge or blocking input()
    native_deps = []
    for imp in sorted(list(imports)):
        if imp in NATIVE_WHEEL_PACKAGES:
            native_deps.append({"package": imp, "note": NATIVE_WHEEL_PACKAGES[imp]})

    for dep in dependencies:
        pkg_name = dep.split("==")[0].split(">=")[0].split("<=")[0].split("~=")[0].strip().lower()
        if pkg_name in NATIVE_WHEEL_PACKAGES and not any(d["package"].lower() == pkg_name for d in native_deps):
            native_deps.append({"package": pkg_name, "note": NATIVE_WHEEL_PACKAGES[pkg_name]})

    modification_reasons = []
    recommendations = []

    if not has_html_bridge:
        modification_reasons.append(
            "Missing index.html WebView UI bridge. Android WebView requires an HTML entrypoint to display output and interact with Python."
        )
        recommendations.append(
            "Use 'Generate HTML Bridge' in the editor to create an index.html wrapper for your Python script."
        )

    if uses_blocking_input:
        modification_reasons.append(
            "Uses blocking standard input `input()`, which hangs in non-interactive WebView environments."
        )
        recommendations.append(
            "Replace `input()` calls with HTML form inputs or parameters passed through the JavaScript-Python bridge."
        )

    if native_deps:
        modification_reasons.append(
            f"Uses native/C-extension packages ({', '.join(d['package'] for d in native_deps)}) that require Chaquopy or Pyodide wheel support."
        )
        recommendations.append(
            "Verify prebuilt Android ABI wheels exist for all native packages in requirements.txt."
        )

    for imp in sorted(list(imports)):
        if imp.lower() in WEB_FRAMEWORKS:
            recommendations.append(WEB_FRAMEWORKS[imp.lower()])

    if modification_reasons:
        return {
            "supported": True,
            "classification": "requires_modification",
            "entrypoint": detected_entry,
            "has_html_bridge": has_html_bridge,
            "python_files": python_files,
            "detected_imports": sorted(list(imports)),
            "declared_dependencies": dependencies,
            "native_or_heavy_dependencies": native_deps,
            "modification_reasons": modification_reasons,
            "unsupported_modules": [],
            "recommendations": recommendations
        }

    if not recommendations:
        recommendations.append("Project is clean and ready for hybrid Android WebView packaging.")

    return {
        "supported": True,
        "classification": "supported",
        "entrypoint": detected_entry,
        "has_html_bridge": has_html_bridge,
        "python_files": python_files,
        "detected_imports": sorted(list(imports)),
        "declared_dependencies": dependencies,
        "native_or_heavy_dependencies": native_deps,
        "modification_reasons": [],
        "unsupported_modules": [],
        "recommendations": recommendations
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Directory path required"}))
        sys.exit(1)
    target_dir = sys.argv[1]
    res = inspect_python_project(target_dir)
    print(json.dumps(res, indent=2))
