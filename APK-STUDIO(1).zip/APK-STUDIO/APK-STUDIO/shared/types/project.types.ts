export type ProjectType = 'html' | 'python';

export interface Project {
  id: string;
  name: string;
  type: ProjectType;
  status?: 'draft' | 'ready' | 'built' | 'error';
  created_at: string;
  updated_at: string;
  app_name?: string;
  package_id?: string;
  version_name?: string;
  version_code?: number;
  last_build_status?: BuildStatus | null;
}

export interface CustomizationSettings {
  app_name: string;
  package_id: string;
  version_name: string;
  version_code: number;
  orientation: 'portrait' | 'landscape' | 'unspecified';
  fullscreen: boolean;
  status_bar_color: string;
  nav_bar_color: string;
  light_status_bar: boolean;
  theme_color: string;
  background_color: string;
  offline_mode: 'cache_first' | 'network_first' | 'offline_only';
  allow_cleartext: boolean;
  enable_zoom: boolean;
  keep_screen_on: boolean;
  splash_enabled: boolean;
  splash_color: string;
  splash_duration_ms: number;
  splash_animation: 'fade' | 'scale' | 'slide' | 'pulse' | 'none';
  icon_data_url?: string | null;
  splash_image_data_url?: string | null;
  permissions: string[];
}

export interface AnimationConfig {
  project_id?: string;
  splash_animation: 'fade' | 'scale' | 'slide' | 'pulse' | 'none';
  splash_duration_ms: number;
  pulse_duration_s: number;
  glass_blur_px: number;
  page_transition: 'fade' | 'slide-up' | 'zoom' | 'none';
  loader_style: 'spinner' | 'pulse-ring' | 'progress-bar' | 'dots' | 'none';
  button_effect: 'scale-press' | 'glow-hover' | 'ripple' | 'none';
  inject_stylesheet: boolean;
}

export interface FileTreeNode {
  name: string;
  path: string;
  isDirectory: boolean;
  size?: number;
  isBinary?: boolean;
  children?: FileTreeNode[];
}

export type BuildStatus = 'queued' | 'building' | 'success' | 'failed';

export type BuildStage =
  | 'queued'
  | 'validating_project'
  | 'preparing_template'
  | 'applying_customization'
  | 'bundling_assets'
  | 'checking_toolchain'
  | 'compiling_gradle'
  | 'verifying_apk'
  | 'completed'
  | 'failed';

export interface BuildRecord {
  id: string;
  project_id: string;
  build_type: 'debug' | 'release';
  status: BuildStatus;
  stage: BuildStage;
  progress: number;
  started_at: string;
  completed_at?: string | null;
  log: string;
  apk_filename?: string | null;
  apk_size_bytes?: number | null;
  error_summary?: string | null;
}

export type PythonSupportTier = 'supported' | 'requires_modification' | 'unsupported';

export interface PythonInspectionResult {
  supported: boolean;
  classification: PythonSupportTier;
  entrypoint?: string | null;
  has_html_bridge: boolean;
  python_files: string[];
  detected_imports: string[];
  declared_dependencies: string[];
  native_or_heavy_dependencies: Array<{ package: string; note: string }>;
  modification_reasons: string[];
  unsupported_modules: Array<{ module: string; reason: string; file?: string }>;
  recommendations: string[];
  error?: string;
}

export interface ToolchainDiagnostics {
  readyForNativeBuild: boolean;
  javaAvailable: boolean;
  javaVersion: string | null;
  javacAvailable: boolean;
  javacVersion: string | null;
  androidSdkAvailable: boolean;
  androidHomePath: string;
  platform34Installed: boolean;
  buildToolsInstalled: boolean;
  gradleAvailable: boolean;
  gradleVersion: string | null;
  missingComponents: string[];
  setupInstructions: string[];
}
