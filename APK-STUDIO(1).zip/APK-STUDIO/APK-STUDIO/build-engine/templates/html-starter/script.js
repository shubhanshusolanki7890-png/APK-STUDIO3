document.addEventListener("DOMContentLoaded", () => {
  console.log("[APK STUDIO] Hybrid Web App initialized.");
  const btn = document.getElementById("action-btn");
  const statusBox = document.getElementById("status-box");
  let clicks = 0;

  if (btn && statusBox) {
    btn.addEventListener("click", () => {
      clicks += 1;
      const msg = `Interaction #${clicks} recorded at ${new Date().toLocaleTimeString()}`;
      statusBox.textContent = msg;
      console.log(msg);
      if (window.AndroidStudioBridge && typeof window.AndroidStudioBridge.showToast === "function") {
        window.AndroidStudioBridge.showToast(msg);
      }
    });
  }
});
