#!/usr/bin/env bash
set -e

echo "========================================================"
echo " APK STUDIO — Android Build Toolchain Diagnostic Check"
echo "========================================================"

MISSING=0

if command -v java >/dev/null 2>&1; then
  echo "[OK] java runtime: $(java -version 2>&1 | head -n 1)"
else
  echo "[MISSING] java runtime not found in PATH."
  MISSING=$((MISSING + 1))
fi

if command -v javac >/dev/null 2>&1; then
  echo "[OK] javac compiler: $(javac -version 2>&1 | head -n 1)"
else
  echo "[MISSING] javac compiler (JDK 17+) not found in PATH."
  MISSING=$((MISSING + 1))
fi

SDK_PATH="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/opt/android-sdk}}"
if [ -d "$SDK_PATH" ]; then
  echo "[OK] ANDROID_HOME directory exists: $SDK_PATH"
else
  echo "[MISSING] ANDROID_HOME directory not found at: $SDK_PATH"
  MISSING=$((MISSING + 1))
fi

if [ -d "$SDK_PATH/platforms/android-34" ]; then
  echo "[OK] Android SDK Platform 34 installed."
else
  echo "[MISSING] Android SDK Platform 34 ($SDK_PATH/platforms/android-34)."
  MISSING=$((MISSING + 1))
fi

if command -v gradle >/dev/null 2>&1; then
  echo "[OK] gradle binary: $(gradle -v | grep 'Gradle ' || true)"
else
  echo "[MISSING] gradle binary not found in PATH."
  MISSING=$((MISSING + 1))
fi

echo "--------------------------------------------------------"
if [ "$MISSING" -eq 0 ]; then
  echo "Toolchain status: READY for native Android APK compilation."
  exit 0
else
  echo "Toolchain status: INCOMPLETE ($MISSING component(s) missing)."
  echo "See docs/ANDROID_BUILD_SETUP.md or run via Docker (docker-compose up --build)."
  exit 1
fi
