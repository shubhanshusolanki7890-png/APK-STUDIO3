/* APK STUDIO — Production Browser & Android WebView Bundle */
(function() {
  "use strict";

  var componentStates = {};
  var activeCompKey = "root";
  var activeHookIdx = 0;
  var visitedCompKeys = {};
  var rootComponent = null;
  var rootContainer = null;
  var pendingEffects = [];
  var renderScheduled = false;

  function scheduleRender() {
    if (renderScheduled) return;
    renderScheduled = true;
    Promise.resolve().then(performRender);
  }

  function performRender() {
    renderScheduled = false;
    if (!rootComponent || !rootContainer) return;

    var activeEl = document.activeElement;
    var focusFocusKey = activeEl && activeEl.getAttribute ? activeEl.getAttribute("data-focus-key") : null;
    var selStart = activeEl && typeof activeEl.selectionStart === "number" ? activeEl.selectionStart : null;
    var selEnd = activeEl && typeof activeEl.selectionEnd === "number" ? activeEl.selectionEnd : null;

    visitedCompKeys = {};
    pendingEffects = [];
    var domTree = renderVNode(createElement(rootComponent, null), "root", { count: 0 });
    rootContainer.innerHTML = "";
    rootContainer.appendChild(domTree);

    Object.keys(componentStates).forEach(function(k) {
      if (!visitedCompKeys[k]) {
        var st = componentStates[k];
        if (st && st.cleanups) {
          st.cleanups.forEach(function(fn) { if (typeof fn === "function") { try { fn(); } catch(e) {} } });
        }
        delete componentStates[k];
      }
    });

    if (focusFocusKey) {
      var restored = rootContainer.querySelector('[data-focus-key="' + focusFocusKey + '"]');
      if (restored && typeof restored.focus === "function") {
        restored.focus();
        if (selStart !== null && typeof restored.setSelectionRange === "function") {
          try { restored.setSelectionRange(selStart, selEnd); } catch (e) {}
        }
      }
    }

    var effectsToRun = pendingEffects.slice();
    pendingEffects = [];
    effectsToRun.forEach(function(ef) { ef(); });
  }

  function createElement(type, props) {
    var children = [];
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (Array.isArray(c)) {
        for (var j = 0; j < c.length; j++) children.push(c[j]);
      } else {
        children.push(c);
      }
    }
    return {
      type: type,
      props: Object.assign({}, props || {}, {
        children: children.length === 0 ? undefined : (children.length === 1 ? children[0] : children)
      })
    };
  }

  function Fragment(props) { return props.children; }
  function StrictMode(props) { return props.children; }

  function getCompRecord(key) {
    if (!componentStates[key]) {
      componentStates[key] = { hooks: [], deps: [], cleanups: [] };
    }
    return componentStates[key];
  }

  function useState(initialVal) {
    var compKey = activeCompKey;
    var idx = activeHookIdx++;
    var rec = getCompRecord(compKey);
    if (rec.hooks[idx] === undefined) {
      rec.hooks[idx] = typeof initialVal === "function" ? initialVal() : initialVal;
    }
    var setState = function(nextVal) {
      var currentRec = getCompRecord(compKey);
      var resolved = typeof nextVal === "function" ? nextVal(currentRec.hooks[idx]) : nextVal;
      if (resolved !== currentRec.hooks[idx]) {
        currentRec.hooks[idx] = resolved;
        scheduleRender();
      }
    };
    return [rec.hooks[idx], setState];
  }

  function useEffect(cb, deps) {
    var compKey = activeCompKey;
    var idx = activeHookIdx++;
    var rec = getCompRecord(compKey);
    var prevDeps = rec.deps[idx];
    var changed = true;
    if (prevDeps !== undefined && Array.isArray(deps)) {
      changed = deps.length !== prevDeps.length || deps.some(function(d, i) { return d !== prevDeps[i]; });
    }
    if (changed) {
      rec.deps[idx] = deps;
      pendingEffects.push(function() {
        if (typeof rec.cleanups[idx] === "function") {
          try { rec.cleanups[idx](); } catch (e) {}
        }
        try {
          var cleanup = cb();
          rec.cleanups[idx] = typeof cleanup === "function" ? cleanup : null;
        } catch (e) {
          console.error(e);
        }
      });
    }
  }

  function renderVNode(vnode, pathPrefix, inputCounter) {
    if (vnode === null || vnode === undefined || typeof vnode === "boolean") {
      return document.createTextNode("");
    }
    if (typeof vnode === "string" || typeof vnode === "number") {
      return document.createTextNode(String(vnode));
    }
    if (Array.isArray(vnode)) {
      var frag = document.createDocumentFragment();
      vnode.forEach(function(child, idx) {
        frag.appendChild(renderVNode(child, pathPrefix + "." + idx, inputCounter));
      });
      return frag;
    }
    if (typeof vnode.type === "function") {
      var fnName = vnode.type.displayName || vnode.type.name || "Anon";
      var explicitKey = vnode.props && vnode.props.key != null ? String(vnode.props.key) : "";
      var compKey = pathPrefix + "/" + fnName + (explicitKey ? "#" + explicitKey : "");
      visitedCompKeys[compKey] = true;
      var prevKey = activeCompKey;
      var prevIdx = activeHookIdx;
      activeCompKey = compKey;
      activeHookIdx = 0;
      var rendered = vnode.type(vnode.props || {});
      activeCompKey = prevKey;
      activeHookIdx = prevIdx;
      return renderVNode(rendered, compKey, inputCounter);
    }

    var tag = String(vnode.type || "div");
    var isSvg = ["svg", "path", "circle", "rect", "line", "polyline", "polygon", "g"].indexOf(tag) !== -1;
    var el = isSvg
      ? document.createElementNS("http://www.w3.org/2000/svg", tag)
      : document.createElement(tag);

    if (tag === "input" || tag === "textarea" || tag === "select") {
      inputCounter.count += 1;
      el.setAttribute("data-focus-key", pathPrefix + ":input:" + inputCounter.count);
    }

    var props = vnode.props || {};
    Object.keys(props).forEach(function(k) {
      if (k === "children" || k === "key") return;
      var val = props[k];
      if (k === "className") {
        if (isSvg) el.setAttribute("class", val || "");
        else el.className = val || "";
      } else if (k === "style" && val && typeof val === "object") {
        Object.keys(val).forEach(function(sk) {
          var sv = val[sk];
          if (typeof sv === "number" && ["width","height","minWidth","minHeight","maxWidth","maxHeight","padding","paddingLeft","paddingRight","paddingTop","paddingBottom","margin","marginTop","marginBottom","marginLeft","marginRight","borderRadius","fontSize","gap","top","left","right","bottom"].indexOf(sk) !== -1) {
            el.style[sk] = sv + "px";
          } else {
            el.style[sk] = sv;
          }
        });
      } else if (k.indexOf("on") === 0 && typeof val === "function") {
        var evt = k.slice(2).toLowerCase();
        if (evt === "change" && (tag === "input" || tag === "textarea")) {
          var inputType = props.type || "text";
          if (inputType === "file" || inputType === "checkbox" || inputType === "radio" || inputType === "color" || inputType === "range") {
            el.addEventListener("change", val);
          } else {
            el.addEventListener("input", val);
          }
        } else {
          el.addEventListener(evt, val);
        }
      } else if (k === "checked" || k === "disabled" || k === "value" || k === "autoFocus" || k === "spellCheck") {
        el[k] = val;
      } else if (k === "srcDoc") {
        el.srcdoc = val;
      } else if (val !== undefined && val !== null && val !== false) {
        el.setAttribute(k, String(val));
      }
    });

    var ch = props.children;
    if (Array.isArray(ch)) {
      ch.forEach(function(c, i) { el.appendChild(renderVNode(c, pathPrefix + "." + i, inputCounter)); });
    } else if (ch !== undefined && ch !== null) {
      el.appendChild(renderVNode(ch, pathPrefix + ".0", inputCounter));
    }

    if (tag === "select" && props.value !== undefined) {
      el.value = String(props.value);
    }
    return el;
  }

  var ReactShim = {
    createElement: createElement,
    Fragment: Fragment,
    StrictMode: StrictMode,
    useState: useState,
    useEffect: useEffect,
    default: null
  };
  ReactShim.default = ReactShim;

  var ReactDOMClientShim = {
    createRoot: function(container) {
      return {
        render: function(element) {
          rootContainer = container;
          rootComponent = function RootWrapper() { return element; };
          performRender();
        }
      };
    }
  };
  ReactDOMClientShim.default = ReactDOMClientShim;

  function makeIcon(pathData) {
    return function IconComponent(props) {
      var size = (props && props.size) || 16;
      var color = (props && props.color) || "currentColor";
      return createElement("svg", {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: color,
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
      }, createElement("path", { d: pathData }));
    };
  }

  var LucideShim = {
    Layers: makeIcon("M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"),
    Settings: makeIcon("M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"),
    Play: makeIcon("M5 3l14 9-14 9V3z"),
    Sliders: makeIcon("M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"),
    Box: makeIcon("M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"),
    Code: makeIcon("M16 18l6-6-6-6M8 6l-6 6 6 6"),
    Plus: makeIcon("M12 5v14M5 12h14"),
    Trash2: makeIcon("M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"),
    FolderOpen: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Folder: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Terminal: makeIcon("M4 17l6-6-6-6M12 19h8"),
    Edit3: makeIcon("M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"),
    Copy: makeIcon("M9 9h13v13H9zM5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"),
    Save: makeIcon("M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"),
    UploadCloud: makeIcon("M16 16l-4-4-4 4M12 12v9M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"),
    RefreshCw: makeIcon("M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"),
    Smartphone: makeIcon("M5 2h14a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zM12 18h.01"),
    FileCode: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"),
    Image: makeIcon("M3 3h18v18H3zM8.5 8.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM21 15l-5-5L5 21"),
    RotateCcw: makeIcon("M1 4v6h6M3.51 15a9 9 0 1 0 2.13-9.36L1 10"),
    Info: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01"),
    Cpu: makeIcon("M4 4h16v16H4zM9 9h6v6H9z"),
    Wand2: makeIcon("M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M3 21l9-9"),
    FilePlus: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM12 18v-6M9 15h6"),
    FileUp: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM12 12v6M9 15l3-3 3 3"),
    Upload: makeIcon("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"),
    CheckCircle2: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9 12l2 2 4-4"),
    AlertTriangle: makeIcon("M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01"),
    Sparkles: makeIcon("M12 3l1.9 5.8a2 2 0 0 0 1.3 1.3L21 12l-5.8 1.9a2 2 0 0 0-1.3 1.3L12 21l-1.9-5.8a2 2 0 0 0-1.3-1.3L3 12l5.8-1.9a2 2 0 0 0 1.3-1.3L12 3z"),
    Download: makeIcon("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"),
    AlertCircle: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 8v4M12 16h.01"),
    CheckCircle: makeIcon("M22 11.08V12a10 10 0 1 1-5.93-9.14M22 4L12 14.01l-3-3"),
    FolderArchive: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Wrench: makeIcon("M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z")
  };

  var modules = {
"./app/App": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.App = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../services/api");
var _MainLayout = require("../layouts/MainLayout");
var _Dashboard = require("../pages/Dashboard");
var _ProjectEditor = require("../pages/ProjectEditor");
var _CustomizationStudio = require("../pages/CustomizationStudio");
var _AnimationStudio = require("../pages/AnimationStudio");
var _BuildStudio = require("../pages/BuildStudio");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}

const App = () => {
  const [projects, setProjects] = (0, _react.useState)([]);
  const [selectedProject, setSelectedProject] = (0, _react.useState)(null);
  const [customization, setCustomization] = (0, _react.useState)(null);
  const [animations, setAnimations] = (0, _react.useState)(null);
  const [activeTab, setActiveTab] = (0, _react.useState)('dashboard');
  const [errorBanner, setErrorBanner] = (0, _react.useState)(null);

  const refreshProjects = async () => {
    try {
      const list = await _api.API.listProjects();
      setProjects(list);
      setErrorBanner(null);
    } catch (err) {
      setErrorBanner(err.message || 'Unable to load workspace projects.');
    }
  };

  (0, _react.useEffect)(() => {
    refreshProjects();
  }, []);

  const handleSelectProject = async (p) => {
    try {
      const data = await _api.API.getProject(p.id);
      setSelectedProject(data.project);
      setCustomization(data.customization);
      setAnimations(data.animations);
      setActiveTab('editor');
    } catch (err) {
      setErrorBanner(err.message);
    }
  };

  const handleCreateProject = async (name, type) => {
    try {
      const created = await _api.API.createProject(name, type);
      await refreshProjects();
      await handleSelectProject(created);
    } catch (err) {
      setErrorBanner(err.message);
    }
  };

  const handleRenameProject = async (id, newName) => {
    try {
      const updated = await _api.API.renameProject(id, newName);
      if (selectedProject?.id === id) {
        setSelectedProject(updated);
      }
      await refreshProjects();
    } catch (err) {
      setErrorBanner(err.message);
    }
  };

  const handleDuplicateProject = async (id) => {
    try {
      await _api.API.duplicateProject(id);
      await refreshProjects();
    } catch (err) {
      setErrorBanner(err.message);
    }
  };

  const handleDeleteProject = async (id) => {
    try {
      await _api.API.deleteProject(id);
      if (selectedProject?.id === id) {
        setSelectedProject(null);
        setCustomization(null);
        setAnimations(null);
        setActiveTab('dashboard');
      }
      await refreshProjects();
    } catch (err) {
      setErrorBanner(err.message);
    }
  };

  return /*#__PURE__*/(
    _react.default.createElement(_MainLayout.MainLayout, {
      activeTab: activeTab,
      setActiveTab: setActiveTab,
      selectedProjectName: selectedProject?.name },

    activeTab === 'dashboard' && /*#__PURE__*/
    _react.default.createElement(_Dashboard.Dashboard, {
      projects: projects,
      errorBanner: errorBanner,
      onSelectProject: handleSelectProject,
      onCreateProject: handleCreateProject,
      onRenameProject: handleRenameProject,
      onDuplicateProject: handleDuplicateProject,
      onDeleteProject: handleDeleteProject }),


    activeTab === 'editor' && selectedProject && /*#__PURE__*/
    _react.default.createElement(_ProjectEditor.ProjectEditor, { project: selectedProject }),

    activeTab === 'customization' && selectedProject && customization && /*#__PURE__*/
    _react.default.createElement(_CustomizationStudio.CustomizationStudio, {
      projectId: selectedProject.id,
      initialSettings: customization,
      onUpdated: (updated) => {
        setCustomization(updated);
        refreshProjects();
      } }),


    activeTab === 'animations' && selectedProject && animations && /*#__PURE__*/
    _react.default.createElement(_AnimationStudio.AnimationStudio, {
      projectId: selectedProject.id,
      initialAnimations: animations,
      onUpdated: (updated) => setAnimations(updated) }),


    activeTab === 'build' && selectedProject && /*#__PURE__*/
    _react.default.createElement(_BuildStudio.BuildStudio, { projectId: selectedProject.id })));



};exports.App = App;
},
"./components/GlassButton": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.GlassButton = void 0;var _react = _interopRequireDefault(require("react"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}function _extends() {_extends = Object.assign ? Object.assign.bind() : function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}





const GlassButton = ({ children, className = '', ...props }) => {
  return /*#__PURE__*/(
    _react.default.createElement("button", _extends({ className: `liquid-glass-btn ${className}` }, props),
    children));


};exports.GlassButton = GlassButton;
},
"./components/GlassModal": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.GlassModal = void 0;var _react = _interopRequireDefault(require("react"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}








const GlassModal = ({ isOpen, title, onClose, children }) => {
  if (!isOpen) return null;

  return /*#__PURE__*/(
    _react.default.createElement("div", {
      onClick: onClose,
      style: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.65)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 100,
        padding: 16
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      className: "window-container",
      onClick: (e) => e.stopPropagation(),
      style: { textAlign: 'left' } }, /*#__PURE__*/

    _react.default.createElement("h2", { style: { fontSize: 21, marginBottom: 16, fontWeight: 700, textAlign: 'center' } },
    title),

    children)));



};exports.GlassModal = GlassModal;
},
"./components/StatusBadge": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.StatusBadge = void 0;var _react = _interopRequireDefault(require("react"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}






const StatusBadge = ({ status, label }) => {
  const normalized = (status || 'ready').toLowerCase();
  let bg = 'rgba(255, 255, 255, 0.12)';
  let color = '#ffffff';
  let border = 'rgba(255, 255, 255, 0.25)';

  if (['success', 'built', 'supported', 'ready'].includes(normalized)) {
    bg = 'rgba(0, 255, 200, 0.15)';
    color = '#00ffc8';
    border = 'rgba(0, 255, 200, 0.35)';
  } else if (['building', 'queued', 'requires_modification', 'warn'].includes(normalized)) {
    bg = 'rgba(254, 202, 87, 0.16)';
    color = '#feca57';
    border = 'rgba(254, 202, 87, 0.38)';
  } else if (['failed', 'error', 'unsupported'].includes(normalized)) {
    bg = 'rgba(255, 107, 107, 0.18)';
    color = '#ff6b6b';
    border = 'rgba(255, 107, 107, 0.4)';
  }

  return /*#__PURE__*/(
    _react.default.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        fontSize: 11,
        fontWeight: 600,
        textTransform: 'uppercase',
        letterSpacing: '0.4px',
        padding: '3px 9px',
        borderRadius: 999,
        background: bg,
        color,
        border: `1px solid ${border}`
      } },

    label || status));


};exports.StatusBadge = StatusBadge;
},
"./features/editor/FileTreeView": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.FileTreeView = void 0;var _react = _interopRequireWildcard(require("react"));

var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}









const FileTreeView = ({
  nodes,
  activeFile,
  onSelectFile,
  onDeleteFile,
  depth = 0
}) => {
  const [collapsedDirs, setCollapsedDirs] = (0, _react.useState)({});

  const toggleDir = (dirPath) => {
    setCollapsedDirs((prev) => ({ ...prev, [dirPath]: !prev[dirPath] }));
  };

  return /*#__PURE__*/(
    _react.default.createElement("div", { style: { display: 'flex', flexDirection: 'column', gap: 2 } },
    nodes.map((node) => {
      const isCollapsed = Boolean(collapsedDirs[node.path]);
      const isSelected = !node.isDirectory && activeFile === node.path;

      return /*#__PURE__*/(
        _react.default.createElement("div", { key: node.path }, /*#__PURE__*/
        _react.default.createElement("div", {
          onClick: () =>
          node.isDirectory ? toggleDir(node.path) : onSelectFile(node.path),

          style: {
            padding: '6px 8px',
            paddingLeft: 8 + depth * 14,
            fontSize: 13,
            borderRadius: 8,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 6,
            background: isSelected ? 'rgba(255, 255, 255, 0.16)' : 'transparent',
            color: node.isDirectory ? 'rgba(255, 255, 255, 0.85)' : '#fff'
          } }, /*#__PURE__*/

        _react.default.createElement("div", {
          style: {
            display: 'flex',
            alignItems: 'center',
            gap: 7,
            minWidth: 0,
            flex: 1
          } },

        node.isDirectory ?
        isCollapsed ? /*#__PURE__*/
        _react.default.createElement(_lucideReact.Folder, { size: 14, color: "#feca57" }) : /*#__PURE__*/

        _react.default.createElement(_lucideReact.FolderOpen, { size: 14, color: "#feca57" }) :

        node.isBinary ? /*#__PURE__*/
        _react.default.createElement(_lucideReact.Image, { size: 14, color: "#54a0ff" }) : /*#__PURE__*/

        _react.default.createElement(_lucideReact.FileCode, { size: 14, color: "#00ffc8" }), /*#__PURE__*/

        _react.default.createElement("span", { className: "truncate-text", title: node.path },
        node.name)),



        !node.isDirectory && node.path !== 'index.html' && /*#__PURE__*/
        _react.default.createElement("button", {
          type: "button",
          title: `Delete ${node.path}`,
          onClick: (e) => {
            e.stopPropagation();
            onDeleteFile(node.path);
          },
          style: {
            background: 'transparent',
            border: 'none',
            color: 'rgba(255,255,255,0.35)',
            cursor: 'pointer',
            padding: 2,
            display: 'flex',
            alignItems: 'center'
          } }, /*#__PURE__*/

        _react.default.createElement(_lucideReact.Trash2, { size: 12 }))),




        node.isDirectory && !isCollapsed && node.children && node.children.length > 0 && /*#__PURE__*/
        _react.default.createElement(FileTreeView, {
          nodes: node.children,
          activeFile: activeFile,
          onSelectFile: onSelectFile,
          onDeleteFile: onDeleteFile,
          depth: depth + 1 })));




    })));


};exports.FileTreeView = FileTreeView;
},
"./features/editor/LivePreviewPane": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.LivePreviewPane = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../../services/api");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}







const SCREEN_PRESETS = [
{ id: 'compact', label: 'Compact (320×560)', width: 320, height: 560 },
{ id: 'pixel', label: 'Android (360×640)', width: 360, height: 640 },
{ id: 'tablet', label: 'Tablet (520×680)', width: 520, height: 680 }];


const LivePreviewPane = ({ projectId, previewKey, onRefresh }) => {
  const [presetId, setPresetId] = (0, _react.useState)('compact');
  const [isLandscape, setIsLandscape] = (0, _react.useState)(false);
  const [consoleLogs, setConsoleLogs] = (0, _react.useState)([]);
  const [showConsole, setShowConsole] = (0, _react.useState)(true);
  const [showLimitations, setShowLimitations] = (0, _react.useState)(false);

  const activePreset = SCREEN_PRESETS.find((p) => p.id === presetId) || SCREEN_PRESETS[0];
  const frameWidth = isLandscape ? Math.min(activePreset.height, 520) : activePreset.width;
  const frameHeight = isLandscape ? activePreset.width : activePreset.height;

  const isStandalone = _api.API.isStandaloneWebViewMode();
  const remoteBase = _api.API.getRemoteBackendUrl();
  const previewSrcUrl = remoteBase ?
  `${remoteBase}/preview/${projectId}/index.html?t=${previewKey}` :
  `/preview/${projectId}/index.html?t=${previewKey}`;
  const inlineSrcDoc = isStandalone ? _api.API.compileLivePreviewSrcDoc(projectId) : undefined;

  (0, _react.useEffect)(() => {
    const handleMessage = (event) => {
      if (event.data && event.data.source === 'apk-studio-preview') {
        const entry = {
          id: `${Date.now()}-${Math.random()}`,
          level: event.data.level || 'info',
          message: String(event.data.message || ''),
          timestamp: event.data.timestamp || new Date().toISOString()
        };
        setConsoleLogs((prev) => [...prev.slice(-49), entry]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const errorCount = consoleLogs.filter((l) => l.level === 'error').length;

  return /*#__PURE__*/(
    _react.default.createElement("div", {
      className: "glass-panel editor-preview-col",
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: 18,
        gap: 12
      } }, /*#__PURE__*/


    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%',
        flexWrap: 'wrap',
        gap: 8
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 6 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Smartphone, { size: 16, color: "#00ffc8" }), /*#__PURE__*/
    _react.default.createElement("span", { style: { fontSize: 14, fontWeight: 600 } }, "Android Web Sandbox")), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 6 } }, /*#__PURE__*/
    _react.default.createElement("select", {
      className: "glass-input",
      value: presetId,
      onChange: (e) => setPresetId(e.target.value),
      style: { width: 'auto', minHeight: 30, padding: '4px 8px', fontSize: 12 } },

    SCREEN_PRESETS.map((p) => /*#__PURE__*/
    _react.default.createElement("option", { key: p.id, value: p.id, style: { background: '#1f1c2c' } },
    p.label))), /*#__PURE__*/




    _react.default.createElement("button", {
      type: "button",
      title: "Rotate Orientation",
      onClick: () => setIsLandscape(!isLandscape),
      style: {
        background: 'rgba(255,255,255,0.1)',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 8,
        color: '#fff',
        padding: 6,
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.RotateCcw, { size: 14 })), /*#__PURE__*/


    _react.default.createElement("button", {
      type: "button",
      title: "Sandbox Notes & Limitations",
      onClick: () => setShowLimitations(!showLimitations),
      style: {
        background: showLimitations ? 'rgba(0,255,200,0.2)' : 'rgba(255,255,255,0.1)',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 8,
        color: '#fff',
        padding: 6,
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Info, { size: 14 })), /*#__PURE__*/


    _react.default.createElement("button", {
      type: "button",
      title: "Refresh Preview",
      onClick: onRefresh,
      style: {
        background: 'rgba(255,255,255,0.1)',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 8,
        color: '#fff',
        padding: 6,
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.RefreshCw, { size: 14 })))),





    showLimitations && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        width: '100%',
        padding: '10px 12px',
        borderRadius: 12,
        background: 'rgba(0, 0, 0, 0.38)',
        border: '1px solid rgba(255, 255, 255, 0.14)',
        fontSize: 11,
        color: 'rgba(255, 255, 255, 0.8)',
        lineHeight: 1.45
      } }, /*#__PURE__*/

    _react.default.createElement("strong", null, "Preview Sandbox Notes:"), " Local relative assets (CSS, JS, images, fonts) resolve directly from your project root. External APIs that block cross-origin requests (CORS) or native Android hardware APIs (vibration, camera, native SQLite) require running inside the compiled Android WebView APK."), /*#__PURE__*/







    _react.default.createElement("div", {
      style: {
        width: Math.min(frameWidth, 340),
        height: Math.min(frameHeight, 500),
        border: '7px solid #222',
        borderRadius: 32,
        overflow: 'hidden',
        background: '#fff',
        boxShadow: '0 16px 36px rgba(0,0,0,0.5)'
      } },

    isStandalone ? /*#__PURE__*/
    _react.default.createElement("iframe", {
      key: previewKey,
      srcDoc: inlineSrcDoc,
      title: "Live Android WebView Preview",
      style: { width: '100%', height: '100%', border: 'none' } }) : /*#__PURE__*/


    _react.default.createElement("iframe", {
      key: previewKey,
      src: previewSrcUrl,
      title: "Live Android WebView Preview",
      style: { width: '100%', height: '100%', border: 'none' } })), /*#__PURE__*/





    _react.default.createElement("div", {
      style: {
        width: '100%',
        background: 'rgba(0, 0, 0, 0.42)',
        borderRadius: 12,
        border: '1px solid rgba(255, 255, 255, 0.1)',
        overflow: 'hidden'
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      onClick: () => setShowConsole(!showConsole),
      style: {
        padding: '8px 12px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        cursor: 'pointer',
        borderBottom: showConsole ? '1px solid rgba(255,255,255,0.08)' : 'none'
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Terminal, { size: 13, color: "#00ffc8" }), /*#__PURE__*/
    _react.default.createElement("span", null, "Preview Console (", consoleLogs.length, ")"),
    errorCount > 0 && /*#__PURE__*/
    _react.default.createElement("span", {
      style: {
        background: 'rgba(255, 107, 107, 0.25)',
        color: '#ff6b6b',
        padding: '1px 6px',
        borderRadius: 999,
        fontSize: 10,
        fontWeight: 700
      } },

    errorCount, " error", errorCount > 1 ? 's' : '')), /*#__PURE__*/



    _react.default.createElement("button", {
      type: "button",
      onClick: (e) => {
        e.stopPropagation();
        setConsoleLogs([]);
      },
      title: "Clear Console",
      style: {
        background: 'transparent',
        border: 'none',
        color: 'rgba(255,255,255,0.5)',
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Trash2, { size: 12 }))),



    showConsole && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        maxHeight: 110,
        overflowY: 'auto',
        padding: '8px 10px',
        fontFamily: 'monospace',
        fontSize: 11,
        display: 'flex',
        flexDirection: 'column',
        gap: 4
      } },

    consoleLogs.length === 0 ? /*#__PURE__*/
    _react.default.createElement("span", { style: { color: 'rgba(255,255,255,0.4)' } }, "No console output or runtime errors captured yet.") :



    consoleLogs.map((log) => /*#__PURE__*/
    _react.default.createElement("div", {
      key: log.id,
      style: {
        color:
        log.level === 'error' ?
        '#ff6b6b' :
        log.level === 'warn' ?
        '#feca57' :
        '#00ffc8',
        wordBreak: 'break-word'
      } },
    "[",
    log.level.toUpperCase(), "] ", log.message))))));








};exports.LivePreviewPane = LivePreviewPane;
},
"./features/python/PythonInspectorPanel": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.PythonInspectorPanel = void 0;var _react = _interopRequireDefault(require("react"));

var _StatusBadge = require("../../components/StatusBadge");
var _GlassButton = require("../../components/GlassButton");
var _lucideReact = require("lucide-react");function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}







const PythonInspectorPanel = ({
  inspection,
  onGenerateBridge,
  isGeneratingBridge
}) => {
  if (!inspection) return null;

  const tierLabel =
  inspection.classification === 'supported' ?
  'Supported for Packaging' :
  inspection.classification === 'requires_modification' ?
  'Requires Modification' :
  'Unsupported Modules / Error';

  return /*#__PURE__*/(
    _react.default.createElement("div", {
      style: {
        padding: 14,
        borderRadius: 14,
        background: 'rgba(0, 0, 0, 0.32)',
        border: '1px solid rgba(255, 255, 255, 0.12)',
        marginBottom: 12,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 8
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Cpu, { size: 16, color: "#00ffc8" }), /*#__PURE__*/
    _react.default.createElement("span", { style: { fontSize: 13, fontWeight: 600 } }, "Python Packaging Diagnostics (",
    inspection.entrypoint || 'No entrypoint', ")")), /*#__PURE__*/


    _react.default.createElement(_StatusBadge.StatusBadge, { status: inspection.classification, label: tierLabel })),


    inspection.error && /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: '#ff6b6b' } }, inspection.error),


    inspection.unsupported_modules && inspection.unsupported_modules.length > 0 && /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: '#ff6b6b' } }, /*#__PURE__*/
    _react.default.createElement("strong", null, "Incompatible Modules:"), /*#__PURE__*/
    _react.default.createElement("ul", { style: { paddingLeft: 18, marginTop: 4 } },
    inspection.unsupported_modules.map((u) => /*#__PURE__*/
    _react.default.createElement("li", { key: u.module }, /*#__PURE__*/
    _react.default.createElement("code", null, u.module), ": ", u.reason)))),






    inspection.modification_reasons && inspection.modification_reasons.length > 0 && /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: '#feca57' } }, /*#__PURE__*/
    _react.default.createElement("strong", null, "Required Modifications:"), /*#__PURE__*/
    _react.default.createElement("ul", { style: { paddingLeft: 18, marginTop: 4 } },
    inspection.modification_reasons.map((m, i) => /*#__PURE__*/
    _react.default.createElement("li", { key: i }, m)))), /*#__PURE__*/





    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 8,
        fontSize: 11,
        color: 'rgba(255,255,255,0.65)'
      } }, /*#__PURE__*/

    _react.default.createElement("span", null, "Imports:",
    ' ',
    inspection.detected_imports.length > 0 ?
    inspection.detected_imports.join(', ') :
    'None', ' ', "| HTML Bridge: ",
    inspection.has_html_bridge ? 'Present' : 'Missing'), /*#__PURE__*/


    _react.default.createElement("div", { style: { width: 'auto' } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, {
      type: "button",
      onClick: onGenerateBridge,
      disabled: isGeneratingBridge,
      style: { padding: '6px 12px', minHeight: 32, fontSize: 12 } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Wand2, { size: 13 }), ' ',
    isGeneratingBridge ? 'Generating...' : 'Generate / Refresh HTML Bridge')))));





};exports.PythonInspectorPanel = PythonInspectorPanel;
},
"./hooks/useUnsavedChanges": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.useUnsavedChanges = useUnsavedChanges;var _react = require("react");

function useUnsavedChanges(isDirty) {
  (0, _react.useEffect)(() => {
    const handleBeforeUnload = (e) => {
      if (!isDirty) return;
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);
}
},
"./layouts/MainLayout": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.MainLayout = void 0;var _react = _interopRequireWildcard(require("react"));
var _lucideReact = require("lucide-react");
var _GlassModal = require("../components/GlassModal");
var _GlassButton = require("../components/GlassButton");
var _api = require("../services/api");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}








const MainLayout = ({
  children,
  activeTab,
  setActiveTab,
  selectedProjectName
}) => {
  const [isServerModalOpen, setIsServerModalOpen] = (0, _react.useState)(false);
  const [serverUrlInput, setServerUrlInput] = (0, _react.useState)(_api.API.getRemoteBackendUrl());
  const [savedNotice, setSavedNotice] = (0, _react.useState)(null);

  const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: _lucideReact.Layers, disabled: false },
  { id: 'editor', label: 'Code & Files', icon: _lucideReact.Code, disabled: !selectedProjectName },
  { id: 'customization', label: 'Customization', icon: _lucideReact.Sliders, disabled: !selectedProjectName },
  { id: 'animations', label: 'Animations', icon: _lucideReact.Play, disabled: !selectedProjectName },
  { id: 'build', label: 'Build Engine', icon: _lucideReact.Box, disabled: !selectedProjectName }];


  const handleSaveServerUrl = (e) => {
    e.preventDefault();
    _api.API.setRemoteBackendUrl(serverUrlInput);
    setSavedNotice(
    serverUrlInput.trim() ?
    `Connected remote build server: ${serverUrlInput.trim()}` :
    'Using local / on-device workspace engine.');

    setTimeout(() => {
      setSavedNotice(null);
      setIsServerModalOpen(false);
    }, 900);
  };

  return /*#__PURE__*/(
    _react.default.createElement("div", { style: { display: 'flex', minHeight: '100vh', flexDirection: 'column' } }, /*#__PURE__*/
    _react.default.createElement("header", { className: "studio-header" }, /*#__PURE__*/
    _react.default.createElement("div", {
      style: { display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' },
      onClick: () => setActiveTab('dashboard') }, /*#__PURE__*/

    _react.default.createElement("div", { className: "app-icon", style: { width: 42, height: 42, margin: 0, borderRadius: 12 } }, /*#__PURE__*/
    _react.default.createElement("svg", { viewBox: "0 0 24 24", style: { width: 22, height: 22, fill: 'none' } }, /*#__PURE__*/
    _react.default.createElement("path", { d: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" }))), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("h1", { style: { fontSize: 18, margin: 0, letterSpacing: '-0.3px' } }, "APK STUDIO"), /*#__PURE__*/
    _react.default.createElement("span", { style: { fontSize: 12, color: 'rgba(255,255,255,0.65)' } },
    selectedProjectName ? `Active Project: ${selectedProjectName}` : 'No active project selected'))), /*#__PURE__*/




    _react.default.createElement("nav", { className: "studio-nav", "aria-label": "Main Studio Navigation" },
    navItems.map((item) => {
      const Icon = item.icon;
      const isActive = activeTab === item.id;
      return /*#__PURE__*/(
        _react.default.createElement("button", {
          key: item.id,
          disabled: item.disabled,
          onClick: () => setActiveTab(item.id),
          style: {
            background: isActive ? 'rgba(255,255,255,0.18)' : 'transparent',
            border: '1px solid',
            borderColor: isActive ? 'rgba(255,255,255,0.32)' : 'transparent',
            borderRadius: 10,
            color: item.disabled ? 'rgba(255,255,255,0.25)' : '#fff',
            padding: '8px 14px',
            cursor: item.disabled ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            fontSize: 13,
            fontWeight: 500,
            transition: 'all 0.2s',
            whiteSpace: 'nowrap'
          } }, /*#__PURE__*/

        _react.default.createElement(Icon, { size: 16 }),
        item.label));


    }), /*#__PURE__*/

    _react.default.createElement("button", {
      type: "button",
      title: "Build Server & Connection Settings",
      onClick: () => {
        setServerUrlInput(_api.API.getRemoteBackendUrl());
        setSavedNotice(null);
        setIsServerModalOpen(true);
      },
      style: {
        background: _api.API.getRemoteBackendUrl() ? 'rgba(0, 255, 200, 0.16)' : 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.2)',
        borderRadius: 10,
        color: '#fff',
        padding: '8px 12px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 12,
        fontWeight: 500
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Settings, { size: 15 }), /*#__PURE__*/
    _react.default.createElement("span", null, _api.API.getRemoteBackendUrl() ? 'Remote Server' : 'Engine Config')))), /*#__PURE__*/




    _react.default.createElement("main", { className: "studio-main" }, children), /*#__PURE__*/

    _react.default.createElement(_GlassModal.GlassModal, {
      isOpen: isServerModalOpen,
      title: "Build Engine & Server Configuration",
      onClose: () => setIsServerModalOpen(false) }, /*#__PURE__*/

    _react.default.createElement("form", { onSubmit: handleSaveServerUrl }, /*#__PURE__*/
    _react.default.createElement("p", { style: { fontSize: 13, color: 'rgba(255,255,255,0.75)', marginBottom: 14, lineHeight: 1.5 } }, "APK STUDIO runs with a persistent On-Device Workspace inside the Android APK and syncs automatically with your Node.js/Docker Build Server when reachable. To delegate native Gradle APK compilation from a mobile device to a remote host, enter your server URL below:"), /*#__PURE__*/




    _react.default.createElement("label", { style: { fontSize: 12, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Remote Build Server URL (leave blank for Local / On-Device Mode)"), /*#__PURE__*/


    _react.default.createElement("input", {
      className: "glass-input",
      placeholder: "e.g. http://192.168.1.50:4000",
      value: serverUrlInput,
      onChange: (e) => setServerUrlInput(e.target.value),
      style: { marginBottom: 16 } }),

    savedNotice && /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: '#00ffc8', marginBottom: 12 } }, savedNotice), /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', gap: 10 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "submit" }, "Save Configuration"), /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setIsServerModalOpen(false),
      style: {
        flex: 1,
        background: 'transparent',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 14,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer'
      } },
    "Close"))))));







};exports.MainLayout = MainLayout;
},
"./main": function(module, exports, require) {
"use strict";var _react = _interopRequireDefault(require("react"));
var _client = _interopRequireDefault(require("react-dom/client"));
var _App = require("./app/App");
require("./styles/index.css");function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

_client.default.createRoot(document.getElementById('root')).render( /*#__PURE__*/
_react.default.createElement(_react.default.StrictMode, null, /*#__PURE__*/
_react.default.createElement(_App.App, null)));
},
"./pages/AnimationStudio": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.AnimationStudio = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../services/api");
var _GlassButton = require("../components/GlassButton");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}







const ANIMATION_PRESETS = [
{
  name: 'Liquid Glass Default',
  config: {
    splash_animation: 'fade',
    splash_duration_ms: 1500,
    pulse_duration_s: 2.0,
    glass_blur_px: 30,
    page_transition: 'fade',
    loader_style: 'spinner',
    button_effect: 'scale-press',
    inject_stylesheet: true
  }
},
{
  name: 'Dynamic Scale & Glow',
  config: {
    splash_animation: 'scale',
    splash_duration_ms: 1800,
    pulse_duration_s: 1.4,
    glass_blur_px: 40,
    page_transition: 'zoom',
    loader_style: 'pulse-ring',
    button_effect: 'glow-hover',
    inject_stylesheet: true
  }
},
{
  name: 'Snappy Minimal',
  config: {
    splash_animation: 'slide',
    splash_duration_ms: 900,
    pulse_duration_s: 3.5,
    glass_blur_px: 18,
    page_transition: 'slide-up',
    loader_style: 'progress-bar',
    button_effect: 'scale-press',
    inject_stylesheet: true
  }
}];


const AnimationStudio = ({
  projectId,
  initialAnimations,
  onUpdated
}) => {
  const [config, setConfig] = (0, _react.useState)(initialAnimations);
  const [isSaving, setIsSaving] = (0, _react.useState)(false);
  const [statusMessage, setStatusMessage] = (0, _react.useState)(null);

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const res = await _api.API.updateAnimations(projectId, config);
      onUpdated(res.animations);
      setStatusMessage(
      'Animation preset saved to database, linked to MainActivity splash config, and written to apk_studio_animations.css.');

    } catch (err) {
      setStatusMessage(`Error: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return /*#__PURE__*/(
    _react.default.createElement("div", { className: "glass-panel", style: { width: '100%', maxWidth: 820, padding: 32 } }, /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 12,
        marginBottom: 20
      } }, /*#__PURE__*/

    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("h2", { style: { fontSize: 24, marginBottom: 4 } }, "Animation Studio"), /*#__PURE__*/
    _react.default.createElement("p", { style: { color: 'rgba(255,255,255,0.72)', fontSize: 14 } }, "Configure native splash transitions, button micro-interactions, loaders, and frosted glass effects injected into your packaged APK.")), /*#__PURE__*/





    _react.default.createElement("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' } },
    ANIMATION_PRESETS.map((preset) => /*#__PURE__*/
    _react.default.createElement("button", {
      key: preset.name,
      type: "button",
      onClick: () => setConfig({ ...preset.config }),
      style: {
        padding: '6px 12px',
        borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.2)',
        background: 'rgba(255,255,255,0.1)',
        color: '#fff',
        fontSize: 12,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: 5
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Sparkles, { size: 12, color: "#00ffc8" }),
    preset.name)))), /*#__PURE__*/






    _react.default.createElement("div", {
      style: {
        height: 210,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 14,
        background: 'rgba(0, 0, 0, 0.28)',
        borderRadius: 20,
        marginBottom: 24,
        border: '1px solid rgba(255, 255, 255, 0.12)',
        position: 'relative',
        overflow: 'hidden'
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      className: "app-icon",
      style: {
        margin: 0,
        animation: `studioPulse ${config.pulse_duration_s}s ease-in-out infinite`,
        backdropFilter: `blur(${config.glass_blur_px}px)`,
        WebkitBackdropFilter: `blur(${config.glass_blur_px}px)`
      } }, /*#__PURE__*/

    _react.default.createElement("svg", { viewBox: "0 0 24 24", style: { fill: 'none' } }, /*#__PURE__*/
    _react.default.createElement("path", { d: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" }))),




    config.loader_style !== 'none' && /*#__PURE__*/
    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#00ffc8' } }, /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        width: 16,
        height: 16,
        borderRadius: '50%',
        border: '2px solid rgba(0,255,200,0.3)',
        borderTopColor: '#00ffc8',
        animation: 'studioSpin 1s linear infinite'
      } }), /*#__PURE__*/

    _react.default.createElement("span", null, "Splash: ",
    config.splash_animation.toUpperCase(), " (", config.splash_duration_ms, "ms) \u2022 Loader: ",
    config.loader_style)), /*#__PURE__*/




    _react.default.createElement("button", {
      type: "button",
      style: {
        padding: '8px 18px',
        borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.28)',
        background: 'rgba(255,255,255,0.14)',
        color: '#fff',
        fontSize: 12,
        fontWeight: 600,
        cursor: 'pointer',
        boxShadow:
        config.button_effect === 'glow-hover' ?
        '0 0 16px rgba(0, 255, 200, 0.45)' :
        'none'
      } },
    "Interactive Button (",
    config.button_effect, ")")), /*#__PURE__*/




    _react.default.createElement("div", { style: { display: 'flex', flexDirection: 'column', gap: 18 } }, /*#__PURE__*/
    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Splash Screen Transition"), /*#__PURE__*/


    _react.default.createElement("select", {
      className: "glass-input",
      value: config.splash_animation,
      onChange: (e) =>
      setConfig({
        ...config,
        splash_animation: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "fade", style: { background: '#1f1c2c' } }, "Fade Out"), /*#__PURE__*/


    _react.default.createElement("option", { value: "scale", style: { background: '#1f1c2c' } }, "Scale Zoom"), /*#__PURE__*/


    _react.default.createElement("option", { value: "slide", style: { background: '#1f1c2c' } }, "Slide Up"), /*#__PURE__*/


    _react.default.createElement("option", { value: "pulse", style: { background: '#1f1c2c' } }, "Pulse & Dissolve"), /*#__PURE__*/


    _react.default.createElement("option", { value: "none", style: { background: '#1f1c2c' } }, "None"))), /*#__PURE__*/





    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Splash Duration (ms)"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "number",
      min: 0,
      max: 10000,
      step: 100,
      className: "glass-input",
      value: config.splash_duration_ms,
      onChange: (e) =>
      setConfig({
        ...config,
        splash_duration_ms: parseInt(e.target.value, 10) || 0
      }) }))), /*#__PURE__*/





    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Page Enter Transition"), /*#__PURE__*/


    _react.default.createElement("select", {
      className: "glass-input",
      value: config.page_transition,
      onChange: (e) =>
      setConfig({
        ...config,
        page_transition: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "fade", style: { background: '#1f1c2c' } }, "Smooth Opacity Fade"), /*#__PURE__*/


    _react.default.createElement("option", { value: "slide-up", style: { background: '#1f1c2c' } }, "Slide Up Entrance"), /*#__PURE__*/


    _react.default.createElement("option", { value: "zoom", style: { background: '#1f1c2c' } }, "Scale Zoom Entrance"), /*#__PURE__*/


    _react.default.createElement("option", { value: "none", style: { background: '#1f1c2c' } }, "No Page Transition"))), /*#__PURE__*/





    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Button Micro-Interaction"), /*#__PURE__*/


    _react.default.createElement("select", {
      className: "glass-input",
      value: config.button_effect,
      onChange: (e) =>
      setConfig({
        ...config,
        button_effect: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "scale-press", style: { background: '#1f1c2c' } }, "Tactile Scale Press"), /*#__PURE__*/


    _react.default.createElement("option", { value: "glow-hover", style: { background: '#1f1c2c' } }, "Luminous Glow"), /*#__PURE__*/


    _react.default.createElement("option", { value: "ripple", style: { background: '#1f1c2c' } }, "Soft Opacity Ripple"), /*#__PURE__*/


    _react.default.createElement("option", { value: "none", style: { background: '#1f1c2c' } }, "None")))), /*#__PURE__*/






    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Pulse Cycle Duration: ",
    config.pulse_duration_s, "s"), /*#__PURE__*/

    _react.default.createElement("input", {
      type: "range",
      min: "0.5",
      max: "10",
      step: "0.1",
      value: config.pulse_duration_s,
      onChange: (e) =>
      setConfig({ ...config, pulse_duration_s: parseFloat(e.target.value) }),

      style: { width: '100%' } })), /*#__PURE__*/



    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, display: 'block', marginBottom: 6 } }, "Frosted Glass Surface Blur: ",
    config.glass_blur_px, "px"), /*#__PURE__*/

    _react.default.createElement("input", {
      type: "range",
      min: "0",
      max: "60",
      value: config.glass_blur_px,
      onChange: (e) =>
      setConfig({ ...config, glass_blur_px: parseInt(e.target.value, 10) }),

      style: { width: '100%' } }))), /*#__PURE__*/




    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: config.inject_stylesheet !== false,
      onChange: (e) => setConfig({ ...config, inject_stylesheet: e.target.checked }) }),
    "Inject ", /*#__PURE__*/
    _react.default.createElement("code", null, "apk_studio_animations.css"), " into packaged Android WebView assets"), /*#__PURE__*/


    _react.default.createElement("div", { style: { marginTop: 8 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "button", onClick: handleSave, disabled: isSaving },
    isSaving ? 'Saving Animation Preset...' : 'Save & Apply Animation Configuration')),



    statusMessage && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        fontSize: 13,
        color: '#00ffc8',
        textAlign: 'center'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.CheckCircle2, { size: 16 }), /*#__PURE__*/
    _react.default.createElement("span", null, statusMessage)))));





};exports.AnimationStudio = AnimationStudio;
},
"./pages/BuildStudio": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.BuildStudio = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../services/api");
var _GlassButton = require("../components/GlassButton");
var _StatusBadge = require("../components/StatusBadge");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}













const BuildStudio = ({ projectId }) => {
  const [builds, setBuilds] = (0, _react.useState)([]);
  const [activeBuild, setActiveBuild] = (0, _react.useState)(null);
  const [buildType, setBuildType] = (0, _react.useState)('debug');
  const [isTriggering, setIsTriggering] = (0, _react.useState)(false);
  const [toolchain, setToolchain] = (0, _react.useState)(null);
  const [exportStatus, setExportStatus] = (0, _react.useState)(null);

  const loadBuilds = async () => {
    const list = await _api.API.listBuilds(projectId);
    setBuilds(list);
    if (list.length > 0 && !activeBuild) {
      setActiveBuild(list[0]);
    }
  };

  const loadDiagnostics = async () => {
    try {
      const diag = await _api.API.getSystemDiagnostics();
      setToolchain(diag.toolchain);
    } catch {

      // ignore
    }};

  (0, _react.useEffect)(() => {
    loadBuilds();
    loadDiagnostics();
  }, [projectId]);

  (0, _react.useEffect)(() => {
    if (!activeBuild || ['success', 'failed'].includes(activeBuild.status)) return;
    const interval = setInterval(async () => {
      const updated = await _api.API.getBuildStatus(activeBuild.id);
      setActiveBuild(updated);
      if (['success', 'failed'].includes(updated.status)) {
        loadBuilds();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [activeBuild]);

  const handleStartBuild = async () => {
    setIsTriggering(true);
    setExportStatus(null);
    try {
      const { buildId } = await _api.API.triggerBuild(projectId, buildType);
      const initialRecord = await _api.API.getBuildStatus(buildId);
      setActiveBuild(initialRecord);
      await loadBuilds();
    } finally {
      setIsTriggering(false);
    }
  };

  const handleExportAndroidProject = async () => {
    if (!activeBuild) return;
    setExportStatus('Packaging Android Gradle project (.zip)...');
    try {
      await _api.API.exportAndroidGradleProject(activeBuild.id);
      setExportStatus('Exported Android Gradle project (.zip) successfully.');
    } catch (err) {
      setExportStatus(`Export failed: ${err.message}`);
    }
  };

  const remoteBase = _api.API.getRemoteBackendUrl();
  const downloadApkHref = activeBuild ?
  `${remoteBase || ''}/api/builds/${activeBuild.id}/download` :
  '#';

  return /*#__PURE__*/(
    _react.default.createElement("div", { style: { width: '100%', maxWidth: 1200, display: 'flex', flexDirection: 'column', gap: 18 } },

    toolchain && /*#__PURE__*/
    _react.default.createElement("div", {
      className: "glass-panel",
      style: {
        padding: '16px 22px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 12
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 10 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Wrench, {
      size: 18,
      color: toolchain.readyForNativeBuild ? '#00ffc8' : '#feca57' }), /*#__PURE__*/

    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 14, fontWeight: 600 } }, "Android Build Environment:",
    ' ',
    toolchain.readyForNativeBuild ?
    'Native SDK & Gradle Ready' :
    'Standalone / Host Missing Native Android SDK'), /*#__PURE__*/

    _react.default.createElement("div", { style: { fontSize: 12, color: 'rgba(255,255,255,0.68)' } }, "Java: ",
    toolchain.javaAvailable ? 'OK' : 'Missing', " \u2022 javac:", ' ',
    toolchain.javacAvailable ? 'OK' : 'Missing', " \u2022 Android SDK 34:", ' ',
    toolchain.platform34Installed ? 'OK' : 'Missing', " \u2022 Gradle:", ' ',
    toolchain.gradleAvailable ? 'OK' : 'Missing'))), /*#__PURE__*/



    _react.default.createElement(_StatusBadge.StatusBadge, {
      status: toolchain.readyForNativeBuild ? 'ready' : 'warn',
      label:
      toolchain.readyForNativeBuild ?
      'Full APK Compilation Ready' :
      'Generates Android Gradle Project (.zip)' })), /*#__PURE__*/





    _react.default.createElement("div", { className: "build-layout" }, /*#__PURE__*/

    _react.default.createElement("div", {
      className: "glass-panel",
      style: { padding: 24, display: 'flex', flexDirection: 'column', gap: 14 } }, /*#__PURE__*/

    _react.default.createElement("h3", { style: { fontSize: 18 } }, "Compilation Engine"), /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', gap: 8 } }, /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setBuildType('debug'),
      style: {
        flex: 1,
        padding: '9px',
        borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.2)',
        background: buildType === 'debug' ? 'rgba(255,255,255,0.2)' : 'transparent',
        color: '#fff',
        fontSize: 12.5,
        fontWeight: 600,
        cursor: 'pointer'
      } },
    "Debug APK"), /*#__PURE__*/


    _react.default.createElement("button", {
      type: "button",
      onClick: () => setBuildType('release'),
      style: {
        flex: 1,
        padding: '9px',
        borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.2)',
        background: buildType === 'release' ? 'rgba(255,255,255,0.2)' : 'transparent',
        color: '#fff',
        fontSize: 12.5,
        fontWeight: 600,
        cursor: 'pointer'
      } },
    "Release APK")), /*#__PURE__*/




    _react.default.createElement(_GlassButton.GlassButton, {
      onClick: handleStartBuild,
      disabled: isTriggering || activeBuild?.status === 'building' }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Play, { size: 16 }), ' ',
    activeBuild?.status === 'building' ?
    'Compiling...' :
    `Compile Android ${buildType.toUpperCase()} APK`), /*#__PURE__*/


    _react.default.createElement("h4", {
      style: {
        fontSize: 13,
        marginTop: 10,
        color: 'rgba(255,255,255,0.72)',
        textTransform: 'uppercase',
        letterSpacing: '0.5px'
      } },
    "Build History (",
    builds.length, ")"), /*#__PURE__*/


    _react.default.createElement("div", {
      style: {
        flex: 1,
        maxHeight: 420,
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      } },

    builds.length === 0 ? /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: 'rgba(255,255,255,0.45)' } }, "No build attempts recorded yet.") :



    builds.map((b) => /*#__PURE__*/
    _react.default.createElement("div", {
      key: b.id,
      onClick: () => setActiveBuild(b),
      style: {
        padding: 12,
        borderRadius: 12,
        cursor: 'pointer',
        background:
        activeBuild?.id === b.id ? 'rgba(255,255,255,0.16)' : 'rgba(0,0,0,0.24)',
        border: '1px solid rgba(255,255,255,0.1)'
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4
      } }, /*#__PURE__*/

    _react.default.createElement("span", { style: { fontSize: 13, fontWeight: 600 } }, "#",
    b.id.substring(0, 8), " (", b.build_type || 'debug', ")"),

    b.status === 'success' && /*#__PURE__*/_react.default.createElement(_lucideReact.CheckCircle, { size: 15, color: "#00ffc8" }),
    b.status === 'failed' && /*#__PURE__*/_react.default.createElement(_lucideReact.AlertCircle, { size: 15, color: "#ff6b6b" }),
    ['queued', 'building'].includes(b.status) && /*#__PURE__*/
    _react.default.createElement("span", { style: { fontSize: 11, color: '#feca57' } },
    b.stage || 'Building...')), /*#__PURE__*/



    _react.default.createElement("div", {
      style: {
        fontSize: 11,
        color: 'rgba(255,255,255,0.55)',
        display: 'flex',
        justifyContent: 'space-between'
      } }, /*#__PURE__*/

    _react.default.createElement("span", null, new Date(b.started_at).toLocaleString()), /*#__PURE__*/
    _react.default.createElement("span", null, b.status.toUpperCase())))))), /*#__PURE__*/








    _react.default.createElement("div", {
      className: "glass-panel",
      style: { flex: 1, padding: 24, display: 'flex', flexDirection: 'column', gap: 14 } }, /*#__PURE__*/

    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Terminal, { size: 18, color: "#00ffc8" }), /*#__PURE__*/
    _react.default.createElement("h3", { style: { fontSize: 16 } }, "Build Pipeline Output",
    ' ',
    activeBuild ? `(Stage: ${activeBuild.stage || activeBuild.status})` : '')), /*#__PURE__*/



    _react.default.createElement("div", { style: { display: 'flex', gap: 10, flexWrap: 'wrap' } },
    activeBuild && /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: handleExportAndroidProject,
      className: "liquid-glass-btn",
      style: {
        width: 'auto',
        padding: '8px 14px',
        fontSize: 12,
        minHeight: 36
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.FolderArchive, { size: 14 }), " Export Android Gradle Project (.zip)"),



    activeBuild?.status === 'success' && activeBuild.apk_filename && /*#__PURE__*/
    _react.default.createElement("a", {
      href: downloadApkHref,
      className: "liquid-glass-btn",
      style: {
        width: 'auto',
        padding: '8px 16px',
        fontSize: 12.5,
        minHeight: 36,
        background: 'rgba(0, 255, 200, 0.22)'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Download, { size: 14 }), " Download Verified APK (", activeBuild.apk_filename, ")"))),





    exportStatus && /*#__PURE__*/
    _react.default.createElement("div", { style: { fontSize: 12, color: '#00ffc8' } }, exportStatus),



    activeBuild && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        width: '100%',
        height: 8,
        background: 'rgba(0,0,0,0.4)',
        borderRadius: 999,
        overflow: 'hidden'
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      style: {
        width: `${activeBuild.progress || (activeBuild.status === 'success' ? 100 : 35)}%`,
        height: '100%',
        background:
        activeBuild.status === 'failed' ?
        '#ff6b6b' :
        activeBuild.status === 'success' ?
        '#00ffc8' :
        '#feca57',
        transition: 'width 0.3s ease'
      } })),




    activeBuild?.error_summary && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        padding: '10px 14px',
        borderRadius: 12,
        background: 'rgba(255, 107, 107, 0.16)',
        border: '1px solid rgba(255, 107, 107, 0.35)',
        color: '#ff9f9f',
        fontSize: 12.5
      } }, /*#__PURE__*/

    _react.default.createElement("strong", null, "Diagnostic Summary:"), " ", activeBuild.error_summary), /*#__PURE__*/



    _react.default.createElement("div", {
      style: {
        flex: 1,
        background: 'rgba(0, 0, 0, 0.52)',
        borderRadius: 14,
        padding: 16,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
        fontSize: 12,
        lineHeight: 1.55,
        color: '#cbd5e1',
        overflowY: 'auto',
        minHeight: 380,
        maxHeight: 500,
        whiteSpace: 'pre-wrap',
        border: '1px solid rgba(255,255,255,0.08)'
      } },

    activeBuild ?
    activeBuild.log || 'Build job queued. Initializing build stages...' :
    'Select a build record or trigger a new compilation to inspect real-time build stage logs.')))));





};exports.BuildStudio = BuildStudio;
},
"./pages/CustomizationStudio": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.CustomizationStudio = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../services/api");
var _GlassButton = require("../components/GlassButton");
var _validation = require("../utils/validation");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}







const PERMISSION_OPTIONS = [
{ id: 'android.permission.INTERNET', label: 'Internet Access (HTTP/HTTPS)' },
{ id: 'android.permission.ACCESS_NETWORK_STATE', label: 'Network Connectivity State' },
{ id: 'android.permission.CAMERA', label: 'Camera / WebRTC Video' },
{ id: 'android.permission.RECORD_AUDIO', label: 'Microphone / Audio Capture' },
{ id: 'android.permission.ACCESS_FINE_LOCATION', label: 'Precise GPS Location' },
{ id: 'android.permission.ACCESS_COARSE_LOCATION', label: 'Approximate Location' },
{ id: 'android.permission.VIBRATE', label: 'Haptic Vibration Feedback' },
{ id: 'android.permission.POST_NOTIFICATIONS', label: 'Push / Local Notifications' },
{ id: 'android.permission.WAKE_LOCK', label: 'Background Wake Lock' }];


const CustomizationStudio = ({
  projectId,
  initialSettings,
  onUpdated
}) => {
  const [settings, setSettings] = (0, _react.useState)(initialSettings);
  const [status, setStatus] = (0, _react.useState)(null);
  const [isSaving, setIsSaving] = (0, _react.useState)(false);

  const handleIconUpload = (e) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSettings((prev) => ({ ...prev, icon_data_url: reader.result }));
      }
    };
    reader.readAsDataURL(file);
  };

  const togglePermission = (permId) => {
    setSettings((prev) => {
      const current = new Set(prev.permissions || []);
      if (current.has(permId)) {
        current.delete(permId);
      } else {
        current.add(permId);
      }
      return { ...prev, permissions: Array.from(current) };
    });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const clientErrors = (0, _validation.validateCustomizationClient)(settings);
    if (clientErrors.length > 0) {
      setStatus({ message: clientErrors.join(' '), isError: true });
      return;
    }

    setIsSaving(true);
    setStatus(null);
    try {
      const res = await _api.API.updateCustomization(projectId, settings);
      onUpdated(res.customization);
      setStatus({
        message: 'Customization validated and synchronized with Android Gradle & Manifest config.'
      });
    } catch (err) {
      setStatus({ message: err.message, isError: true });
    } finally {
      setIsSaving(false);
    }
  };

  return /*#__PURE__*/(
    _react.default.createElement("div", { className: "glass-panel", style: { width: '100%', maxWidth: 860, padding: 32 } }, /*#__PURE__*/
    _react.default.createElement("h2", { style: { fontSize: 24, marginBottom: 6 } }, "App Customization Studio"), /*#__PURE__*/
    _react.default.createElement("p", { style: { color: 'rgba(255,255,255,0.72)', fontSize: 14, marginBottom: 24 } }, "Configure Android package identity, icons, splash screen, system bars, offline behavior, and manifest permissions."), /*#__PURE__*/




    _react.default.createElement("form", { onSubmit: handleSave, style: { display: 'flex', flexDirection: 'column', gap: 20 } }, /*#__PURE__*/

    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Application Name"), /*#__PURE__*/


    _react.default.createElement("input", {
      className: "glass-input",
      value: settings.app_name,
      onChange: (e) => setSettings({ ...settings, app_name: e.target.value }) })), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Android Package ID"), /*#__PURE__*/


    _react.default.createElement("input", {
      className: "glass-input",
      placeholder: "com.company.appname",
      value: settings.package_id,
      onChange: (e) => setSettings({ ...settings, package_id: e.target.value }) }))), /*#__PURE__*/




    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Version Name"), /*#__PURE__*/


    _react.default.createElement("input", {
      className: "glass-input",
      value: settings.version_name,
      onChange: (e) => setSettings({ ...settings, version_name: e.target.value }) })), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Version Code (Integer)"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "number",
      min: 1,
      className: "glass-input",
      value: settings.version_code,
      onChange: (e) =>
      setSettings({ ...settings, version_code: parseInt(e.target.value, 10) || 1 }) }))), /*#__PURE__*/






    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Launcher App Icon (PNG)"), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 12 } }, /*#__PURE__*/
    _react.default.createElement("div", {
      className: "app-icon",
      style: { width: 52, height: 52, margin: 0, borderRadius: 14, overflow: 'hidden' } },

    settings.icon_data_url ? /*#__PURE__*/
    _react.default.createElement("img", {
      src: settings.icon_data_url,
      alt: "App Icon",
      style: { width: '100%', height: '100%', objectFit: 'cover' } }) : /*#__PURE__*/


    _react.default.createElement("svg", { viewBox: "0 0 24 24", style: { width: 24, height: 24, fill: 'none' } }, /*#__PURE__*/
    _react.default.createElement("path", { d: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" }))), /*#__PURE__*/



    _react.default.createElement("label", { className: "liquid-glass-btn", style: { width: 'auto', padding: '8px 14px', fontSize: 12 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Upload, { size: 14 }), " Upload Icon", /*#__PURE__*/
    _react.default.createElement("input", {
      type: "file",
      accept: "image/png,image/jpeg,image/webp",
      onChange: handleIconUpload,
      style: { display: 'none' } })))), /*#__PURE__*/





    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Screen Orientation & Offline Strategy"), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', gap: 10 } }, /*#__PURE__*/
    _react.default.createElement("select", {
      className: "glass-input",
      value: settings.orientation,
      onChange: (e) =>
      setSettings({
        ...settings,
        orientation: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "portrait", style: { background: '#1f1c2c' } }, "Portrait"), /*#__PURE__*/


    _react.default.createElement("option", { value: "landscape", style: { background: '#1f1c2c' } }, "Landscape"), /*#__PURE__*/


    _react.default.createElement("option", { value: "unspecified", style: { background: '#1f1c2c' } }, "Auto-Sensor")), /*#__PURE__*/




    _react.default.createElement("select", {
      className: "glass-input",
      value: settings.offline_mode || 'cache_first',
      onChange: (e) =>
      setSettings({
        ...settings,
        offline_mode: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "cache_first", style: { background: '#1f1c2c' } }, "Cache Fallback"), /*#__PURE__*/


    _react.default.createElement("option", { value: "network_first", style: { background: '#1f1c2c' } }, "Network Default"), /*#__PURE__*/


    _react.default.createElement("option", { value: "offline_only", style: { background: '#1f1c2c' } }, "Offline Bundle Only"))))), /*#__PURE__*/








    _react.default.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
        gap: 14
      } }, /*#__PURE__*/

    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 } }, "Status Bar Color"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "color",
      className: "glass-input",
      value: settings.status_bar_color || '#1f1c2c',
      onChange: (e) => setSettings({ ...settings, status_bar_color: e.target.value }),
      style: { height: 42, padding: 4 } })), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 } }, "Navigation Bar Color"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "color",
      className: "glass-input",
      value: settings.nav_bar_color || '#1f1c2c',
      onChange: (e) => setSettings({ ...settings, nav_bar_color: e.target.value }),
      style: { height: 42, padding: 4 } })), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 } }, "Theme Accent Color"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "color",
      className: "glass-input",
      value: settings.theme_color || '#6c5ce7',
      onChange: (e) => setSettings({ ...settings, theme_color: e.target.value }),
      style: { height: 42, padding: 4 } })), /*#__PURE__*/


    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 } }, "Splash Background"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "color",
      className: "glass-input",
      value: settings.splash_color || '#1f1c2c',
      onChange: (e) => setSettings({ ...settings, splash_color: e.target.value }),
      style: { height: 42, padding: 4 } }))), /*#__PURE__*/





    _react.default.createElement("div", { className: "form-row-2" }, /*#__PURE__*/
    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Splash Screen Duration (ms)"), /*#__PURE__*/


    _react.default.createElement("input", {
      type: "number",
      min: 0,
      max: 10000,
      step: 100,
      className: "glass-input",
      value: settings.splash_duration_ms ?? 1500,
      onChange: (e) =>
      setSettings({
        ...settings,
        splash_duration_ms: parseInt(e.target.value, 10) || 0
      }) })), /*#__PURE__*/



    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 } }, "Splash Exit Animation"), /*#__PURE__*/


    _react.default.createElement("select", {
      className: "glass-input",
      value: settings.splash_animation || 'fade',
      onChange: (e) =>
      setSettings({
        ...settings,
        splash_animation: e.target.value
      }) }, /*#__PURE__*/


    _react.default.createElement("option", { value: "fade", style: { background: '#1f1c2c' } }, "Smooth Fade Out"), /*#__PURE__*/


    _react.default.createElement("option", { value: "scale", style: { background: '#1f1c2c' } }, "Zoom Scale Transition"), /*#__PURE__*/


    _react.default.createElement("option", { value: "slide", style: { background: '#1f1c2c' } }, "Slide Up Dismissal"), /*#__PURE__*/


    _react.default.createElement("option", { value: "pulse", style: { background: '#1f1c2c' } }, "Liquid Pulse & Fade"), /*#__PURE__*/


    _react.default.createElement("option", { value: "none", style: { background: '#1f1c2c' } }, "Instant (No Animation)")))), /*#__PURE__*/







    _react.default.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
        gap: 12,
        padding: 16,
        borderRadius: 14,
        background: 'rgba(0,0,0,0.22)',
        border: '1px solid rgba(255,255,255,0.1)'
      } }, /*#__PURE__*/

    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: Boolean(settings.fullscreen),
      onChange: (e) => setSettings({ ...settings, fullscreen: e.target.checked }) }),
    "Fullscreen Immersive Mode"), /*#__PURE__*/



    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: settings.splash_enabled !== false,
      onChange: (e) => setSettings({ ...settings, splash_enabled: e.target.checked }) }),
    "Show Native Launch Splash Screen"), /*#__PURE__*/



    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: Boolean(settings.light_status_bar),
      onChange: (e) => setSettings({ ...settings, light_status_bar: e.target.checked }) }),
    "Dark Status Bar Icons (Light Theme)"), /*#__PURE__*/



    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: Boolean(settings.keep_screen_on),
      onChange: (e) => setSettings({ ...settings, keep_screen_on: e.target.checked }) }),
    "Keep Screen Awake While Active"), /*#__PURE__*/



    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: Boolean(settings.enable_zoom),
      onChange: (e) => setSettings({ ...settings, enable_zoom: e.target.checked }) }),
    "Enable WebView Pinch-to-Zoom"), /*#__PURE__*/



    _react.default.createElement("label", { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' } }, /*#__PURE__*/
    _react.default.createElement("input", {
      type: "checkbox",
      checked: settings.allow_cleartext !== false,
      onChange: (e) => setSettings({ ...settings, allow_cleartext: e.target.checked }) }),
    "Allow Cleartext HTTP Traffic")), /*#__PURE__*/





    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 8 } }, "Android Manifest Permissions"), /*#__PURE__*/


    _react.default.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
        gap: 10,
        padding: 14,
        borderRadius: 14,
        background: 'rgba(0,0,0,0.22)',
        border: '1px solid rgba(255,255,255,0.1)'
      } },

    PERMISSION_OPTIONS.map((perm) => /*#__PURE__*/
    _react.default.createElement("label", {
      key: perm.id,
      style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, cursor: 'pointer' } }, /*#__PURE__*/

    _react.default.createElement("input", {
      type: "checkbox",
      checked: (settings.permissions || []).includes(perm.id),
      onChange: () => togglePermission(perm.id) }), /*#__PURE__*/

    _react.default.createElement("span", null, perm.label))))), /*#__PURE__*/





    _react.default.createElement("div", { style: { marginTop: 6 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "submit", disabled: isSaving },
    isSaving ? 'Validating & Saving...' : 'Save Android Customization')),



    status && /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        fontSize: 13,
        color: status.isError ? '#ff6b6b' : '#00ffc8',
        textAlign: 'center'
      } },

    status.isError ? /*#__PURE__*/_react.default.createElement(_lucideReact.AlertTriangle, { size: 16 }) : /*#__PURE__*/_react.default.createElement(_lucideReact.CheckCircle2, { size: 16 }), /*#__PURE__*/
    _react.default.createElement("span", null, status.message)))));





};exports.CustomizationStudio = CustomizationStudio;
},
"./pages/Dashboard": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.Dashboard = void 0;var _react = _interopRequireWildcard(require("react"));

var _GlassButton = require("../components/GlassButton");
var _GlassModal = require("../components/GlassModal");
var _StatusBadge = require("../components/StatusBadge");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}











const Dashboard = ({
  projects,
  errorBanner,
  onSelectProject,
  onCreateProject,
  onRenameProject,
  onDuplicateProject,
  onDeleteProject
}) => {
  const [isCreateOpen, setIsCreateOpen] = (0, _react.useState)(false);
  const [projectName, setProjectName] = (0, _react.useState)('');
  const [projectType, setProjectType] = (0, _react.useState)('html');

  const [renameTarget, setRenameTarget] = (0, _react.useState)(null);
  const [renameValue, setRenameValue] = (0, _react.useState)('');

  const [deleteTarget, setDeleteTarget] = (0, _react.useState)(null);
  const [formError, setFormError] = (0, _react.useState)(null);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!projectName.trim()) {
      setFormError('Please enter a project name.');
      return;
    }
    setFormError(null);
    await onCreateProject(projectName.trim(), projectType);
    setProjectName('');
    setIsCreateOpen(false);
  };

  const handleRenameSubmit = async (e) => {
    e.preventDefault();
    if (!renameTarget || !renameValue.trim()) return;
    await onRenameProject(renameTarget.id, renameValue.trim());
    setRenameTarget(null);
    setRenameValue('');
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    await onDeleteProject(deleteTarget.id);
    setDeleteTarget(null);
  };

  return /*#__PURE__*/(
    _react.default.createElement("div", { style: { width: '100%', maxWidth: 1080 } }, /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 16,
        marginBottom: 28
      } }, /*#__PURE__*/

    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("h2", { style: { fontSize: 28, fontWeight: 700 } }, "Workspace Projects"), /*#__PURE__*/
    _react.default.createElement("p", { style: { color: 'rgba(255,255,255,0.72)', fontSize: 14 } }, "Create, import, customize, and package HTML5 and Python applications for Android.")), /*#__PURE__*/



    _react.default.createElement("div", { style: { width: 185 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, {
      onClick: () => {
        setFormError(null);
        setIsCreateOpen(true);
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Plus, { size: 18 }), " New Project"))),




    errorBanner && /*#__PURE__*/
    _react.default.createElement("div", {
      className: "glass-panel",
      style: {
        padding: '12px 18px',
        marginBottom: 20,
        borderColor: 'rgba(255, 107, 107, 0.45)',
        color: '#ff6b6b',
        fontSize: 13
      } },

    errorBanner),



    projects.length === 0 ? /*#__PURE__*/
    _react.default.createElement("div", { className: "glass-panel", style: { padding: 48, textAlign: 'center' } }, /*#__PURE__*/
    _react.default.createElement("div", { className: "app-icon", style: { marginBottom: 18 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.FolderOpen, { size: 30 })), /*#__PURE__*/

    _react.default.createElement("h3", { style: { fontSize: 20, marginBottom: 8 } }, "No Projects Yet"), /*#__PURE__*/
    _react.default.createElement("p", { style: { color: 'rgba(255,255,255,0.68)', fontSize: 14, marginBottom: 24 } }, "Create your first HTML5 or Python project to launch the code editor, live preview, and Android APK build studio."), /*#__PURE__*/



    _react.default.createElement("div", { style: { width: 200, margin: '0 auto' } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { onClick: () => setIsCreateOpen(true) }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Plus, { size: 18 }), " Create First Project"))) : /*#__PURE__*/




    _react.default.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: 20
      } },

    projects.map((p) => /*#__PURE__*/
    _react.default.createElement("div", {
      key: p.id,
      className: "glass-panel",
      style: {
        padding: 24,
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        minHeight: 205,
        transition: 'transform 0.25s ease'
      },
      onClick: () => onSelectProject(p) }, /*#__PURE__*/

    _react.default.createElement("div", null, /*#__PURE__*/
    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start'
      } }, /*#__PURE__*/

    _react.default.createElement("div", {
      className: "app-icon",
      style: { width: 46, height: 46, margin: '0 0 14px 0', borderRadius: 13 } },

    p.type === 'python' ? /*#__PURE__*/_react.default.createElement(_lucideReact.Terminal, { size: 21 }) : /*#__PURE__*/_react.default.createElement(_lucideReact.FolderOpen, { size: 21 })), /*#__PURE__*/


    _react.default.createElement("div", {
      style: { display: 'flex', gap: 6 },
      onClick: (e) => e.stopPropagation() }, /*#__PURE__*/

    _react.default.createElement("button", {
      type: "button",
      title: "Rename Project",
      onClick: () => {
        setRenameTarget(p);
        setRenameValue(p.name);
      },
      style: {
        background: 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: 8,
        padding: 6,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Edit3, { size: 14 })), /*#__PURE__*/

    _react.default.createElement("button", {
      type: "button",
      title: "Duplicate Project",
      onClick: () => onDuplicateProject(p.id),
      style: {
        background: 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: 8,
        padding: 6,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Copy, { size: 14 })), /*#__PURE__*/

    _react.default.createElement("button", {
      type: "button",
      title: "Delete Project",
      onClick: () => setDeleteTarget(p),
      style: {
        background: 'rgba(255,107,107,0.12)',
        border: '1px solid rgba(255,107,107,0.25)',
        borderRadius: 8,
        padding: 6,
        color: '#ff6b6b',
        cursor: 'pointer',
        display: 'flex'
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.Trash2, { size: 14 })))), /*#__PURE__*/




    _react.default.createElement("h3", { className: "truncate-text", style: { fontSize: 18, marginBottom: 6 } },
    p.name), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' } }, /*#__PURE__*/
    _react.default.createElement(_StatusBadge.StatusBadge, { status: p.type, label: p.type === 'python' ? 'Python' : 'HTML5 Web' }), /*#__PURE__*/
    _react.default.createElement(_StatusBadge.StatusBadge, {
      status: p.last_build_status || p.status || 'ready',
      label:
      p.last_build_status ?
      `Last Build: ${p.last_build_status}` :
      p.status || 'Ready' })),




    p.package_id && /*#__PURE__*/
    _react.default.createElement("div", {
      className: "truncate-text",
      style: {
        fontSize: 12,
        color: 'rgba(255,255,255,0.6)',
        marginTop: 10,
        fontFamily: 'monospace'
      } },

    p.package_id, " \u2022 v", p.version_name || '1.0.0')), /*#__PURE__*/




    _react.default.createElement("div", {
      style: {
        fontSize: 12,
        color: 'rgba(255,255,255,0.5)',
        marginTop: 14,
        display: 'flex',
        justifyContent: 'space-between'
      } }, /*#__PURE__*/

    _react.default.createElement("span", null, "Modified: ", new Date(p.updated_at).toLocaleString()))))), /*#__PURE__*/







    _react.default.createElement(_GlassModal.GlassModal, {
      isOpen: isCreateOpen,
      title: "Create New Project",
      onClose: () => setIsCreateOpen(false) }, /*#__PURE__*/

    _react.default.createElement("form", { onSubmit: handleCreate }, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 } }, "Project Name"), /*#__PURE__*/


    _react.default.createElement("input", {
      className: "glass-input",
      placeholder: "e.g. Storefront Portal",
      value: projectName,
      onChange: (e) => setProjectName(e.target.value),
      autoFocus: true,
      style: { marginBottom: 16 } }), /*#__PURE__*/


    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 } }, "Runtime Architecture"), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', gap: 12, marginBottom: 20 } }, /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setProjectType('html'),
      style: {
        flex: 1,
        padding: '12px 10px',
        borderRadius: 12,
        border: '1px solid rgba(255,255,255,0.22)',
        background: projectType === 'html' ? 'rgba(255,255,255,0.22)' : 'transparent',
        color: '#fff',
        cursor: 'pointer',
        fontWeight: 600
      } },
    "HTML5 / CSS / JS"), /*#__PURE__*/


    _react.default.createElement("button", {
      type: "button",
      onClick: () => setProjectType('python'),
      style: {
        flex: 1,
        padding: '12px 10px',
        borderRadius: 12,
        border: '1px solid rgba(255,255,255,0.22)',
        background: projectType === 'python' ? 'rgba(255,255,255,0.22)' : 'transparent',
        color: '#fff',
        cursor: 'pointer',
        fontWeight: 600
      } },
    "Python Bridge")),




    formError && /*#__PURE__*/
    _react.default.createElement("div", { style: { color: '#ff6b6b', fontSize: 12, marginBottom: 12 } }, formError), /*#__PURE__*/


    _react.default.createElement("div", { style: { display: 'flex', gap: 12 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "submit" }, "Create Project"), /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setIsCreateOpen(false),
      style: {
        flex: 1,
        background: 'transparent',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 14,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer'
      } },
    "Cancel")))), /*#__PURE__*/







    _react.default.createElement(_GlassModal.GlassModal, {
      isOpen: Boolean(renameTarget),
      title: "Rename Project",
      onClose: () => setRenameTarget(null) }, /*#__PURE__*/

    _react.default.createElement("form", { onSubmit: handleRenameSubmit }, /*#__PURE__*/
    _react.default.createElement("input", {
      className: "glass-input",
      value: renameValue,
      onChange: (e) => setRenameValue(e.target.value),
      autoFocus: true,
      style: { marginBottom: 20 } }), /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', gap: 12 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "submit" }, "Save Name"), /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setRenameTarget(null),
      style: {
        flex: 1,
        background: 'transparent',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 14,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer'
      } },
    "Cancel")))), /*#__PURE__*/







    _react.default.createElement(_GlassModal.GlassModal, {
      isOpen: Boolean(deleteTarget),
      title: "Delete Project",
      onClose: () => setDeleteTarget(null) }, /*#__PURE__*/

    _react.default.createElement("p", { style: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginBottom: 24, lineHeight: 1.5 } }, "Are you sure you want to permanently delete",
    ' ', /*#__PURE__*/
    _react.default.createElement("strong", null, deleteTarget?.name), " and all of its source files and build records?"), /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', gap: 12 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, {
      type: "button",
      onClick: handleConfirmDelete,
      style: { background: 'rgba(255, 107, 107, 0.28)' } },
    "Delete Permanently"), /*#__PURE__*/


    _react.default.createElement("button", {
      type: "button",
      onClick: () => setDeleteTarget(null),
      style: {
        flex: 1,
        background: 'transparent',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 14,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer'
      } },
    "Cancel")))));






};exports.Dashboard = Dashboard;
},
"./pages/ProjectEditor": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.ProjectEditor = void 0;var _react = _interopRequireWildcard(require("react"));

var _api = require("../services/api");
var _GlassButton = require("../components/GlassButton");
var _GlassModal = require("../components/GlassModal");
var _FileTreeView = require("../features/editor/FileTreeView");
var _LivePreviewPane = require("../features/editor/LivePreviewPane");
var _PythonInspectorPanel = require("../features/python/PythonInspectorPanel");
var _useUnsavedChanges = require("../hooks/useUnsavedChanges");
var _syntaxHighlight = require("../utils/syntaxHighlight");
var _lucideReact = require("lucide-react");function _getRequireWildcardCache(nodeInterop) {if (typeof WeakMap !== "function") return null;var cacheBabelInterop = new WeakMap();var cacheNodeInterop = new WeakMap();return (_getRequireWildcardCache = function (nodeInterop) {return nodeInterop ? cacheNodeInterop : cacheBabelInterop;})(nodeInterop);}function _interopRequireWildcard(obj, nodeInterop) {if (!nodeInterop && obj && obj.__esModule) {return obj;}if (obj === null || typeof obj !== "object" && typeof obj !== "function") {return { default: obj };}var cache = _getRequireWildcardCache(nodeInterop);if (cache && cache.has(obj)) {return cache.get(obj);}var newObj = {};var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var key in obj) {if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;if (desc && (desc.get || desc.set)) {Object.defineProperty(newObj, key, desc);} else {newObj[key] = obj[key];}}}newObj.default = obj;if (cache) {cache.set(obj, newObj);}return newObj;}





const ProjectEditor = ({ project }) => {
  const [fileTree, setFileTree] = (0, _react.useState)([]);
  const [activeFile, setActiveFile] = (0, _react.useState)('index.html');
  const [fileContent, setFileContent] = (0, _react.useState)('');
  const [savedContent, setSavedContent] = (0, _react.useState)('');
  const [isBinaryFile, setIsBinaryFile] = (0, _react.useState)(false);
  const [isSaving, setIsSaving] = (0, _react.useState)(false);
  const [previewKey, setPreviewKey] = (0, _react.useState)(Date.now());
  const [statusMessage, setStatusMessage] = (0, _react.useState)(
  null);


  const [isNewFileModalOpen, setIsNewFileModalOpen] = (0, _react.useState)(false);
  const [newFilePath, setNewFilePath] = (0, _react.useState)('');

  const [pythonInspection, setPythonInspection] = (0, _react.useState)(null);
  const [isGeneratingBridge, setIsGeneratingBridge] = (0, _react.useState)(false);

  const isDirty = !isBinaryFile && fileContent !== savedContent;
  (0, _useUnsavedChanges.useUnsavedChanges)(isDirty);

  const loadTree = async () => {
    const tree = await _api.API.getFileTree(project.id);
    setFileTree(tree);
  };

  const loadPythonDiagnostics = async () => {
    if (project.type === 'python') {
      const res = await _api.API.inspectPython(project.id);
      setPythonInspection(res);
    } else {
      setPythonInspection(null);
    }
  };

  const loadContent = async (targetPath, force = false) => {
    if (!force && isDirty) {
      const proceed = window.confirm(
      `You have unsaved changes in ${activeFile}. Discard changes and open ${targetPath}?`);

      if (!proceed) return;
    }
    try {
      const res = await _api.API.getFile(project.id, targetPath);
      setActiveFile(targetPath);
      setFileContent(res.content);
      setSavedContent(res.content);
      setIsBinaryFile(Boolean(res.isBinary));
    } catch (err) {
      setStatusMessage({ text: err.message || 'Failed to read file', isError: true });
    }
  };

  (0, _react.useEffect)(() => {
    loadTree();
    loadPythonDiagnostics();
    const defaultEntry = project.type === 'python' ? 'main.py' : 'index.html';
    loadContent(defaultEntry, true);
  }, [project.id]);

  const handleSave = async () => {
    if (isBinaryFile) return;
    setIsSaving(true);
    setStatusMessage(null);
    try {
      await _api.API.saveFile(project.id, activeFile, fileContent);
      setSavedContent(fileContent);
      setPreviewKey(Date.now());
      await loadPythonDiagnostics();
      setStatusMessage({ text: `Saved ${activeFile}` });
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSingleFileUpload = async (e) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    setStatusMessage(null);
    try {
      const res = await _api.API.importSingleFile(project.id, file, file.name);
      await loadTree();
      await loadPythonDiagnostics();
      await loadContent(res.importedFile, true);
      setPreviewKey(Date.now());
      setStatusMessage({ text: `Imported ${res.importedFile}` });
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      e.target.value = '';
    }
  };

  const handleZipUpload = async (e) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    setStatusMessage(null);
    try {
      const res = await _api.API.uploadZip(project.id, file);
      await loadTree();
      await loadPythonDiagnostics();
      if (res.hasIndexHtml) {
        await loadContent('index.html', true);
      } else if (res.filesExtracted.length > 0) {
        await loadContent(res.filesExtracted[0], true);
      }
      setPreviewKey(Date.now());
      const warnNote =
      res.skippedUnsupportedFiles.length > 0 ?
      ` (Skipped ${res.skippedUnsupportedFiles.length} unsupported binary file(s))` :
      '';
      setStatusMessage({
        text: `Extracted ${res.filesExtracted.length} file(s) from archive.${warnNote}`
      });
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      e.target.value = '';
    }
  };

  const handleCreateNewFile = async (e) => {
    e.preventDefault();
    const cleaned = newFilePath.trim().replace(/^[/\\]+/, '');
    if (!cleaned) return;
    try {
      await _api.API.saveFile(project.id, cleaned, '');
      setIsNewFileModalOpen(false);
      setNewFilePath('');
      await loadTree();
      await loadContent(cleaned, true);
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    }
  };

  const handleDeleteFile = async (targetPath) => {
    try {
      await _api.API.deleteFile(project.id, targetPath);
      await loadTree();
      await loadPythonDiagnostics();
      if (activeFile === targetPath) {
        await loadContent('index.html', true);
      }
      setPreviewKey(Date.now());
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    }
  };

  const handleGeneratePythonBridge = async () => {
    setIsGeneratingBridge(true);
    try {
      const res = await _api.API.generatePythonBridge(
      project.id,
      pythonInspection?.entrypoint || 'main.py');

      setPythonInspection(res.inspection);
      await loadTree();
      setPreviewKey(Date.now());
      setStatusMessage({ text: 'Generated index.html WebView bridge for Python script.' });
    } catch (err) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      setIsGeneratingBridge(false);
    }
  };

  const currentLang = (0, _syntaxHighlight.detectLanguageFromPath)(activeFile);
  const syntaxColor = (0, _syntaxHighlight.getSyntaxAccentColor)(currentLang);
  const lineCount = fileContent.split('\n').length;

  return /*#__PURE__*/(
    _react.default.createElement("div", { className: "editor-layout" }, /*#__PURE__*/

    _react.default.createElement("div", {
      className: "glass-panel",
      style: { padding: 18, display: 'flex', flexDirection: 'column', gap: 10 } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } }, /*#__PURE__*/
    _react.default.createElement("h3", { style: { fontSize: 15, fontWeight: 600 } }, "Project Files"), /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      title: "New File",
      onClick: () => setIsNewFileModalOpen(true),
      style: {
        background: 'rgba(255,255,255,0.1)',
        border: '1px solid rgba(255,255,255,0.18)',
        borderRadius: 8,
        color: '#fff',
        padding: '5px 8px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: 4,
        fontSize: 11
      } }, /*#__PURE__*/

    _react.default.createElement(_lucideReact.FilePlus, { size: 13 }), " New")), /*#__PURE__*/



    _react.default.createElement("div", { style: { display: 'flex', flexDirection: 'column', gap: 8 } }, /*#__PURE__*/
    _react.default.createElement("label", { className: "liquid-glass-btn", style: { fontSize: 12, padding: '8px 12px', minHeight: 36 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.FileUp, { size: 15 }), " Import HTML / Asset File", /*#__PURE__*/
    _react.default.createElement("input", {
      type: "file",
      accept: ".html,.htm,.css,.js,.json,.py,.txt,.svg,.png,.jpg,.jpeg,.webp",
      onChange: handleSingleFileUpload,
      style: { display: 'none' } })), /*#__PURE__*/



    _react.default.createElement("label", { className: "liquid-glass-btn", style: { fontSize: 12, padding: '8px 12px', minHeight: 36 } }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.UploadCloud, { size: 15 }), " Import Website ZIP", /*#__PURE__*/
    _react.default.createElement("input", {
      type: "file",
      accept: ".zip",
      onChange: handleZipUpload,
      style: { display: 'none' } }))), /*#__PURE__*/




    _react.default.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        marginTop: 6,
        paddingRight: 4,
        maxHeight: 540
      } }, /*#__PURE__*/

    _react.default.createElement(_FileTreeView.FileTreeView, {
      nodes: fileTree,
      activeFile: activeFile,
      onSelectFile: (p) => loadContent(p),
      onDeleteFile: handleDeleteFile }))), /*#__PURE__*/





    _react.default.createElement("div", {
      className: "glass-panel",
      style: { flex: 1, display: 'flex', flexDirection: 'column', padding: 18 } },

    project.type === 'python' && /*#__PURE__*/
    _react.default.createElement(_PythonInspectorPanel.PythonInspectorPanel, {
      inspection: pythonInspection,
      onGenerateBridge: handleGeneratePythonBridge,
      isGeneratingBridge: isGeneratingBridge }), /*#__PURE__*/



    _react.default.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10,
        marginBottom: 12
      } }, /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 10 } }, /*#__PURE__*/
    _react.default.createElement("span", { style: { fontSize: 14, fontWeight: 600 } }, activeFile), /*#__PURE__*/
    _react.default.createElement("span", {
      style: {
        fontSize: 11,
        padding: '2px 8px',
        borderRadius: 6,
        background: 'rgba(255,255,255,0.1)',
        color: syntaxColor
      } },

    currentLang, " \u2022 ", lineCount, " lines"),

    isDirty && /*#__PURE__*/
    _react.default.createElement("span", {
      style: {
        fontSize: 11,
        padding: '2px 8px',
        borderRadius: 6,
        background: 'rgba(254, 202, 87, 0.2)',
        color: '#feca57',
        fontWeight: 600
      } },
    "Unsaved edits")), /*#__PURE__*/





    _react.default.createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 10 } },
    statusMessage && /*#__PURE__*/
    _react.default.createElement("span", {
      style: {
        fontSize: 12,
        color: statusMessage.isError ? '#ff6b6b' : '#00ffc8'
      } },

    statusMessage.text), /*#__PURE__*/


    _react.default.createElement("div", { style: { width: 130 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { onClick: handleSave, disabled: isSaving || isBinaryFile }, /*#__PURE__*/
    _react.default.createElement(_lucideReact.Save, { size: 15 }), " ", isSaving ? 'Saving...' : 'Save File')))), /*#__PURE__*/





    _react.default.createElement("textarea", {
      value: fileContent,
      disabled: isBinaryFile,
      onChange: (e) => setFileContent(e.target.value),
      spellCheck: false,
      style: {
        flex: 1,
        minHeight: 420,
        width: '100%',
        background: 'rgba(0, 0, 0, 0.36)',
        color: syntaxColor,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
        fontSize: 13.5,
        lineHeight: 1.55,
        padding: 16,
        borderRadius: 14,
        border: '1px solid rgba(255,255,255,0.12)',
        outline: 'none',
        resize: 'none'
      } })), /*#__PURE__*/




    _react.default.createElement(_LivePreviewPane.LivePreviewPane, {
      projectId: project.id,
      previewKey: previewKey,
      onRefresh: () => setPreviewKey(Date.now()) }), /*#__PURE__*/



    _react.default.createElement(_GlassModal.GlassModal, {
      isOpen: isNewFileModalOpen,
      title: "Create New File",
      onClose: () => setIsNewFileModalOpen(false) }, /*#__PURE__*/

    _react.default.createElement("form", { onSubmit: handleCreateNewFile }, /*#__PURE__*/
    _react.default.createElement("label", { style: { fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 } }, "Relative File Path (e.g. ", /*#__PURE__*/
    _react.default.createElement("code", null, "pages/about.html"), " or ", /*#__PURE__*/_react.default.createElement("code", null, "js/utils.js"), ")"), /*#__PURE__*/

    _react.default.createElement("input", {
      className: "glass-input",
      placeholder: "styles/custom.css",
      value: newFilePath,
      onChange: (e) => setNewFilePath(e.target.value),
      autoFocus: true,
      style: { marginBottom: 18 } }), /*#__PURE__*/

    _react.default.createElement("div", { style: { display: 'flex', gap: 12 } }, /*#__PURE__*/
    _react.default.createElement(_GlassButton.GlassButton, { type: "submit" }, "Create File"), /*#__PURE__*/
    _react.default.createElement("button", {
      type: "button",
      onClick: () => setIsNewFileModalOpen(false),
      style: {
        flex: 1,
        background: 'transparent',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 14,
        color: 'rgba(255,255,255,0.75)',
        cursor: 'pointer'
      } },
    "Cancel"))))));







};exports.ProjectEditor = ProjectEditor;
},
"./services/api": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.API = void 0;








var _localEngine = require("./localEngine");

function getApiBaseUrl() {
  const custom = _localEngine.LocalEngine.getRemoteBackendUrl();
  if (custom) {
    return custom.endsWith('/api') ? custom : `${custom}/api`;
  }
  return '/api';
}

function isFileProtocolWithoutRemote() {
  if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
    return !_localEngine.LocalEngine.getRemoteBackendUrl();
  }
  return false;
}

async function fetchBackendOrFallback(
pathSuffix,
options,
fallbackFn)
{
  if (isFileProtocolWithoutRemote()) {
    return await fallbackFn();
  }
  try {
    const res = await fetch(`${getApiBaseUrl()}${pathSuffix}`, options);
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return await fallbackFn();
    }
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `Request failed with status ${res.status}`);
    }
    return data;
  } catch (err) {
    // If network/fetch fails because backend server isn't running locally, use LocalEngine
    if (
    err instanceof TypeError ||
    err?.message && (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')))
    {
      return await fallbackFn();
    }
    throw err;
  }
}

const API = {
  getRemoteBackendUrl: () => _localEngine.LocalEngine.getRemoteBackendUrl(),
  setRemoteBackendUrl: (url) => _localEngine.LocalEngine.setRemoteBackendUrl(url),
  isStandaloneWebViewMode: () => isFileProtocolWithoutRemote(),

  async getSystemDiagnostics()



  {
    return fetchBackendOrFallback('/system/diagnostics', undefined, () =>
    _localEngine.LocalEngine.getSystemDiagnostics());

  },

  async listProjects() {
    return fetchBackendOrFallback('/projects', undefined, () => _localEngine.LocalEngine.listProjects());
  },

  async createProject(name, type) {
    return fetchBackendOrFallback(
    '/projects',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, type })
    },
    () => _localEngine.LocalEngine.createProject(name, type));

  },

  async getProject(id)



  {
    return fetchBackendOrFallback(`/projects/${id}`, undefined, () => _localEngine.LocalEngine.getProject(id));
  },

  async renameProject(id, name) {
    return fetchBackendOrFallback(
    `/projects/${id}`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    },
    () => _localEngine.LocalEngine.renameProject(id, name));

  },

  async duplicateProject(id, name) {
    return fetchBackendOrFallback(
    `/projects/${id}/duplicate`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    },
    () => _localEngine.LocalEngine.duplicateProject(id, name));

  },

  async updateCustomization(
  id,
  settings)
  {
    return fetchBackendOrFallback(
    `/projects/${id}/customization`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    },
    () => _localEngine.LocalEngine.updateCustomization(id, settings));

  },

  async updateAnimations(
  id,
  animations)
  {
    return fetchBackendOrFallback(
    `/projects/${id}/animations`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(animations)
    },
    () => _localEngine.LocalEngine.updateAnimations(id, animations));

  },

  async deleteProject(id) {
    await fetchBackendOrFallback(
    `/projects/${id}`,
    { method: 'DELETE' },
    () => {
      _localEngine.LocalEngine.deleteProject(id);
    });

  },

  async getFileTree(projectId) {
    return fetchBackendOrFallback(`/projects/${projectId}/files`, undefined, () =>
    _localEngine.LocalEngine.getFileTree(projectId));

  },

  async getFile(
  projectId,
  filePath)
  {
    return fetchBackendOrFallback(
    `/projects/${projectId}/file?path=${encodeURIComponent(filePath)}`,
    undefined,
    () => _localEngine.LocalEngine.getFile(projectId, filePath));

  },

  async saveFile(projectId, filePath, content) {
    await fetchBackendOrFallback(
    `/projects/${projectId}/file`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: filePath, content })
    },
    () => {
      _localEngine.LocalEngine.saveFile(projectId, filePath, content);
    });

  },

  async deleteFile(projectId, filePath) {
    await fetchBackendOrFallback(
    `/projects/${projectId}/file?path=${encodeURIComponent(filePath)}`,
    { method: 'DELETE' },
    () => {
      _localEngine.LocalEngine.deleteFile(projectId, filePath);
    });

  },

  async importSingleFile(
  projectId,
  file,
  targetPath)
  {
    const formData = new FormData();
    formData.append('file', file);
    if (targetPath) formData.append('targetPath', targetPath);
    return fetchBackendOrFallback(
    `/projects/${projectId}/import-file`,
    {
      method: 'POST',
      body: formData
    },
    () => _localEngine.LocalEngine.importSingleFile(projectId, file, targetPath));

  },

  async uploadZip(
  projectId,
  file)







  {
    const formData = new FormData();
    formData.append('zipfile', file);
    return fetchBackendOrFallback(
    `/projects/${projectId}/upload-zip`,
    {
      method: 'POST',
      body: formData
    },
    () => _localEngine.LocalEngine.uploadZip(projectId, file));

  },

  async inspectPython(projectId) {
    return fetchBackendOrFallback(`/projects/${projectId}/python-inspect`, undefined, () =>
    _localEngine.LocalEngine.inspectPython(projectId));

  },

  async generatePythonBridge(
  projectId,
  entrypoint)
  {
    return fetchBackendOrFallback(
    `/projects/${projectId}/python-bridge`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entrypoint })
    },
    () => _localEngine.LocalEngine.generatePythonBridge(projectId, entrypoint));

  },

  async triggerBuild(
  projectId,
  buildType = 'debug')
  {
    return fetchBackendOrFallback(
    `/projects/${projectId}/builds`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ buildType })
    },
    () => _localEngine.LocalEngine.triggerBuild(projectId, buildType));

  },

  async getBuildStatus(buildId) {
    return fetchBackendOrFallback(`/builds/${buildId}`, undefined, () =>
    _localEngine.LocalEngine.getBuildStatus(buildId));

  },

  async listBuilds(projectId) {
    return fetchBackendOrFallback(`/projects/${projectId}/builds`, undefined, () =>
    _localEngine.LocalEngine.listBuilds(projectId));

  },

  compileLivePreviewSrcDoc(projectId) {
    return _localEngine.LocalEngine.compileLivePreviewSrcDoc(projectId);
  },

  async exportAndroidGradleProject(buildId) {
    if (isFileProtocolWithoutRemote()) {
      _localEngine.LocalEngine.exportPreparedProjectZip(buildId);
      return;
    }
    try {
      const res = await fetch(`${getApiBaseUrl()}/builds/${buildId}/export-project`);
      if (!res.ok) {
        _localEngine.LocalEngine.exportPreparedProjectZip(buildId);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `android-project-${buildId.substring(0, 8)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch {
      _localEngine.LocalEngine.exportPreparedProjectZip(buildId);
    }
  }
};exports.API = API;
},
"./services/localEngine": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.SUPPORTED_PERMISSIONS_LIST = exports.LocalEngine = void 0;exports.buildZipUint8Array = buildZipUint8Array;








var _validation = require("../utils/validation");

const STORAGE_KEY = 'apk_studio_workspace_v2';
const BACKEND_URL_KEY = 'apk_studio_remote_backend_url';










const BINARY_EXTS = new Set([
'.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.bmp',
'.woff', '.woff2', '.ttf', '.otf', '.eot',
'.mp3', '.wav', '.ogg', '.mp4', '.webm', '.pdf', '.zip', '.apk']);


const UNSUPPORTED_EXTS = new Set([
'.exe', '.dll', '.msi', '.bat', '.cmd', '.com', '.scr', '.vbs', '.dmg', '.pkg']);


const PROHIBITED_PY_MODULES = {
  tkinter: 'Desktop Tk GUI cannot render inside an Android WebView.',
  _tkinter: 'Internal Tk C-extension is unavailable on Android.',
  turtle: 'Turtle graphics depends on a desktop X11/Tk window server.',
  win32api: 'Windows native Win32 APIs cannot execute on Linux/Android.',
  win32con: 'Windows native constants/APIs are incompatible with Android.',
  winreg: 'Windows Registry API is unavailable on Android.',
  msvcrt: 'Microsoft Visual C++ runtime console I/O is Windows-only.',
  curses: 'Terminal ncurses interfaces cannot render directly in Android WebView.',
  pygame: 'Pygame requires an SDL2 surface; use HTML5 Canvas or an SDL2 Android port.',
  pyqt5: 'Desktop Qt5 bindings are not supported in WebView hybrid containers.',
  pyqt6: 'Desktop Qt6 bindings are not supported in WebView hybrid containers.',
  pyside2: 'Desktop Qt bindings are not supported in WebView hybrid containers.',
  pyside6: 'Desktop Qt bindings are not supported in WebView hybrid containers.',
  wx: 'wxPython desktop GUI requires native desktop windowing.',
  gtk: 'GTK desktop bindings are not supported on Android.'
};

const NATIVE_WHEEL_PACKAGES = {
  numpy: 'Requires Chaquopy or Pyodide prebuilt native Android wheel.',
  pandas: 'Requires Chaquopy/Pyodide native wheel; increases APK size.',
  scipy: 'Heavy Fortran/C++ extensions; verify Chaquopy wheel availability.',
  cv2: 'OpenCV requires native Android .so libraries or OpenCV.js.',
  'opencv-python': 'OpenCV requires native Android .so libraries or OpenCV.js.',
  pil: 'Pillow requires native image codecs (supported via Chaquopy/Pyodide).',
  pillow: 'Pillow requires native image codecs (supported via Chaquopy/Pyodide).',
  cryptography: 'Requires Rust/OpenSSL prebuilt Android binaries.',
  torch: 'PyTorch Mobile / ExecuTorch required instead of desktop torch.',
  tensorflow: 'TensorFlow Lite required on Android instead of full tensorflow.'
};

const SUPPORTED_PERMISSIONS_LIST = [
'android.permission.INTERNET',
'android.permission.ACCESS_NETWORK_STATE',
'android.permission.ACCESS_WIFI_STATE',
'android.permission.CAMERA',
'android.permission.RECORD_AUDIO',
'android.permission.MODIFY_AUDIO_SETTINGS',
'android.permission.ACCESS_FINE_LOCATION',
'android.permission.ACCESS_COARSE_LOCATION',
'android.permission.VIBRATE',
'android.permission.WAKE_LOCK',
'android.permission.POST_NOTIFICATIONS',
'android.permission.READ_EXTERNAL_STORAGE',
'android.permission.WRITE_EXTERNAL_STORAGE'];exports.SUPPORTED_PERMISSIONS_LIST = SUPPORTED_PERMISSIONS_LIST;


function randomId() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}

function defaultStarterFiles(projectName, type) {
  if (type === 'python') {
    return {
      'main.py': `# APK STUDIO Python Entrypoint\nimport json\nimport math\n\ndef compute_metrics():\n    return {\n        "app": "${projectName}",\n        "pi_estimate": round(math.pi, 6),\n        "status": "ready"\n    }\n\ndef run():\n    print("Initializing ${projectName} Python runtime...")\n    print(json.dumps(compute_metrics()))\n\nif __name__ == "__main__":\n    run()\n`,
      'requirements.txt': '# Declare pure-Python or Chaquopy-supported packages here (one per line)\n',
      'index.html': generatePythonBridgeHtml(projectName, 'main.py', `print("Initializing ${projectName} Python runtime...")`)
    };
  }
  return {
    'index.html': `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${projectName}</title>\n  <link rel="stylesheet" href="style.css" />\n</head>\n<body>\n  <div class="card">\n    <div class="badge">APK STUDIO • HTML5 Hybrid</div>\n    <h1>Welcome to ${projectName}</h1>\n    <p>Edit <code>index.html</code>, <code>style.css</code>, and <code>script.js</code> or import a complete website ZIP archive.</p>\n    <button id="action-btn" class="btn">Test Interactive Action</button>\n    <div id="status-box" class="status-box">Ready inside Android WebView Sandbox.</div>\n  </div>\n  <script src="script.js"></script>\n</body>\n</html>\n`,
    'style.css': `* { box-sizing: border-box; margin: 0; padding: 0; }\nbody {\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;\n  min-height: 100vh;\n  padding: 24px;\n  background: linear-gradient(135deg, #1f1c2c 0%, #3a3456 50%, #24243e 100%);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.card {\n  width: 100%;\n  max-width: 380px;\n  padding: 28px 24px;\n  border-radius: 22px;\n  background: rgba(255, 255, 255, 0.08);\n  backdrop-filter: blur(20px);\n  -webkit-backdrop-filter: blur(20px);\n  border: 1px solid rgba(255, 255, 255, 0.15);\n  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35);\n  text-align: center;\n}\n.badge {\n  display: inline-block;\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n  padding: 4px 10px;\n  border-radius: 999px;\n  background: rgba(0, 255, 200, 0.15);\n  color: #00ffc8;\n  margin-bottom: 14px;\n}\nh1 { font-size: 22px; margin-bottom: 10px; }\np { font-size: 13px; color: rgba(255, 255, 255, 0.75); line-height: 1.5; margin-bottom: 20px; }\n.btn {\n  width: 100%;\n  padding: 12px 18px;\n  border-radius: 12px;\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  background: rgba(255, 255, 255, 0.14);\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 600;\n  cursor: pointer;\n}\n.status-box {\n  margin-top: 16px;\n  padding: 10px;\n  border-radius: 10px;\n  background: rgba(0, 0, 0, 0.3);\n  font-size: 12px;\n  color: #00ffc8;\n}\n`,
    'script.js': `document.addEventListener("DOMContentLoaded", () => {\n  console.log("[APK STUDIO] ${projectName} initialized.");\n  const btn = document.getElementById("action-btn");\n  const statusBox = document.getElementById("status-box");\n  let clicks = 0;\n  if (btn && statusBox) {\n    btn.addEventListener("click", () => {\n      clicks += 1;\n      const msg = "Interaction #" + clicks + " at " + new Date().toLocaleTimeString();\n      statusBox.textContent = msg;\n      console.log(msg);\n    });\n  }\n});\n`
  };
}

function generatePythonBridgeHtml(projectName, entrypoint, pyCode) {
  const esc = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(projectName)} — Python Runtime Bridge</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(135deg, #1f1c2c 0%, #3a3456 50%, #24243e 100%);
      color: #ffffff;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .card {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 18px;
      padding: 20px;
    }
    .badge {
      display: inline-block;
      font-size: 11px;
      text-transform: uppercase;
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(0, 255, 200, 0.15);
      color: #00ffc8;
      margin-bottom: 10px;
    }
    .btn {
      margin-top: 12px;
      padding: 10px 16px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.25);
      background: rgba(255, 255, 255, 0.14);
      color: #fff;
      font-weight: 600;
      cursor: pointer;
    }
    pre {
      background: rgba(0, 0, 0, 0.45);
      border-radius: 12px;
      padding: 14px;
      font-family: monospace;
      font-size: 12px;
      color: #00ffc8;
      white-space: pre-wrap;
    }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">Python Hybrid Bridge • ${esc(entrypoint)}</span>
    <h1 style="font-size:20px;margin-bottom:6px;">${esc(projectName)}</h1>
    <p style="font-size:13px;color:rgba(255,255,255,0.75);">Embedded Python script packaged for Android WebView execution.</p>
    <button class="btn" onclick="runPythonSimulation()">▶ Execute ${esc(entrypoint)}</button>
  </div>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:8px;">Console Output</h2>
    <pre id="output-console">Ready.</pre>
  </div>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:8px;">Bundled Source (${esc(entrypoint)})</h2>
    <pre id="python-source">${esc(pyCode)}</pre>
  </div>
  <script>
    function runPythonSimulation() {
      var out = document.getElementById('output-console');
      var src = document.getElementById('python-source').textContent || '';
      var lines = ['[Python Runtime] Executing ${esc(entrypoint)}...'];
      var regex = /print\\s*\\(\\s*(?:f?["']([^"']*)["']|([^)]+))\\s*\\)/g;
      var m;
      while ((m = regex.exec(src)) !== null) {
        lines.push(m[1] !== undefined ? m[1] : String(m[2]));
      }
      if (lines.length === 1) lines.push('[Python Runtime] Script completed with exit code 0.');
      out.textContent = lines.join('\\n');
      console.log('[PythonBridge] Execution finished:', lines.join(' | '));
    }
    window.addEventListener('DOMContentLoaded', runPythonSimulation);
  </script>
</body>
</html>`;
}

function generateAnimationStylesheet(anim) {
  const pulseDuration = Number(anim?.pulse_duration_s) || 2.0;
  const glassBlur = Number(anim?.glass_blur_px) ?? 30;
  const pageTransition = anim?.page_transition || 'fade';
  const buttonEffect = anim?.button_effect || 'scale-press';

  let transitionCss = '';
  if (pageTransition === 'fade') {
    transitionCss = 'body { animation: apkStudioFadeIn 0.45s cubic-bezier(0.16, 1, 0.3, 1); }';
  } else if (pageTransition === 'slide-up') {
    transitionCss = 'body { animation: apkStudioSlideUp 0.45s cubic-bezier(0.16, 1, 0.3, 1); }';
  } else if (pageTransition === 'zoom') {
    transitionCss = 'body { animation: apkStudioZoomIn 0.4s cubic-bezier(0.16, 1, 0.3, 1); }';
  }

  let buttonCss = '';
  if (buttonEffect === 'scale-press') {
    buttonCss = 'button, .btn, input[type="submit"] { transition: transform 0.15s ease; } button:active, .btn:active { transform: scale(0.96); }';
  } else if (buttonEffect === 'glow-hover') {
    buttonCss = 'button, .btn { transition: box-shadow 0.25s ease, transform 0.2s ease; } button:active, .btn:active { box-shadow: 0 0 18px rgba(0, 255, 200, 0.55); transform: translateY(-1px); }';
  } else if (buttonEffect === 'ripple') {
    buttonCss = 'button, .btn { position: relative; overflow: hidden; transition: background 0.2s ease; } button:active, .btn:active { opacity: 0.85; }';
  }

  return `/* Auto-generated by APK STUDIO Animation Studio */
:root {
  --apk-studio-pulse-duration: ${pulseDuration}s;
  --apk-studio-glass-blur: ${glassBlur}px;
}
@keyframes apkStudioFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes apkStudioSlideUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
@keyframes apkStudioZoomIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
@keyframes apkStudioPulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.04); opacity: 0.88; } }
.apk-studio-glass { backdrop-filter: blur(${glassBlur}px) saturate(180%); -webkit-backdrop-filter: blur(${glassBlur}px) saturate(180%); }
.apk-studio-pulse { animation: apkStudioPulse ${pulseDuration}s ease-in-out infinite; }
${transitionCss}
${buttonCss}
`;
}

let memoryWorkspace = null;

function loadWorkspace() {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      parsed.preparedAndroidProjects = parsed.preparedAndroidProjects || {};
      return parsed;
    }
  } catch {

    // ignore storage read error
  }if (memoryWorkspace) return memoryWorkspace;

  const starterId = 'default-liquid-showcase';
  const now = new Date().toISOString();
  const initial = {
    projects: [
    {
      id: starterId,
      name: 'Liquid Glass Showcase',
      type: 'html',
      status: 'ready',
      created_at: now,
      updated_at: now,
      app_name: 'Liquid Glass Showcase',
      package_id: 'com.apkstudio.liquidshowcase',
      version_name: '1.0.0',
      version_code: 1,
      last_build_status: null
    }],

    customizations: {
      [starterId]: {
        app_name: 'Liquid Glass Showcase',
        package_id: 'com.apkstudio.liquidshowcase',
        version_name: '1.0.0',
        version_code: 1,
        orientation: 'portrait',
        fullscreen: false,
        status_bar_color: '#1f1c2c',
        nav_bar_color: '#1f1c2c',
        light_status_bar: false,
        theme_color: '#6c5ce7',
        background_color: '#1f1c2c',
        offline_mode: 'cache_first',
        allow_cleartext: true,
        enable_zoom: false,
        keep_screen_on: false,
        splash_enabled: true,
        splash_color: '#1f1c2c',
        splash_duration_ms: 1500,
        splash_animation: 'fade',
        icon_data_url: null,
        splash_image_data_url: null,
        permissions: ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']
      }
    },
    animations: {
      [starterId]: {
        splash_animation: 'fade',
        splash_duration_ms: 1500,
        pulse_duration_s: 2.0,
        glass_blur_px: 30,
        page_transition: 'fade',
        loader_style: 'spinner',
        button_effect: 'scale-press',
        inject_stylesheet: true
      }
    },
    files: {
      [starterId]: defaultStarterFiles('Liquid Glass Showcase', 'html')
    },
    builds: {},
    preparedAndroidProjects: {}
  };
  saveWorkspace(initial);
  return initial;
}

function saveWorkspace(ws) {
  memoryWorkspace = ws;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(ws));
    }
  } catch {

    // ignore quota error
  }}

function normalizeRelPath(filePath) {
  const cleaned = String(filePath || '').
  replace(/\\/g, '/').
  replace(/^\/+/, '');
  if (!cleaned || cleaned.includes('\0')) {
    throw new Error('Invalid file path.');
  }
  const parts = cleaned.split('/');
  for (const part of parts) {
    if (part === '..') {
      throw new Error('Access denied: Path traversal detected.');
    }
  }
  return parts.filter(Boolean).join('/');
}

function getExt(p) {
  const idx = p.lastIndexOf('.');
  return idx >= 0 ? p.slice(idx).toLowerCase() : '';
}

/**
 * Pure JavaScript CRC32 & ZIP Archive Builder so users can export real `.zip`
 * Android Gradle projects directly from inside the Android WebView or browser.
 */
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ c >>> 1 : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ crc >>> 8;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function buildZipUint8Array(filesMap) {
  const encoder = new TextEncoder();
  const entries =




  [];

  let offset = 0;
  const localChunks = [];

  for (const [relPath, content] of Object.entries(filesMap)) {
    const nameBytes = encoder.encode(relPath);
    let dataBytes;
    if (content.startsWith('data:') && content.includes(';base64,')) {
      const b64 = content.split(';base64,')[1] || '';
      const binStr = atob(b64);
      dataBytes = new Uint8Array(binStr.length);
      for (let i = 0; i < binStr.length; i++) dataBytes[i] = binStr.charCodeAt(i);
    } else {
      dataBytes = encoder.encode(content);
    }

    const crc = crc32(dataBytes);
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const view = new DataView(localHeader.buffer);
    view.setUint32(0, 0x04034b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 0, true);
    view.setUint16(8, 0, true); // STORED
    view.setUint16(10, 0, true);
    view.setUint16(12, 0x21, true);
    view.setUint32(14, crc, true);
    view.setUint32(18, dataBytes.length, true);
    view.setUint32(22, dataBytes.length, true);
    view.setUint16(26, nameBytes.length, true);
    view.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    entries.push({ nameBytes, dataBytes, crc, offset });
    localChunks.push(localHeader, dataBytes);
    offset += localHeader.length + dataBytes.length;
  }

  const centralChunks = [];
  let centralSize = 0;
  for (const entry of entries) {
    const cHeader = new Uint8Array(46 + entry.nameBytes.length);
    const view = new DataView(cHeader.buffer);
    view.setUint32(0, 0x02014b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 20, true);
    view.setUint16(8, 0, true);
    view.setUint16(10, 0, true);
    view.setUint16(12, 0, true);
    view.setUint16(14, 0x21, true);
    view.setUint32(16, entry.crc, true);
    view.setUint32(20, entry.dataBytes.length, true);
    view.setUint32(24, entry.dataBytes.length, true);
    view.setUint16(28, entry.nameBytes.length, true);
    view.setUint16(30, 0, true);
    view.setUint16(32, 0, true);
    view.setUint16(34, 0, true);
    view.setUint16(36, 0, true);
    view.setUint32(38, 0, true);
    view.setUint32(42, entry.offset, true);
    cHeader.set(entry.nameBytes, 46);
    centralChunks.push(cHeader);
    centralSize += cHeader.length;
  }

  const eocd = new Uint8Array(22);
  const eView = new DataView(eocd.buffer);
  eView.setUint32(0, 0x06054b50, true);
  eView.setUint16(4, 0, true);
  eView.setUint16(6, 0, true);
  eView.setUint16(8, entries.length, true);
  eView.setUint16(10, entries.length, true);
  eView.setUint32(12, centralSize, true);
  eView.setUint32(16, offset, true);
  eView.setUint16(20, 0, true);

  const totalLen = offset + centralSize + 22;
  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const chunk of localChunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  for (const chunk of centralChunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  out.set(eocd, pos);
  return out;
}

/**
 * Pure browser/WebView binary ZIP reader supporting STORED (0) and DEFLATE (8).
 */
async function extractZipBuffer(buffer)




{
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  if (bytes.length < 22 || view.getUint32(0, true) !== 0x04034b50) {
    throw new Error('Corrupted or invalid ZIP archive.');
  }

  // Locate End of Central Directory (0x06054b50)
  let eocdOffset = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset === -1) {
    throw new Error('Invalid ZIP archive: End of Central Directory not found.');
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const cdOffset = view.getUint32(eocdOffset + 16, true);
  const decoder = new TextDecoder('utf-8');

  const rawEntries = [];
  const skippedUnsupportedFiles = [];
  let ptr = cdOffset;

  for (let idx = 0; idx < totalEntries; idx++) {
    if (ptr + 46 > bytes.length || view.getUint32(ptr, true) !== 0x02014b50) break;
    const compressionMethod = view.getUint16(ptr + 10, true);
    const compressedSize = view.getUint32(ptr + 20, true);
    const nameLen = view.getUint16(ptr + 28, true);
    const extraLen = view.getUint16(ptr + 30, true);
    const commentLen = view.getUint16(ptr + 32, true);
    const localHeaderOffset = view.getUint32(ptr + 42, true);

    const rawName = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + nameLen)).replace(/\\/g, '/');
    ptr += 46 + nameLen + extraLen + commentLen;

    if (rawName.startsWith('__MACOSX/') || rawName.endsWith('.DS_Store')) continue;
    if (rawName.startsWith('/') || rawName.includes('../') || rawName.startsWith('..')) {
      throw new Error(`Malicious zip entry path detected: ${rawName}`);
    }
    if (rawName.endsWith('/')) continue;

    const ext = getExt(rawName);
    if (UNSUPPORTED_EXTS.has(ext)) {
      skippedUnsupportedFiles.push(rawName);
      continue;
    }

    const localNameLen = view.getUint16(localHeaderOffset + 26, true);
    const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
    const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
    const compressedSlice = bytes.subarray(dataStart, dataStart + compressedSize);

    let uncompressedBytes;
    if (compressionMethod === 0) {
      uncompressedBytes = compressedSlice;
    } else if (compressionMethod === 8 && typeof DecompressionStream !== 'undefined') {
      const ds = new DecompressionStream('deflate-raw');
      const writer = ds.writable.getWriter();
      writer.write(compressedSlice);
      writer.close();
      const resp = new Response(ds.readable);
      uncompressedBytes = new Uint8Array(await resp.arrayBuffer());
    } else {
      throw new Error(`Unsupported ZIP compression method (${compressionMethod}) for ${rawName}`);
    }

    let contentStr;
    if (BINARY_EXTS.has(ext)) {
      let binary = '';
      for (let i = 0; i < uncompressedBytes.length; i++) {
        binary += String.fromCharCode(uncompressedBytes[i]);
      }
      contentStr = `data:application/octet-stream;base64,${btoa(binary)}`;
    } else {
      contentStr = decoder.decode(uncompressedBytes);
    }

    rawEntries.push({ path: rawName, content: contentStr });
  }

  const topHasIndex = rawEntries.some((e) => e.path.toLowerCase() === 'index.html');
  const hasRootFiles = rawEntries.some((e) => !e.path.includes('/'));
  const firstSegments = new Set(
  rawEntries.filter((e) => e.path.includes('/')).map((e) => e.path.split('/')[0]));


  let flattenedRoot = false;
  let prefix = '';
  if (!topHasIndex && !hasRootFiles && firstSegments.size === 1) {
    flattenedRoot = true;
    prefix = `${Array.from(firstSegments)[0]}/`;
  }

  const files = {};
  const extractedFiles = [];
  for (const item of rawEntries) {
    const finalPath = flattenedRoot && item.path.startsWith(prefix) ?
    item.path.slice(prefix.length) :
    item.path;
    if (!finalPath) continue;
    files[finalPath] = item.content;
    extractedFiles.push(finalPath);
  }

  return { files, extractedFiles, skippedUnsupportedFiles, flattenedRoot };
}

const LocalEngine = {
  getRemoteBackendUrl() {
    try {
      return typeof localStorage !== 'undefined' && localStorage.getItem(BACKEND_URL_KEY) || '';
    } catch {
      return '';
    }
  },

  setRemoteBackendUrl(url) {
    try {
      if (typeof localStorage !== 'undefined') {
        const cleaned = url.trim().replace(/\/+$/, '');
        if (cleaned) localStorage.setItem(BACKEND_URL_KEY, cleaned);else
        localStorage.removeItem(BACKEND_URL_KEY);
      }
    } catch {

      // ignore
    }},

  getSystemDiagnostics()



  {
    return {
      status: 'on-device-webview',
      toolchain: {
        readyForNativeBuild: false,
        javaAvailable: false,
        javaVersion: null,
        javacAvailable: false,
        javacVersion: null,
        androidSdkAvailable: false,
        androidHomePath: '/opt/android-sdk',
        platform34Installed: false,
        buildToolsInstalled: false,
        gradleAvailable: false,
        gradleVersion: null,
        missingComponents: [
        'Remote Build Server or Host Android SDK (running in On-Device Standalone Mode)'],

        setupInstructions: [
        'Click "Export Android Gradle Project (.zip)" below to download the ready-to-compile Android project with GitHub Actions & Gradle Wrapper.',
        'Or configure a Remote Build Server URL in the top header bar to delegate Gradle compilation to a workstation or Docker host.']

      },
      supportedPermissions: SUPPORTED_PERMISSIONS_LIST
    };
  },

  listProjects() {
    const ws = loadWorkspace();
    return ws.projects.slice().sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  },

  createProject(name, type) {
    const trimmed = (name || '').trim();
    if (!trimmed || !['html', 'python'].includes(type)) {
      throw new Error("Valid project name and type ('html' or 'python') are required.");
    }
    const ws = loadWorkspace();
    const id = randomId();
    const now = new Date().toISOString();
    const cleanPkg = trimmed.toLowerCase().replace(/[^a-z0-9]/g, '');
    const safeSeg = cleanPkg && /^[a-z]/.test(cleanPkg) ? cleanPkg : `app${cleanPkg}`;
    const packageId = `com.apkstudio.${safeSeg}`;

    const project = {
      id,
      name: trimmed,
      type,
      status: 'ready',
      created_at: now,
      updated_at: now,
      app_name: trimmed,
      package_id: packageId,
      version_name: '1.0.0',
      version_code: 1,
      last_build_status: null
    };

    ws.projects.unshift(project);
    ws.customizations[id] = {
      app_name: trimmed,
      package_id: packageId,
      version_name: '1.0.0',
      version_code: 1,
      orientation: 'portrait',
      fullscreen: false,
      status_bar_color: '#1f1c2c',
      nav_bar_color: '#1f1c2c',
      light_status_bar: false,
      theme_color: '#6c5ce7',
      background_color: '#1f1c2c',
      offline_mode: 'cache_first',
      allow_cleartext: true,
      enable_zoom: false,
      keep_screen_on: false,
      splash_enabled: true,
      splash_color: '#1f1c2c',
      splash_duration_ms: 1500,
      splash_animation: 'fade',
      icon_data_url: null,
      splash_image_data_url: null,
      permissions: ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']
    };
    ws.animations[id] = {
      splash_animation: 'fade',
      splash_duration_ms: 1500,
      pulse_duration_s: 2.0,
      glass_blur_px: 30,
      page_transition: 'fade',
      loader_style: 'spinner',
      button_effect: 'scale-press',
      inject_stylesheet: true
    };
    ws.files[id] = defaultStarterFiles(trimmed, type);
    saveWorkspace(ws);
    return project;
  },

  getProject(id)



  {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    return {
      project,
      customization: ws.customizations[id],
      animations: ws.animations[id]
    };
  },

  renameProject(id, name) {
    const trimmed = (name || '').trim();
    if (!trimmed) throw new Error('A non-empty project name is required.');
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    project.name = trimmed;
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return project;
  },

  duplicateProject(id, customName) {
    const ws = loadWorkspace();
    const src = ws.projects.find((p) => p.id === id);
    if (!src) throw new Error('Source project not found');
    const newId = randomId();
    const now = new Date().toISOString();
    const newName = customName && customName.trim() || `${src.name} (Copy)`;
    const suffix = Math.random().toString(36).substring(2, 6);
    const srcCust = ws.customizations[id];
    const newPkg = `${srcCust?.package_id || 'com.apkstudio.app'}copy${suffix}`;

    const duplicated = {
      ...src,
      id: newId,
      name: newName,
      app_name: newName,
      package_id: newPkg,
      created_at: now,
      updated_at: now,
      last_build_status: null
    };

    ws.projects.unshift(duplicated);
    ws.customizations[newId] = {
      ...srcCust,
      app_name: newName,
      package_id: newPkg
    };
    ws.animations[newId] = { ...ws.animations[id] };
    ws.files[newId] = { ...(ws.files[id] || {}) };
    saveWorkspace(ws);
    return duplicated;
  },

  updateCustomization(
  id,
  settings)
  {
    const errs = (0, _validation.validateCustomizationClient)(settings);
    if (errs.length > 0) {
      throw new Error(errs.join(' '));
    }
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    ws.customizations[id] = { ...settings };
    project.app_name = settings.app_name;
    project.package_id = settings.package_id;
    project.version_name = settings.version_name;
    project.version_code = settings.version_code;
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return { success: true, customization: ws.customizations[id] };
  },

  updateAnimations(
  id,
  animations)
  {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    ws.animations[id] = { ...animations };
    if (ws.customizations[id]) {
      ws.customizations[id].splash_animation = animations.splash_animation;
      ws.customizations[id].splash_duration_ms = animations.splash_duration_ms;
    }
    if (animations.inject_stylesheet !== false) {
      ws.files[id] = ws.files[id] || {};
      ws.files[id]['apk_studio_animations.css'] = generateAnimationStylesheet(animations);
    }
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return { success: true, animations: ws.animations[id] };
  },

  deleteProject(id) {
    const ws = loadWorkspace();
    ws.projects = ws.projects.filter((p) => p.id !== id);
    delete ws.customizations[id];
    delete ws.animations[id];
    delete ws.files[id];
    for (const [bId, b] of Object.entries(ws.builds)) {
      if (b.project_id === id) {
        delete ws.builds[bId];
        delete ws.preparedAndroidProjects[bId];
      }
    }
    saveWorkspace(ws);
  },

  getFileTree(projectId) {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    const rootNodes = [];

    for (const [relPath, content] of Object.entries(fileMap)) {
      const parts = relPath.split('/').filter(Boolean);
      let currentLevel = rootNodes;
      let builtPath = '';

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        builtPath = builtPath ? `${builtPath}/${part}` : part;
        const isLast = i === parts.length - 1;

        if (isLast) {
          const ext = getExt(part);
          const isBin = BINARY_EXTS.has(ext) || content.startsWith('data:image/');
          currentLevel.push({
            name: part,
            path: builtPath,
            isDirectory: false,
            size: content.length,
            isBinary: isBin
          });
        } else {
          let dirNode = currentLevel.find((n) => n.isDirectory && n.name === part);
          if (!dirNode) {
            dirNode = {
              name: part,
              path: builtPath,
              isDirectory: true,
              children: []
            };
            currentLevel.push(dirNode);
          }
          currentLevel = dirNode.children;
        }
      }
    }

    const sortTree = (nodes) => {
      nodes.sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name);
      });
      for (const n of nodes) {
        if (n.children) sortTree(n.children);
      }
    };
    sortTree(rootNodes);
    return rootNodes;
  },

  getFile(projectId, filePath) {
    const norm = normalizeRelPath(filePath);
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    if (fileMap[norm] === undefined) {
      throw new Error(`File not found: ${norm}`);
    }
    const raw = fileMap[norm];
    const isBinary = BINARY_EXTS.has(getExt(norm)) || raw.startsWith('data:application/octet-stream');
    return {
      content: isBinary ? `/* Binary asset (${norm}, ${raw.length} bytes) */` : raw,
      isBinary,
      path: norm
    };
  },

  saveFile(projectId, filePath, content) {
    const norm = normalizeRelPath(filePath);
    const ext = getExt(norm);
    if (UNSUPPORTED_EXTS.has(ext)) {
      throw new Error(`Unsupported executable file type: ${ext}`);
    }
    const ws = loadWorkspace();
    ws.files[projectId] = ws.files[projectId] || {};
    ws.files[projectId][norm] = String(content);
    const p = ws.projects.find((proj) => proj.id === projectId);
    if (p) p.updated_at = new Date().toISOString();
    saveWorkspace(ws);
  },

  deleteFile(projectId, filePath) {
    const norm = normalizeRelPath(filePath);
    const ws = loadWorkspace();
    if (ws.files[projectId]) {
      delete ws.files[projectId][norm];
      for (const k of Object.keys(ws.files[projectId])) {
        if (k.startsWith(`${norm}/`)) delete ws.files[projectId][k];
      }
      saveWorkspace(ws);
    }
  },

  async importSingleFile(
  projectId,
  file,
  targetPath)
  {
    const norm = normalizeRelPath(targetPath || file.name || 'index.html');
    const ext = getExt(norm);
    if (UNSUPPORTED_EXTS.has(ext)) {
      throw new Error(`Unsupported file type: ${ext}`);
    }
    const content = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('Failed to read imported file'));
      if (BINARY_EXTS.has(ext)) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
    this.saveFile(projectId, norm, content);
    return { success: true, importedFile: norm };
  },

  async uploadZip(
  projectId,
  file)







  {
    const buffer = await file.arrayBuffer();
    const extracted = await extractZipBuffer(buffer);
    const ws = loadWorkspace();
    ws.files[projectId] = ws.files[projectId] || {};
    for (const [k, v] of Object.entries(extracted.files)) {
      ws.files[projectId][k] = v;
    }
    const p = ws.projects.find((proj) => proj.id === projectId);
    if (p) p.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    const hasIndexHtml = Boolean(ws.files[projectId]['index.html']);
    return {
      success: true,
      filesExtracted: extracted.extractedFiles,
      skippedUnsupportedFiles: extracted.skippedUnsupportedFiles,
      flattenedRoot: extracted.flattenedRoot,
      hasIndexHtml,
      warnings: hasIndexHtml ?
      [] :
      ["Uploaded archive does not contain an 'index.html' file at the root level."]
    };
  },

  inspectPython(projectId) {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    const entryCandidates = ['main.py', 'app.py', 'index.py', 'server.py'];
    const detectedEntry = entryCandidates.find((e) => fileMap[e] !== undefined) || null;
    const pyFiles = Object.keys(fileMap).
    filter((f) => f.endsWith('.py')).
    sort();
    const hasHtmlBridge = fileMap['index.html'] !== undefined;

    if (!detectedEntry) {
      return {
        supported: false,
        classification: 'unsupported',
        entrypoint: null,
        has_html_bridge: hasHtmlBridge,
        python_files: pyFiles,
        detected_imports: [],
        declared_dependencies: [],
        native_or_heavy_dependencies: [],
        modification_reasons: [],
        unsupported_modules: [],
        recommendations: ['Create or rename your primary Python file to main.py or app.py.'],
        error: 'Missing main entrypoint. Provide main.py, app.py, index.py, or server.py.'
      };
    }

    const imports = new Set();
    const unsupported = [];
    let usesBlockingInput = false;

    for (const pyFile of pyFiles) {
      const src = fileMap[pyFile] || '';
      const lines = src.split(/\r?\n/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const impMatch = trimmed.match(/^import\s+([a-zA-Z0-9_.,\s]+)/);
        if (impMatch) {
          for (const part of impMatch[1].split(',')) {
            const mod = part.trim().split(/\s+as\s+/)[0].split('.')[0];
            if (mod) {
              imports.add(mod);
              if (PROHIBITED_PY_MODULES[mod.toLowerCase()]) {
                unsupported.push({
                  module: mod,
                  reason: PROHIBITED_PY_MODULES[mod.toLowerCase()],
                  file: pyFile
                });
              }
            }
          }
        }
        const fromMatch = trimmed.match(/^from\s+([a-zA-Z0-9_.]+)\s+import\s+/);
        if (fromMatch) {
          const mod = fromMatch[1].split('.')[0];
          if (mod) {
            imports.add(mod);
            if (PROHIBITED_PY_MODULES[mod.toLowerCase()]) {
              unsupported.push({
                module: mod,
                reason: PROHIBITED_PY_MODULES[mod.toLowerCase()],
                file: pyFile
              });
            }
          }
        }
        if (/\binput\s*\(/.test(trimmed)) {
          usesBlockingInput = true;
        }
      }
    }

    const reqContent = fileMap['requirements.txt'] || '';
    const dependencies = reqContent.
    split(/\r?\n/).
    map((l) => l.trim()).
    filter((l) => l && !l.startsWith('#'));

    if (unsupported.length > 0) {
      return {
        supported: false,
        classification: 'unsupported',
        entrypoint: detectedEntry,
        has_html_bridge: hasHtmlBridge,
        python_files: pyFiles,
        detected_imports: Array.from(imports).sort(),
        declared_dependencies: dependencies,
        native_or_heavy_dependencies: [],
        modification_reasons: [],
        unsupported_modules: unsupported,
        recommendations: unsupported.map((u) => `Replace ${u.module} (${u.reason})`),
        error: 'Incompatible desktop/native modules detected.'
      };
    }

    const nativeDeps = [];
    for (const imp of Array.from(imports)) {
      if (NATIVE_WHEEL_PACKAGES[imp.toLowerCase()]) {
        nativeDeps.push({ package: imp, note: NATIVE_WHEEL_PACKAGES[imp.toLowerCase()] });
      }
    }

    const modReasons = [];
    const recommendations = [];
    if (!hasHtmlBridge) {
      modReasons.push(
      'Missing index.html WebView UI bridge. Android WebView requires an HTML entrypoint to display output.');

      recommendations.push(
      "Use 'Generate / Refresh HTML Bridge' to create an index.html wrapper for your Python script.");

    }
    if (usesBlockingInput) {
      modReasons.push(
      'Uses blocking standard input `input()`, which hangs in non-interactive WebView environments.');

    }
    if (nativeDeps.length > 0) {
      modReasons.push(
      `Uses native/C-extension packages (${nativeDeps.map((d) => d.package).join(', ')}) requiring Chaquopy or Pyodide wheels.`);

    }

    return {
      supported: true,
      classification: modReasons.length > 0 ? 'requires_modification' : 'supported',
      entrypoint: detectedEntry,
      has_html_bridge: hasHtmlBridge,
      python_files: pyFiles,
      detected_imports: Array.from(imports).sort(),
      declared_dependencies: dependencies,
      native_or_heavy_dependencies: nativeDeps,
      modification_reasons: modReasons,
      unsupported_modules: [],
      recommendations:
      recommendations.length > 0 ?
      recommendations :
      ['Project is clean and ready for hybrid Android WebView packaging.']
    };
  },

  generatePythonBridge(
  projectId,
  entrypoint = 'main.py')
  {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === projectId);
    if (!project) throw new Error('Project not found');
    const pyCode = ws.files[projectId] && ws.files[projectId][entrypoint] || '# Python script';
    const html = generatePythonBridgeHtml(project.name, entrypoint, pyCode);
    this.saveFile(projectId, 'index.html', html);
    return {
      success: true,
      generatedFile: 'index.html',
      inspection: this.inspectPython(projectId)
    };
  },

  /**
   * Compiles a self-contained HTML `srcdoc` string for LivePreviewPane so live preview
   * works identically inside the Android APK WebView (`file://`) and standard browsers.
   */
  compileLivePreviewSrcDoc(projectId) {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    let html = fileMap['index.html'] || '<!DOCTYPE html><html><body><p>No index.html found.</p></body></html>';

    // Inline local CSS <link rel="stylesheet" href="...">
    html = html.replace(
    /<link\s+[^>]*href=["']([^"']+\.css)["'][^>]*>/gi,
    (fullMatch, href) => {
      const cleanHref = href.replace(/^\.?\//, '');
      if (fileMap[cleanHref] !== undefined) {
        return `<style data-source="${cleanHref}">\n${fileMap[cleanHref]}\n</style>`;
      }
      return fullMatch;
    });


    if (fileMap['apk_studio_animations.css'] && !html.includes('apk_studio_animations.css')) {
      const animStyle = `<style data-source="apk_studio_animations.css">\n${fileMap['apk_studio_animations.css']}\n</style>`;
      html = html.includes('</head>') ?
      html.replace('</head>', `${animStyle}\n</head>`) :
      `${animStyle}\n${html}`;
    }

    // Inline local JS <script src="..."></script>
    html = html.replace(
    /<script\s+[^>]*src=["']([^"']+\.js)["'][^>]*>\s*<\/script>/gi,
    (fullMatch, src) => {
      const cleanSrc = src.replace(/^\.?\//, '');
      if (fileMap[cleanSrc] !== undefined) {
        return `<script data-source="${cleanSrc}">\n${fileMap[cleanSrc]}\n</script>`;
      }
      return fullMatch;
    });


    const bridgeScript = `<script>
(function() {
  function sendToStudio(level, args) {
    try {
      var msg = Array.prototype.slice.call(args).map(function(a) {
        if (a instanceof Error) return a.stack || a.message;
        if (typeof a === 'object') { try { return JSON.stringify(a); } catch(e) { return String(a); } }
        return String(a);
      }).join(' ');
      window.parent.postMessage({
        source: 'apk-studio-preview',
        level: level,
        message: msg,
        timestamp: new Date().toISOString()
      }, '*');
    } catch (e) {}
  }
  var origLog = console.log;
  var origWarn = console.warn;
  var origError = console.error;
  console.log = function() { sendToStudio('info', arguments); origLog.apply(console, arguments); };
  console.warn = function() { sendToStudio('warn', arguments); origWarn.apply(console, arguments); };
  console.error = function() { sendToStudio('error', arguments); origError.apply(console, arguments); };
  window.addEventListener('error', function(ev) {
    sendToStudio('error', [ev.message + (ev.filename ? ' (' + ev.filename + ':' + ev.lineno + ')' : '')]);
  });
})();
</script>`;

    return html.includes('<head>') ?
    html.replace('<head>', `<head>${bridgeScript}`) :
    `${bridgeScript}${html}`;
  },

  triggerBuild(
  projectId,
  buildType = 'debug')
  {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === projectId);
    if (!project) throw new Error('Project not found');
    const config = ws.customizations[projectId];
    const anim = ws.animations[projectId];
    const fileMap = ws.files[projectId] || {};

    const buildId = randomId();
    const now = new Date().toISOString();
    let log = `[Build Engine] Initializing ${buildType.toUpperCase()} build for project "${project.name}" (${projectId})\n`;
    log += `[Stage 1/7] Validating project structure and customization parameters...\n`;

    if (!fileMap['index.html'] && project.type === 'python') {
      const pyRes = this.inspectPython(projectId);
      if (!pyRes.supported || pyRes.classification === 'unsupported') {
        const failedRecord = {
          id: buildId,
          project_id: projectId,
          build_type: buildType,
          status: 'failed',
          stage: 'failed',
          progress: 20,
          started_at: now,
          completed_at: new Date().toISOString(),
          log: log + `\n[Build Engine ERROR] ${pyRes.error || 'Unsupported Python modules.'}\n`,
          error_summary: pyRes.error || 'Unsupported Python modules.'
        };
        ws.builds[buildId] = failedRecord;
        project.last_build_status = 'failed';
        saveWorkspace(ws);
        return { buildId, status: 'failed', buildType };
      }
      this.generatePythonBridge(projectId, pyRes.entrypoint || 'main.py');
    }

    const updatedFiles = loadWorkspace().files[projectId] || {};
    if (!updatedFiles['index.html']) {
      const failedRecord = {
        id: buildId,
        project_id: projectId,
        build_type: buildType,
        status: 'failed',
        stage: 'failed',
        progress: 20,
        started_at: now,
        completed_at: new Date().toISOString(),
        log: log + "\n[Build Engine ERROR] Project must contain an 'index.html' entrypoint at its root.\n",
        error_summary: "Project must contain an 'index.html' entrypoint at its root."
      };
      ws.builds[buildId] = failedRecord;
      project.last_build_status = 'failed';
      saveWorkspace(ws);
      return { buildId, status: 'failed', buildType };
    }

    log += `[Stage 2/7] Preparing isolated Android Gradle project in build workspace...\n`;
    log += `[Stage 3/7] Applying package ID (${config.package_id}), version ${config.version_name} (${config.version_code}), permissions, and theme...\n`;
    log += `[Stage 4/7] Packaging ${Object.keys(updatedFiles).length} project file(s) and Animation Studio presets into app/src/main/assets/webapp/...\n`;
    log += `[Stage 5/7] Checking host Android SDK, JDK compiler, and Gradle toolchain...\n`;
    log += `  - Running in On-Device Standalone Mode (no local Android SDK/Gradle daemon on mobile WebView).\n`;
    log += `\n[Build Engine READY FOR EXPORT OR REMOTE COMPILATION]\n`;
    log += `  • Your complete Android Studio Gradle project (${config.package_id}) has been generated and verified.\n`;
    log += `  • Click "Export Android Gradle Project (.zip)" above to download the ready-to-compile Android project (includes Gradle Wrapper & GitHub Actions workflow).\n`;
    log += `  • Or connect a Remote Build Server URL in the top navigation bar to compile the APK binary over the network.\n`;

    // Store prepared Android project files for instant ZIP export
    const preparedFiles = {
      'settings.gradle': `pluginManagement {\n    repositories {\n        google()\n        mavenCentral()\n        gradlePluginPortal()\n    }\n}\ndependencyResolutionManagement {\n    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n    repositories {\n        google()\n        mavenCentral()\n    }\n}\nrootProject.name = "APKStudioApp"\ninclude ':app'\n`,
      'build.gradle': `plugins {\n    id 'com.android.application' version '8.2.2' apply false\n}\n`,
      'gradle.properties': `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nandroid.enableJetifier=true\nandroid.nonTransitiveRClass=true\n`,
      'gradle/wrapper/gradle-wrapper.properties': `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\n`,
      'app/build.gradle': `plugins {\n    id 'com.android.application'\n}\nandroid {\n    namespace 'com.apkstudio.app'\n    compileSdk 34\n    defaultConfig {\n        applicationId "${config.package_id}"\n        minSdk 24\n        targetSdk 34\n        versionCode ${config.version_code}\n        versionName "${config.version_name}"\n    }\n    compileOptions {\n        sourceCompatibility JavaVersion.VERSION_17\n        targetCompatibility JavaVersion.VERSION_17\n    }\n}\ndependencies {\n    implementation 'androidx.appcompat:appcompat:1.6.1'\n    implementation 'com.google.android.material:material:1.11.0'\n    implementation 'androidx.webkit:webkit:1.10.0'\n    implementation 'androidx.activity:activity:1.8.2'\n}\n`,
      'app/src/main/res/values/strings.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">${config.app_name.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</string>\n</resources>\n`,
      'app/src/main/res/values/colors.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="status_bar_color">${config.status_bar_color}</color>\n    <color name="nav_bar_color">${config.nav_bar_color}</color>\n    <color name="theme_color">${config.theme_color || '#6C5CE7'}</color>\n    <color name="background_color">${config.background_color || '#1F1C2C'}</color>\n    <color name="splash_color">${config.splash_color || '#1F1C2C'}</color>\n</resources>\n`,
      'app/src/main/res/values/styles.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <style name="Theme.APKStudioApp" parent="Theme.MaterialComponents.DayNight.NoActionBar">\n        <item name="colorPrimary">@color/theme_color</item>\n        <item name="android:windowBackground">@color/background_color</item>\n        <item name="android:statusBarColor">@color/status_bar_color</item>\n        <item name="android:windowLightStatusBar">${config.light_status_bar ? 'true' : 'false'}</item>\n        <item name="android:navigationBarColor">@color/nav_bar_color</item>\n    </style>\n</resources>\n`,
      'app/src/main/AndroidManifest.xml': `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n${(config.permissions || ['android.permission.INTERNET']).map((p) => `    <uses-permission android:name="${p}" />`).join('\n')}\n    <application\n        android:allowBackup="true"\n        android:hardwareAccelerated="true"\n        android:label="@string/app_name"\n        android:supportsRtl="true"\n        android:theme="@style/Theme.APKStudioApp"\n        android:usesCleartextTraffic="${config.allow_cleartext !== false ? 'true' : 'false'}">\n        <activity\n            android:name="com.apkstudio.app.MainActivity"\n            android:exported="true"\n            android:configChanges="orientation|screenSize|keyboardHidden|uiMode"\n            android:screenOrientation="${config.orientation || 'portrait'}"\n            android:theme="@style/Theme.APKStudioApp">\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>\n`,
      '.github/workflows/build-apk.yml': `name: Build Android APK\non:\n  workflow_dispatch:\n  push:\n    branches: [ main, master ]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-java@v4\n        with:\n          distribution: 'temurin'\n          java-version: '17'\n      - uses: android-actions/setup-android@v3\n      - uses: gradle/actions/setup-gradle@v3\n        with:\n          gradle-version: '8.5'\n      - run: gradle assembleDebug --no-daemon\n      - uses: actions/upload-artifact@v4\n        with:\n          name: Android-APK\n          path: app/build/outputs/apk/**/*.apk\n`
    };

    for (const [k, v] of Object.entries(updatedFiles)) {
      preparedFiles[`app/src/main/assets/webapp/${k}`] = v;
    }
    if (anim && anim.inject_stylesheet !== false) {
      preparedFiles['app/src/main/assets/webapp/apk_studio_animations.css'] =
      generateAnimationStylesheet(anim);
    }

    ws.preparedAndroidProjects[buildId] = preparedFiles;
    ws.builds[buildId] = {
      id: buildId,
      project_id: projectId,
      build_type: buildType,
      status: 'failed',
      stage: 'checking_toolchain',
      progress: 65,
      started_at: now,
      completed_at: new Date().toISOString(),
      log,
      error_summary:
      'Prepared Android Gradle project is ready for export. Native Gradle compilation requires a connected Build Server or exporting the Android Gradle ZIP.'
    };
    project.last_build_status = 'failed';
    saveWorkspace(ws);
    return { buildId, status: 'failed', buildType };
  },

  getBuildStatus(buildId) {
    const ws = loadWorkspace();
    const rec = ws.builds[buildId];
    if (!rec) throw new Error('Build ID not found');
    return rec;
  },

  listBuilds(projectId) {
    const ws = loadWorkspace();
    return Object.values(ws.builds).
    filter((b) => b.project_id === projectId).
    sort((a, b) => b.started_at.localeCompare(a.started_at));
  },

  exportPreparedProjectZip(buildId) {
    const ws = loadWorkspace();
    const filesMap = ws.preparedAndroidProjects[buildId];
    if (!filesMap) {
      throw new Error('Prepared Android project files not found for this build.');
    }
    const zipBytes = buildZipUint8Array(filesMap);
    const filename = `android-project-${buildId.substring(0, 8)}.zip`;

    const win = window;
    if (win.AndroidStudioBridge && typeof win.AndroidStudioBridge.saveBase64File === 'function') {
      let binary = '';
      for (let i = 0; i < zipBytes.length; i++) {
        binary += String.fromCharCode(zipBytes[i]);
      }
      win.AndroidStudioBridge.saveBase64File(btoa(binary), filename, 'application/zip');
      return;
    }

    const blob = new Blob([zipBytes], { type: 'application/zip' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
};exports.LocalEngine = LocalEngine;
},
"./types/index": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });
},
"./utils/syntaxHighlight": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.detectLanguageFromPath = detectLanguageFromPath;exports.getSyntaxAccentColor = getSyntaxAccentColor;function detectLanguageFromPath(filePath) {
  const lower = filePath.toLowerCase();
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'HTML';
  if (lower.endsWith('.css')) return 'CSS';
  if (lower.endsWith('.js') || lower.endsWith('.mjs')) return 'JavaScript';
  if (lower.endsWith('.ts') || lower.endsWith('.tsx')) return 'TypeScript';
  if (lower.endsWith('.py')) return 'Python';
  if (lower.endsWith('.json')) return 'JSON';
  if (lower.endsWith('.xml')) return 'XML';
  if (lower.endsWith('.md')) return 'Markdown';
  return 'Plain Text';
}

function getSyntaxAccentColor(language) {
  switch (language) {
    case 'HTML':
      return '#ff9ff3';
    case 'CSS':
      return '#54a0ff';
    case 'JavaScript':
    case 'TypeScript':
      return '#feca57';
    case 'Python':
      return '#00ffc8';
    case 'JSON':
      return '#1dd1a1';
    default:
      return '#e2e8f0';}

}
},
"./utils/validation": function(module, exports, require) {
"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.validateCustomizationClient = validateCustomizationClient;

function validateCustomizationClient(settings) {
  const errors = [];

  if (!settings.app_name || !settings.app_name.trim()) {
    errors.push('Application name cannot be empty.');
  }

  const pkgRegex = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;
  if (!settings.package_id || !pkgRegex.test(settings.package_id.trim())) {
    errors.push("Android Package ID must have at least two segments (e.g. 'com.company.myapp') using letters, digits, and underscores.");
  }

  const verRegex = /^[0-9]+(\.[0-9]+){0,3}(-[a-zA-Z0-9._-]+)?$/;
  if (!settings.version_name || !verRegex.test(settings.version_name.trim())) {
    errors.push("Version Name must follow semantic format (e.g. '1.0.0').");
  }

  if (!Number.isInteger(Number(settings.version_code)) || Number(settings.version_code) < 1) {
    errors.push('Version Code must be a positive integer (>= 1).');
  }

  const hexRegex = /^#[0-9A-Fa-f]{6}$/;
  if (!hexRegex.test(settings.status_bar_color)) {
    errors.push('Status Bar Color must be a valid 6-digit hex color.');
  }
  if (!hexRegex.test(settings.nav_bar_color)) {
    errors.push('Navigation Bar Color must be a valid 6-digit hex color.');
  }

  return errors;
}
}
  };

  var cache = {};

  function resolvePath(baseKey, reqPath) {
    if (reqPath === "react") return "react";
    if (reqPath === "react-dom/client" || reqPath === "react-dom") return "react-dom/client";
    if (reqPath === "lucide-react") return "lucide-react";
    if (reqPath.endsWith(".css")) return "__css__";
    var baseParts = baseKey.split("/").slice(0, -1);
    var relParts = reqPath.split("/");
    for (var i = 0; i < relParts.length; i++) {
      var seg = relParts[i];
      if (seg === "." || seg === "") continue;
      if (seg === "..") baseParts.pop();
      else baseParts.push(seg);
    }
    var candidate = "./" + baseParts.filter(Boolean).join("/");
    if (modules[candidate]) return candidate;
    if (modules[candidate + "/index"]) return candidate + "/index";
    return candidate;
  }

  function requireModule(fromKey, reqPath) {
    var resolved = resolvePath(fromKey, reqPath);
    if (resolved === "react") return ReactShim;
    if (resolved === "react-dom/client") return ReactDOMClientShim;
    if (resolved === "lucide-react") return LucideShim;
    if (resolved === "__css__") return {};
    if (cache[resolved]) return cache[resolved].exports;
    var factory = modules[resolved];
    if (!factory) {
      throw new Error("Module not found in bundle: " + reqPath + " (resolved: " + resolved + ")");
    }
    var mod = { exports: {} };
    cache[resolved] = mod;
    factory(mod, mod.exports, function(childReq) {
      return requireModule(resolved, childReq);
    });
    return mod.exports;
  }

  window.addEventListener("DOMContentLoaded", function() {
    requireModule("./main", "./main");
  });
})();
