package com.apkstudio.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout splashOverlay;
    private ValueCallback<Uri[]> filePathCallback;

    // __CONFIG_CONSTANTS_START__
    private static final boolean ENABLE_FULLSCREEN = false;
    private static final boolean KEEP_SCREEN_ON = false;
    private static final boolean ENABLE_ZOOM = false;
    private static final boolean SPLASH_ENABLED = true;
    private static final int SPLASH_DURATION_MS = 1500;
    private static final String SPLASH_ANIMATION = "fade";
    private static final String OFFLINE_MODE = "cache_first";
    private static final String BACKGROUND_COLOR = "#1F1C2C";
    private static final String SPLASH_COLOR = "#1F1C2C";
    private static final String APP_TITLE = "APK STUDIO";
    private static final String VERSION_NAME = "1.0.0";
    // __CONFIG_CONSTANTS_END__

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        applyWindowConfiguration();

        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        try {
            rootLayout.setBackgroundColor(Color.parseColor(BACKGROUND_COLOR));
        } catch (IllegalArgumentException ignored) {
            rootLayout.setBackgroundColor(Color.parseColor("#1F1C2C"));
        }

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                8
        );
        pbParams.gravity = Gravity.TOP;
        progressBar.setLayoutParams(pbParams);
        progressBar.setMax(100);

        rootLayout.addView(webView);
        rootLayout.addView(progressBar);

        if (SPLASH_ENABLED && savedInstanceState == null) {
            splashOverlay = createSplashOverlay();
            rootLayout.addView(splashOverlay);
        }

        setContentView(rootLayout);

        configureWebView();
        configureBackNavigation();

        webView.loadUrl("file:///android_asset/webapp/index.html");

        if (splashOverlay != null) {
            scheduleSplashDismissal();
        }
    }

    private void applyWindowConfiguration() {
        if (KEEP_SCREEN_ON) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        if (ENABLE_FULLSCREEN) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                final WindowInsetsController insetsController = getWindow().getInsetsController();
                if (insetsController != null) {
                    insetsController.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    insetsController.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                }
            } else {
                //noinspection deprecation
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
            }
        }
    }

    private FrameLayout createSplashOverlay() {
        FrameLayout splash = new FrameLayout(this);
        splash.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        try {
            splash.setBackgroundColor(Color.parseColor(SPLASH_COLOR));
        } catch (IllegalArgumentException ignored) {
            splash.setBackgroundColor(Color.parseColor("#1F1C2C"));
        }

        LinearLayout centerBox = new LinearLayout(this);
        centerBox.setOrientation(LinearLayout.VERTICAL);
        centerBox.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams boxParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        boxParams.gravity = Gravity.CENTER;
        centerBox.setLayoutParams(boxParams);

        TextView titleView = new TextView(this);
        titleView.setText(APP_TITLE);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(24f);
        titleView.setGravity(Gravity.CENTER);

        ProgressBar loader = new ProgressBar(this);
        LinearLayout.LayoutParams loaderParams = new LinearLayout.LayoutParams(72, 72);
        loaderParams.topMargin = 36;
        loader.setLayoutParams(loaderParams);

        centerBox.addView(titleView);
        centerBox.addView(loader);
        splash.addView(centerBox);

        if ("scale".equalsIgnoreCase(SPLASH_ANIMATION) || "pulse".equalsIgnoreCase(SPLASH_ANIMATION)) {
            centerBox.setScaleX(0.85f);
            centerBox.setScaleY(0.85f);
            centerBox.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(450)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .start();
        }

        return splash;
    }

    private void scheduleSplashDismissal() {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (splashOverlay == null) return;
            if ("none".equalsIgnoreCase(SPLASH_ANIMATION)) {
                splashOverlay.setVisibility(View.GONE);
                return;
            }
            float targetTranslationY = "slide".equalsIgnoreCase(SPLASH_ANIMATION) ? -splashOverlay.getHeight() : 0f;
            float targetScale = "scale".equalsIgnoreCase(SPLASH_ANIMATION) ? 1.12f : 1.0f;
            splashOverlay.animate()
                    .alpha(0f)
                    .translationY(targetTranslationY)
                    .scaleX(targetScale)
                    .scaleY(targetScale)
                    .setDuration(380)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> splashOverlay.setVisibility(View.GONE))
                    .start();
        }, Math.max(200, SPLASH_DURATION_MS));
    }

    @SuppressLint({"SetJavaScriptEnabled", "AllowFileAccessFromFileURLs"})
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        //noinspection deprecation
        settings.setAllowFileAccessFromFileURLs(true);
        //noinspection deprecation
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(ENABLE_ZOOM);
        settings.setBuiltInZoomControls(ENABLE_ZOOM);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        if ("offline_only".equalsIgnoreCase(OFFLINE_MODE)) {
            settings.setCacheMode(WebSettings.LOAD_CACHE_ONLY);
        } else if ("cache_first".equalsIgnoreCase(OFFLINE_MODE)) {
            settings.setCacheMode(isNetworkAvailable()
                    ? WebSettings.LOAD_DEFAULT
                    : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        } else {
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        }

        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidStudioBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    //noinspection deprecation
                    startActivityForResult(Intent.createChooser(intent, "Select File or Archive"), FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this, "Offline mode: loaded from local bundle.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private void configureBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    public static class AndroidBridge {
        private final Context context;

        public AndroidBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void showToast(String message) {
            new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            );
        }

        @JavascriptInterface
        public String getAppVersion() {
            return VERSION_NAME;
        }

        @JavascriptInterface
        public void saveBase64File(String base64Data, String fileName, String mimeType) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!downloadsDir.exists()) {
                        downloadsDir.mkdirs();
                    }
                    File outFile = new File(downloadsDir, fileName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                    }
                    Toast.makeText(context, "Saved to Downloads: " + outFile.getName(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(context, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void vibrate(long milliseconds) {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(
                            Math.min(milliseconds, 1000L),
                            VibrationEffect.DEFAULT_AMPLITUDE
                    ));
                } else {
                    //noinspection deprecation
                    vibrator.vibrate(Math.min(milliseconds, 1000L));
                }
            }
        }
    }
}
