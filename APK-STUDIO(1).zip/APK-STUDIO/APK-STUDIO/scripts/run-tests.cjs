#!/usr/bin/env node
/**
 * APK STUDIO — Universal Automated Test Runner (Jest-compatible API over Node 18)
 * Includes per-test timeout protection and explicit process termination so tests
 * never hang on open handles.
 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { compileTsxToCommonJs } = require('./ts-jsx-compiler.cjs');

const ROOT = path.resolve(__dirname, '..');
const scopeArg = process.argv[2] || 'all';
const TEST_TIMEOUT_MS = 15000;

const SEARCH_PATHS = [
  path.join(ROOT, 'node_modules'),
  path.join(ROOT, 'backend', 'node_modules'),
  path.join(ROOT, 'frontend', 'node_modules'),
  '/usr/share/nodejs',
  '/usr/lib/node_modules'
].filter((p) => fs.existsSync(p));

if (SEARCH_PATHS.length > 0 && process.env.DISABLE_SYSTEM_NODE_PATH !== '1') {
  const existingNodePath = process.env.NODE_PATH ? process.env.NODE_PATH.split(path.delimiter) : [];
  process.env.NODE_PATH = Array.from(new Set([...SEARCH_PATHS, ...existingNodePath])).join(path.delimiter);
  require('module').Module._initPaths();
}

function tryResolve(modName) {
  if (process.env.DISABLE_SYSTEM_NODE_PATH === '1') return null;
  try {
    return require.resolve(modName, { paths: SEARCH_PATHS });
  } catch {
    return null;
  }
}

const babelCorePath = tryResolve('@babel/core');
const presetEnvPath = tryResolve('@babel/preset-env');
const presetTsPath = tryResolve('@babel/preset-typescript');
const presetReactPath = tryResolve('@babel/preset-react');
const babel = babelCorePath ? require(babelCorePath) : null;

function transpileCode(content, filename, isTSX) {
  if (babel && presetEnvPath && presetTsPath && (!isTSX || presetReactPath)) {
    const presets = [
      [presetEnvPath, { targets: { node: '18' }, modules: 'commonjs' }],
      [presetTsPath, { isTSX, allExtensions: true }]
    ];
    if (isTSX && presetReactPath) {
      presets.push([presetReactPath, { runtime: 'classic' }]);
    }
    const compiled = babel.transformSync(content, {
      filename,
      presets,
      retainLines: true
    });
    return compiled.code || '';
  }

  return compileTsxToCommonJs(content, filename);
}

require.extensions['.ts'] = function (module, filename) {
  const content = fs.readFileSync(filename, 'utf-8');
  module._compile(transpileCode(content, filename, false), filename);
};

require.extensions['.tsx'] = function (module, filename) {
  const content = fs.readFileSync(filename, 'utf-8');
  module._compile(transpileCode(content, filename, true), filename);
};

const suites = [];
let currentSuite = null;

global.describe = (name, fn) => {
  const suite = { name, beforeAllFns: [], afterAllFns: [], tests: [] };
  const prev = currentSuite;
  currentSuite = suite;
  fn();
  currentSuite = prev;
  suites.push(suite);
};

global.beforeAll = (fn) => {
  if (currentSuite) currentSuite.beforeAllFns.push(fn);
};

global.afterAll = (fn) => {
  if (currentSuite) currentSuite.afterAllFns.push(fn);
};

global.it = (name, fn) => {
  if (currentSuite) currentSuite.tests.push({ name, fn });
};
global.test = global.it;

function createMatchers(actual, isNot = false) {
  const check = (cond, msg) => {
    if (isNot ? cond : !cond) {
      throw new Error(msg);
    }
  };
  return {
    toBe(expected) {
      check(Object.is(actual, expected), `Expected ${JSON.stringify(actual)} ${isNot ? 'not ' : ''}to be ${JSON.stringify(expected)}`);
    },
    toEqual(expected) {
      let eq = false;
      try {
        assert.deepStrictEqual(actual, expected);
        eq = true;
      } catch {
        eq = false;
      }
      check(eq, `Expected ${JSON.stringify(actual)} ${isNot ? 'not ' : ''}to equal ${JSON.stringify(expected)}`);
    },
    toBeGreaterThan(num) {
      check(typeof actual === 'number' && actual > num, `Expected ${actual} to be > ${num}`);
    },
    toBeGreaterThanOrEqual(num) {
      check(typeof actual === 'number' && actual >= num, `Expected ${actual} to be >= ${num}`);
    },
    toContain(item) {
      const has = Array.isArray(actual) || typeof actual === 'string' ? actual.includes(item) : false;
      check(has, `Expected ${JSON.stringify(actual)} ${isNot ? 'not ' : ''}to contain ${JSON.stringify(item)}`);
    },
    toBeDefined() {
      check(actual !== undefined, `Expected value ${isNot ? 'not ' : ''}to be defined`);
    },
    toBeTruthy() {
      check(Boolean(actual), `Expected ${JSON.stringify(actual)} to be truthy`);
    },
    toBeFalsy() {
      check(!actual, `Expected ${JSON.stringify(actual)} to be falsy`);
    },
    toThrow(expectedSubstr) {
      let threw = false;
      let errMessage = '';
      try {
        actual();
      } catch (err) {
        threw = true;
        errMessage = err && err.message ? err.message : String(err);
      }
      check(threw, `Expected function ${isNot ? 'not ' : ''}to throw`);
      if (!isNot && expectedSubstr && !errMessage.includes(expectedSubstr)) {
        throw new Error(`Expected error "${errMessage}" to include "${expectedSubstr}"`);
      }
    },
    get not() {
      return createMatchers(actual, !isNot);
    },
    get rejects() {
      return {
        async toThrow(expectedSubstr) {
          let threw = false;
          let errMessage = '';
          try {
            await actual;
          } catch (err) {
            threw = true;
            errMessage = err && err.message ? err.message : String(err);
          }
          if (!threw) {
            throw new Error('Expected promise to reject, but it resolved.');
          }
          if (expectedSubstr && !errMessage.includes(expectedSubstr)) {
            throw new Error(`Expected rejection "${errMessage}" to include "${expectedSubstr}"`);
          }
        }
      };
    }
  };
}

global.expect = (actual) => createMatchers(actual, false);

async function runWithTimeout(fn, label) {
  let timer = null;
  try {
    await Promise.race([
      Promise.resolve().then(() => fn()),
      new Promise((_, reject) => {
        timer = setTimeout(
          () => reject(new Error(`Test timed out after ${TEST_TIMEOUT_MS}ms: ${label}`)),
          TEST_TIMEOUT_MS
        );
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function runAll() {
  const testDirs = [];
  if (scopeArg === 'all' || scopeArg === 'backend') {
    testDirs.push(path.join(ROOT, 'backend', 'tests'));
  }
  if (scopeArg === 'all' || scopeArg === 'frontend') {
    testDirs.push(path.join(ROOT, 'frontend', 'tests'));
  }

  for (const dir of testDirs) {
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.test.ts')).sort();
    for (const file of files) {
      require(path.join(dir, file));
    }
  }

  let passed = 0;
  let failed = 0;
  const startAll = Date.now();

  console.log('==============================================================');
  console.log(` APK STUDIO — Automated Test Suite Execution (${scopeArg})`);
  console.log('==============================================================');

  for (const suite of suites) {
    console.log(`\nSUITE: ${suite.name}`);
    try {
      for (const hook of suite.beforeAllFns) {
        await runWithTimeout(hook, `${suite.name} beforeAll`);
      }
      for (const t of suite.tests) {
        const t0 = Date.now();
        try {
          await runWithTimeout(t.fn, t.name);
          passed += 1;
          console.log(`  ✓ ${t.name} (${Date.now() - t0}ms)`);
        } catch (err) {
          failed += 1;
          console.error(`  ✗ ${t.name} (${Date.now() - t0}ms)`);
          console.error(`    ${err && err.stack ? err.stack : err}`);
        }
      }
    } finally {
      for (const hook of suite.afterAllFns) {
        try {
          await runWithTimeout(hook, `${suite.name} afterAll`);
        } catch (err) {
          console.error(`  [afterAll error]: ${err}`);
        }
      }
    }
  }

  console.log('\n--------------------------------------------------------------');
  console.log(
    `Test Summary: ${passed} passed, ${failed} failed, ${passed + failed} total (${Date.now() - startAll}ms)`
  );
  console.log('--------------------------------------------------------------');
  process.exit(failed > 0 ? 1 : 0);
}

runAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
