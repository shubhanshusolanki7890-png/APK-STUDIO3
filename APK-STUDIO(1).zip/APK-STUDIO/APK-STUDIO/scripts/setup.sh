#!/usr/bin/env bash
set -e
echo "[APK STUDIO] Installing workspace dependencies..."
npm install
cd backend && npm install
cd ../frontend && npm install
echo "[APK STUDIO] Setup complete."
