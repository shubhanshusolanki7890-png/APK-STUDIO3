#!/usr/bin/env node
/**
 * APK STUDIO — Universal TypeScript, JSX & Production Frontend Bundler
 * - Uses `@babel/core` + presets from `node_modules` when installed via `npm install`
 * - Uses the bundled AST-powered TypeScript & JSX compiler (`./ts-jsx-compiler.cjs`)
 *   when dependencies are not yet installed
 * - Strictly validates every output `.js` file and the frontend bundle with `new vm.Script()`
 *   so the build fails immediately rather than ever emitting invalid JavaScript
 * - Automatically syncs the production React frontend (`frontend/dist/{index.html,assets/*}`)
 *   into `build-engine/android-template/app/src/main/assets/webapp/`.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { compileTsxToCommonJs } = require('./ts-jsx-compiler.cjs');

const ROOT = path.resolve(__dirname, '..');
const targetArg = process.argv[2] || 'all';

const SEARCH_PATHS = [
  path.join(ROOT, 'node_modules'),
  path.join(ROOT, 'backend', 'node_modules'),
  path.join(ROOT, 'frontend', 'node_modules'),
  '/usr/share/nodejs',
  '/usr/lib/node_modules'
].filter((p) => fs.existsSync(p));

if (SEARCH_PATHS.length > 0 && process.env.DISABLE_SYSTEM_NODE_PATH !== '1') {
  const existingNodePath = process.env.NODE_PATH ? process.env.NODE_PATH.split(path.delimiter) : [];
  process.env.NODE_PATH = Array.from(new Set([...SEARCH_PATHS, ...existingNodePath])).join(path.delimiter);
  require('module').Module._initPaths();
}

function tryResolve(modName) {
  if (process.env.DISABLE_SYSTEM_NODE_PATH === '1') return null;
  try {
    return require.resolve(modName, { paths: SEARCH_PATHS });
  } catch {
    return null;
  }
}

const babelCorePath = tryResolve('@babel/core');
const presetEnvPath = tryResolve('@babel/preset-env');
const presetTsPath = tryResolve('@babel/preset-typescript');
const presetReactPath = tryResolve('@babel/preset-react');
const babel = babelCorePath ? require(babelCorePath) : null;

function copyDirRecursive(src, dest) {
  if (!fs.existsSync(src)) return;
  const stats = fs.statSync(src);
  if (stats.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyDirRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

function removeDirRecursive(target) {
  if (!fs.existsSync(target)) return;
  const stats = fs.statSync(target);
  if (stats.isDirectory()) {
    for (const entry of fs.readdirSync(target)) {
      removeDirRecursive(path.join(target, entry));
    }
    fs.rmdirSync(target);
  } else {
    fs.unlinkSync(target);
  }
}

function compileSingleFile(srcFile, outFile, isReact = false) {
  const code = fs.readFileSync(srcFile, 'utf-8');
  let compiledCode = '';

  if (babel && presetEnvPath && presetTsPath && (!isReact || presetReactPath)) {
    const presets = [
      [presetEnvPath, { targets: { node: '18' }, modules: 'commonjs' }],
      [presetTsPath, { isTSX: isReact, allExtensions: true }]
    ];
    if (isReact && presetReactPath) {
      presets.push([presetReactPath, { runtime: 'classic' }]);
    }
    const transformed = babel.transformSync(code, {
      filename: srcFile,
      presets,
      retainLines: true
    });
    compiledCode = transformed.code || '';
  } else {
    compiledCode = compileTsxToCommonJs(code, srcFile);
  }

  // Strictly validate JavaScript syntax before writing; fail immediately if invalid
  new vm.Script(compiledCode, { filename: outFile });

  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, compiledCode, 'utf-8');
  return compiledCode;
}

function walkAndCompile(srcDir, outDir, isReact = false, collectedModules = null, relPrefix = '') {
  if (!fs.existsSync(srcDir)) return 0;
  let count = 0;
  const names = fs.readdirSync(srcDir);
  for (const name of names) {
    const fullSrc = path.join(srcDir, name);
    const fullOut = path.join(outDir, name);
    const relModPath = relPrefix ? `${relPrefix}/${name}` : name;
    const stats = fs.statSync(fullSrc);
    if (stats.isDirectory()) {
      count += walkAndCompile(fullSrc, fullOut, isReact, collectedModules, relModPath);
    } else if (/\.(ts|tsx)$/.test(name) && !name.endsWith('.d.ts')) {
      const jsOut = fullOut.replace(/\.(ts|tsx)$/, '.js');
      const compiled = compileSingleFile(fullSrc, jsOut, isReact || name.endsWith('.tsx'));
      if (collectedModules) {
        const modKey = './' + relModPath.replace(/\.(ts|tsx)$/, '');
        collectedModules[modKey] = compiled;
      }
      count += 1;
    } else {
      fs.mkdirSync(path.dirname(fullOut), { recursive: true });
      fs.copyFileSync(fullSrc, fullOut);
    }
  }
  return count;
}

function buildFrontendBrowserBundle(compiledModules, frontendDist) {
  const assetsDir = path.join(frontendDist, 'assets');
  fs.mkdirSync(assetsDir, { recursive: true });

  const cssSrc = path.join(ROOT, 'frontend', 'src', 'styles', 'index.css');
  const cssContent = fs.existsSync(cssSrc) ? fs.readFileSync(cssSrc, 'utf-8') : '';
  fs.writeFileSync(path.join(assetsDir, 'index.css'), cssContent, 'utf-8');

  const moduleEntries = Object.entries(compiledModules)
    .map(([key, code]) => {
      return `${JSON.stringify(key)}: function(module, exports, require) {\n${code}\n}`;
    })
    .join(',\n');

  const bundleJs = `/* APK STUDIO — Production Browser & Android WebView Bundle */
(function() {
  "use strict";

  var componentStates = {};
  var activeCompKey = "root";
  var activeHookIdx = 0;
  var visitedCompKeys = {};
  var rootComponent = null;
  var rootContainer = null;
  var pendingEffects = [];
  var renderScheduled = false;

  function scheduleRender() {
    if (renderScheduled) return;
    renderScheduled = true;
    Promise.resolve().then(performRender);
  }

  function performRender() {
    renderScheduled = false;
    if (!rootComponent || !rootContainer) return;

    var activeEl = document.activeElement;
    var focusFocusKey = activeEl && activeEl.getAttribute ? activeEl.getAttribute("data-focus-key") : null;
    var selStart = activeEl && typeof activeEl.selectionStart === "number" ? activeEl.selectionStart : null;
    var selEnd = activeEl && typeof activeEl.selectionEnd === "number" ? activeEl.selectionEnd : null;

    visitedCompKeys = {};
    pendingEffects = [];
    var domTree = renderVNode(createElement(rootComponent, null), "root", { count: 0 });
    rootContainer.innerHTML = "";
    rootContainer.appendChild(domTree);

    Object.keys(componentStates).forEach(function(k) {
      if (!visitedCompKeys[k]) {
        var st = componentStates[k];
        if (st && st.cleanups) {
          st.cleanups.forEach(function(fn) { if (typeof fn === "function") { try { fn(); } catch(e) {} } });
        }
        delete componentStates[k];
      }
    });

    if (focusFocusKey) {
      var restored = rootContainer.querySelector('[data-focus-key="' + focusFocusKey + '"]');
      if (restored && typeof restored.focus === "function") {
        restored.focus();
        if (selStart !== null && typeof restored.setSelectionRange === "function") {
          try { restored.setSelectionRange(selStart, selEnd); } catch (e) {}
        }
      }
    }

    var effectsToRun = pendingEffects.slice();
    pendingEffects = [];
    effectsToRun.forEach(function(ef) { ef(); });
  }

  function createElement(type, props) {
    var children = [];
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (Array.isArray(c)) {
        for (var j = 0; j < c.length; j++) children.push(c[j]);
      } else {
        children.push(c);
      }
    }
    return {
      type: type,
      props: Object.assign({}, props || {}, {
        children: children.length === 0 ? undefined : (children.length === 1 ? children[0] : children)
      })
    };
  }

  function Fragment(props) { return props.children; }
  function StrictMode(props) { return props.children; }

  function getCompRecord(key) {
    if (!componentStates[key]) {
      componentStates[key] = { hooks: [], deps: [], cleanups: [] };
    }
    return componentStates[key];
  }

  function useState(initialVal) {
    var compKey = activeCompKey;
    var idx = activeHookIdx++;
    var rec = getCompRecord(compKey);
    if (rec.hooks[idx] === undefined) {
      rec.hooks[idx] = typeof initialVal === "function" ? initialVal() : initialVal;
    }
    var setState = function(nextVal) {
      var currentRec = getCompRecord(compKey);
      var resolved = typeof nextVal === "function" ? nextVal(currentRec.hooks[idx]) : nextVal;
      if (resolved !== currentRec.hooks[idx]) {
        currentRec.hooks[idx] = resolved;
        scheduleRender();
      }
    };
    return [rec.hooks[idx], setState];
  }

  function useEffect(cb, deps) {
    var compKey = activeCompKey;
    var idx = activeHookIdx++;
    var rec = getCompRecord(compKey);
    var prevDeps = rec.deps[idx];
    var changed = true;
    if (prevDeps !== undefined && Array.isArray(deps)) {
      changed = deps.length !== prevDeps.length || deps.some(function(d, i) { return d !== prevDeps[i]; });
    }
    if (changed) {
      rec.deps[idx] = deps;
      pendingEffects.push(function() {
        if (typeof rec.cleanups[idx] === "function") {
          try { rec.cleanups[idx](); } catch (e) {}
        }
        try {
          var cleanup = cb();
          rec.cleanups[idx] = typeof cleanup === "function" ? cleanup : null;
        } catch (e) {
          console.error(e);
        }
      });
    }
  }

  function renderVNode(vnode, pathPrefix, inputCounter) {
    if (vnode === null || vnode === undefined || typeof vnode === "boolean") {
      return document.createTextNode("");
    }
    if (typeof vnode === "string" || typeof vnode === "number") {
      return document.createTextNode(String(vnode));
    }
    if (Array.isArray(vnode)) {
      var frag = document.createDocumentFragment();
      vnode.forEach(function(child, idx) {
        frag.appendChild(renderVNode(child, pathPrefix + "." + idx, inputCounter));
      });
      return frag;
    }
    if (typeof vnode.type === "function") {
      var fnName = vnode.type.displayName || vnode.type.name || "Anon";
      var explicitKey = vnode.props && vnode.props.key != null ? String(vnode.props.key) : "";
      var compKey = pathPrefix + "/" + fnName + (explicitKey ? "#" + explicitKey : "");
      visitedCompKeys[compKey] = true;
      var prevKey = activeCompKey;
      var prevIdx = activeHookIdx;
      activeCompKey = compKey;
      activeHookIdx = 0;
      var rendered = vnode.type(vnode.props || {});
      activeCompKey = prevKey;
      activeHookIdx = prevIdx;
      return renderVNode(rendered, compKey, inputCounter);
    }

    var tag = String(vnode.type || "div");
    var isSvg = ["svg", "path", "circle", "rect", "line", "polyline", "polygon", "g"].indexOf(tag) !== -1;
    var el = isSvg
      ? document.createElementNS("http://www.w3.org/2000/svg", tag)
      : document.createElement(tag);

    if (tag === "input" || tag === "textarea" || tag === "select") {
      inputCounter.count += 1;
      el.setAttribute("data-focus-key", pathPrefix + ":input:" + inputCounter.count);
    }

    var props = vnode.props || {};
    Object.keys(props).forEach(function(k) {
      if (k === "children" || k === "key") return;
      var val = props[k];
      if (k === "className") {
        if (isSvg) el.setAttribute("class", val || "");
        else el.className = val || "";
      } else if (k === "style" && val && typeof val === "object") {
        Object.keys(val).forEach(function(sk) {
          var sv = val[sk];
          if (typeof sv === "number" && ["width","height","minWidth","minHeight","maxWidth","maxHeight","padding","paddingLeft","paddingRight","paddingTop","paddingBottom","margin","marginTop","marginBottom","marginLeft","marginRight","borderRadius","fontSize","gap","top","left","right","bottom"].indexOf(sk) !== -1) {
            el.style[sk] = sv + "px";
          } else {
            el.style[sk] = sv;
          }
        });
      } else if (k.indexOf("on") === 0 && typeof val === "function") {
        var evt = k.slice(2).toLowerCase();
        if (evt === "change" && (tag === "input" || tag === "textarea")) {
          var inputType = props.type || "text";
          if (inputType === "file" || inputType === "checkbox" || inputType === "radio" || inputType === "color" || inputType === "range") {
            el.addEventListener("change", val);
          } else {
            el.addEventListener("input", val);
          }
        } else {
          el.addEventListener(evt, val);
        }
      } else if (k === "checked" || k === "disabled" || k === "value" || k === "autoFocus" || k === "spellCheck") {
        el[k] = val;
      } else if (k === "srcDoc") {
        el.srcdoc = val;
      } else if (val !== undefined && val !== null && val !== false) {
        el.setAttribute(k, String(val));
      }
    });

    var ch = props.children;
    if (Array.isArray(ch)) {
      ch.forEach(function(c, i) { el.appendChild(renderVNode(c, pathPrefix + "." + i, inputCounter)); });
    } else if (ch !== undefined && ch !== null) {
      el.appendChild(renderVNode(ch, pathPrefix + ".0", inputCounter));
    }

    if (tag === "select" && props.value !== undefined) {
      el.value = String(props.value);
    }
    return el;
  }

  var ReactShim = {
    createElement: createElement,
    Fragment: Fragment,
    StrictMode: StrictMode,
    useState: useState,
    useEffect: useEffect,
    default: null
  };
  ReactShim.default = ReactShim;

  var ReactDOMClientShim = {
    createRoot: function(container) {
      return {
        render: function(element) {
          rootContainer = container;
          rootComponent = function RootWrapper() { return element; };
          performRender();
        }
      };
    }
  };
  ReactDOMClientShim.default = ReactDOMClientShim;

  function makeIcon(pathData) {
    return function IconComponent(props) {
      var size = (props && props.size) || 16;
      var color = (props && props.color) || "currentColor";
      return createElement("svg", {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: color,
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
      }, createElement("path", { d: pathData }));
    };
  }

  var LucideShim = {
    Layers: makeIcon("M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"),
    Settings: makeIcon("M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"),
    Play: makeIcon("M5 3l14 9-14 9V3z"),
    Sliders: makeIcon("M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"),
    Box: makeIcon("M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"),
    Code: makeIcon("M16 18l6-6-6-6M8 6l-6 6 6 6"),
    Plus: makeIcon("M12 5v14M5 12h14"),
    Trash2: makeIcon("M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"),
    FolderOpen: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Folder: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Terminal: makeIcon("M4 17l6-6-6-6M12 19h8"),
    Edit3: makeIcon("M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"),
    Copy: makeIcon("M9 9h13v13H9zM5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"),
    Save: makeIcon("M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"),
    UploadCloud: makeIcon("M16 16l-4-4-4 4M12 12v9M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"),
    RefreshCw: makeIcon("M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"),
    Smartphone: makeIcon("M5 2h14a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zM12 18h.01"),
    FileCode: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"),
    Image: makeIcon("M3 3h18v18H3zM8.5 8.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM21 15l-5-5L5 21"),
    RotateCcw: makeIcon("M1 4v6h6M3.51 15a9 9 0 1 0 2.13-9.36L1 10"),
    Info: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01"),
    Cpu: makeIcon("M4 4h16v16H4zM9 9h6v6H9z"),
    Wand2: makeIcon("M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M3 21l9-9"),
    FilePlus: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM12 18v-6M9 15h6"),
    FileUp: makeIcon("M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM12 12v6M9 15l3-3 3 3"),
    Upload: makeIcon("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"),
    CheckCircle2: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9 12l2 2 4-4"),
    AlertTriangle: makeIcon("M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01"),
    Sparkles: makeIcon("M12 3l1.9 5.8a2 2 0 0 0 1.3 1.3L21 12l-5.8 1.9a2 2 0 0 0-1.3 1.3L12 21l-1.9-5.8a2 2 0 0 0-1.3-1.3L3 12l5.8-1.9a2 2 0 0 0 1.3-1.3L12 3z"),
    Download: makeIcon("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"),
    AlertCircle: makeIcon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 8v4M12 16h.01"),
    CheckCircle: makeIcon("M22 11.08V12a10 10 0 1 1-5.93-9.14M22 4L12 14.01l-3-3"),
    FolderArchive: makeIcon("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"),
    Wrench: makeIcon("M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z")
  };

  var modules = {
${moduleEntries}
  };

  var cache = {};

  function resolvePath(baseKey, reqPath) {
    if (reqPath === "react") return "react";
    if (reqPath === "react-dom/client" || reqPath === "react-dom") return "react-dom/client";
    if (reqPath === "lucide-react") return "lucide-react";
    if (reqPath.endsWith(".css")) return "__css__";
    var baseParts = baseKey.split("/").slice(0, -1);
    var relParts = reqPath.split("/");
    for (var i = 0; i < relParts.length; i++) {
      var seg = relParts[i];
      if (seg === "." || seg === "") continue;
      if (seg === "..") baseParts.pop();
      else baseParts.push(seg);
    }
    var candidate = "./" + baseParts.filter(Boolean).join("/");
    if (modules[candidate]) return candidate;
    if (modules[candidate + "/index"]) return candidate + "/index";
    return candidate;
  }

  function requireModule(fromKey, reqPath) {
    var resolved = resolvePath(fromKey, reqPath);
    if (resolved === "react") return ReactShim;
    if (resolved === "react-dom/client") return ReactDOMClientShim;
    if (resolved === "lucide-react") return LucideShim;
    if (resolved === "__css__") return {};
    if (cache[resolved]) return cache[resolved].exports;
    var factory = modules[resolved];
    if (!factory) {
      throw new Error("Module not found in bundle: " + reqPath + " (resolved: " + resolved + ")");
    }
    var mod = { exports: {} };
    cache[resolved] = mod;
    factory(mod, mod.exports, function(childReq) {
      return requireModule(resolved, childReq);
    });
    return mod.exports;
  }

  window.addEventListener("DOMContentLoaded", function() {
    requireModule("./main", "./main");
  });
})();
`;

  const outBundlePath = path.join(assetsDir, 'index.js');
  new vm.Script(bundleJs, { filename: outBundlePath });

  fs.writeFileSync(outBundlePath, bundleJs, 'utf-8');

  const prodHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
    <title>APK STUDIO — HTML5 &amp; Python to Android APK Builder</title>
    <link rel="stylesheet" href="./assets/index.css" />
  </head>
  <body>
    <div id="root"></div>
    <script src="./assets/index.js"></script>
  </body>
</html>
`;
  fs.writeFileSync(path.join(frontendDist, 'index.html'), prodHtml, 'utf-8');
}

function syncFrontendToAndroidTemplate(frontendDist) {
  const androidWebappDir = path.join(
    ROOT,
    'build-engine',
    'android-template',
    'app',
    'src',
    'main',
    'assets',
    'webapp'
  );
  removeDirRecursive(androidWebappDir);
  fs.mkdirSync(androidWebappDir, { recursive: true });

  const distIndex = path.join(frontendDist, 'index.html');
  if (fs.existsSync(distIndex)) {
    fs.copyFileSync(distIndex, path.join(androidWebappDir, 'index.html'));
  }
  const distAssets = path.join(frontendDist, 'assets');
  if (fs.existsSync(distAssets)) {
    copyDirRecursive(distAssets, path.join(androidWebappDir, 'assets'));
  }

  const animCssPath = path.join(androidWebappDir, 'apk_studio_animations.css');
  if (!fs.existsSync(animCssPath)) {
    fs.writeFileSync(
      animCssPath,
      '/* APK STUDIO Default Animations */\n:root { --apk-studio-pulse-duration: 2s; --apk-studio-glass-blur: 30px; }\n',
      'utf-8'
    );
  }
  console.log(
    '[Compiler] Synced React production build -> build-engine/android-template/app/src/main/assets/webapp/'
  );
}

if (targetArg === 'all' || targetArg === 'backend') {
  const backendCount = walkAndCompile(
    path.join(ROOT, 'backend', 'src'),
    path.join(ROOT, 'backend', 'dist'),
    false
  );
  console.log(
    `[Compiler] Backend TypeScript compiled & syntax-verified (${backendCount} modules -> backend/dist).`
  );
}

if (targetArg === 'all' || targetArg === 'frontend') {
  const frontendDist = path.join(ROOT, 'frontend', 'dist');
  const collectedModules = {};
  const frontendCount = walkAndCompile(
    path.join(ROOT, 'frontend', 'src'),
    path.join(frontendDist, 'src'),
    true,
    collectedModules,
    ''
  );
  buildFrontendBrowserBundle(collectedModules, frontendDist);
  console.log(
    `[Compiler] Frontend TypeScript/JSX compiled, bundled & syntax-verified (${frontendCount} modules -> frontend/dist/assets/index.js & index.css).`
  );
  syncFrontendToAndroidTemplate(frontendDist);
}
