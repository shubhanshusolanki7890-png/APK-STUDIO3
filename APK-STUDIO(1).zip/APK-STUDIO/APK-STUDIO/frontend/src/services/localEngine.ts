import {
  Project,
  CustomizationSettings,
  AnimationConfig,
  FileTreeNode,
  BuildRecord,
  PythonInspectionResult,
  ToolchainDiagnostics
} from '../types';
import { validateCustomizationClient } from '../utils/validation';

const STORAGE_KEY = 'apk_studio_workspace_v2';
const BACKEND_URL_KEY = 'apk_studio_remote_backend_url';

interface StoredWorkspace {
  projects: Project[];
  customizations: Record<string, CustomizationSettings>;
  animations: Record<string, AnimationConfig>;
  files: Record<string, Record<string, string>>;
  builds: Record<string, BuildRecord>;
  preparedAndroidProjects: Record<string, Record<string, string>>;
}

const BINARY_EXTS = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.bmp',
  '.woff', '.woff2', '.ttf', '.otf', '.eot',
  '.mp3', '.wav', '.ogg', '.mp4', '.webm', '.pdf', '.zip', '.apk'
]);

const UNSUPPORTED_EXTS = new Set([
  '.exe', '.dll', '.msi', '.bat', '.cmd', '.com', '.scr', '.vbs', '.dmg', '.pkg'
]);

const PROHIBITED_PY_MODULES: Record<string, string> = {
  tkinter: 'Desktop Tk GUI cannot render inside an Android WebView.',
  _tkinter: 'Internal Tk C-extension is unavailable on Android.',
  turtle: 'Turtle graphics depends on a desktop X11/Tk window server.',
  win32api: 'Windows native Win32 APIs cannot execute on Linux/Android.',
  win32con: 'Windows native constants/APIs are incompatible with Android.',
  winreg: 'Windows Registry API is unavailable on Android.',
  msvcrt: 'Microsoft Visual C++ runtime console I/O is Windows-only.',
  curses: 'Terminal ncurses interfaces cannot render directly in Android WebView.',
  pygame: 'Pygame requires an SDL2 surface; use HTML5 Canvas or an SDL2 Android port.',
  pyqt5: 'Desktop Qt5 bindings are not supported in WebView hybrid containers.',
  pyqt6: 'Desktop Qt6 bindings are not supported in WebView hybrid containers.',
  pyside2: 'Desktop Qt bindings are not supported in WebView hybrid containers.',
  pyside6: 'Desktop Qt bindings are not supported in WebView hybrid containers.',
  wx: 'wxPython desktop GUI requires native desktop windowing.',
  gtk: 'GTK desktop bindings are not supported on Android.'
};

const NATIVE_WHEEL_PACKAGES: Record<string, string> = {
  numpy: 'Requires Chaquopy or Pyodide prebuilt native Android wheel.',
  pandas: 'Requires Chaquopy/Pyodide native wheel; increases APK size.',
  scipy: 'Heavy Fortran/C++ extensions; verify Chaquopy wheel availability.',
  cv2: 'OpenCV requires native Android .so libraries or OpenCV.js.',
  'opencv-python': 'OpenCV requires native Android .so libraries or OpenCV.js.',
  pil: 'Pillow requires native image codecs (supported via Chaquopy/Pyodide).',
  pillow: 'Pillow requires native image codecs (supported via Chaquopy/Pyodide).',
  cryptography: 'Requires Rust/OpenSSL prebuilt Android binaries.',
  torch: 'PyTorch Mobile / ExecuTorch required instead of desktop torch.',
  tensorflow: 'TensorFlow Lite required on Android instead of full tensorflow.'
};

export const SUPPORTED_PERMISSIONS_LIST = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.ACCESS_WIFI_STATE',
  'android.permission.CAMERA',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.VIBRATE',
  'android.permission.WAKE_LOCK',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.WRITE_EXTERNAL_STORAGE'
];

function randomId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function defaultStarterFiles(projectName: string, type: 'html' | 'python'): Record<string, string> {
  if (type === 'python') {
    return {
      'main.py': `# APK STUDIO Python Entrypoint\nimport json\nimport math\n\ndef compute_metrics():\n    return {\n        "app": "${projectName}",\n        "pi_estimate": round(math.pi, 6),\n        "status": "ready"\n    }\n\ndef run():\n    print("Initializing ${projectName} Python runtime...")\n    print(json.dumps(compute_metrics()))\n\nif __name__ == "__main__":\n    run()\n`,
      'requirements.txt': '# Declare pure-Python or Chaquopy-supported packages here (one per line)\n',
      'index.html': generatePythonBridgeHtml(projectName, 'main.py', `print("Initializing ${projectName} Python runtime...")`)
    };
  }
  return {
    'index.html': `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${projectName}</title>\n  <link rel="stylesheet" href="style.css" />\n</head>\n<body>\n  <div class="card">\n    <div class="badge">APK STUDIO • HTML5 Hybrid</div>\n    <h1>Welcome to ${projectName}</h1>\n    <p>Edit <code>index.html</code>, <code>style.css</code>, and <code>script.js</code> or import a complete website ZIP archive.</p>\n    <button id="action-btn" class="btn">Test Interactive Action</button>\n    <div id="status-box" class="status-box">Ready inside Android WebView Sandbox.</div>\n  </div>\n  <script src="script.js"></script>\n</body>\n</html>\n`,
    'style.css': `* { box-sizing: border-box; margin: 0; padding: 0; }\nbody {\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;\n  min-height: 100vh;\n  padding: 24px;\n  background: linear-gradient(135deg, #1f1c2c 0%, #3a3456 50%, #24243e 100%);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.card {\n  width: 100%;\n  max-width: 380px;\n  padding: 28px 24px;\n  border-radius: 22px;\n  background: rgba(255, 255, 255, 0.08);\n  backdrop-filter: blur(20px);\n  -webkit-backdrop-filter: blur(20px);\n  border: 1px solid rgba(255, 255, 255, 0.15);\n  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35);\n  text-align: center;\n}\n.badge {\n  display: inline-block;\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n  padding: 4px 10px;\n  border-radius: 999px;\n  background: rgba(0, 255, 200, 0.15);\n  color: #00ffc8;\n  margin-bottom: 14px;\n}\nh1 { font-size: 22px; margin-bottom: 10px; }\np { font-size: 13px; color: rgba(255, 255, 255, 0.75); line-height: 1.5; margin-bottom: 20px; }\n.btn {\n  width: 100%;\n  padding: 12px 18px;\n  border-radius: 12px;\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  background: rgba(255, 255, 255, 0.14);\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 600;\n  cursor: pointer;\n}\n.status-box {\n  margin-top: 16px;\n  padding: 10px;\n  border-radius: 10px;\n  background: rgba(0, 0, 0, 0.3);\n  font-size: 12px;\n  color: #00ffc8;\n}\n`,
    'script.js': `document.addEventListener("DOMContentLoaded", () => {\n  console.log("[APK STUDIO] ${projectName} initialized.");\n  const btn = document.getElementById("action-btn");\n  const statusBox = document.getElementById("status-box");\n  let clicks = 0;\n  if (btn && statusBox) {\n    btn.addEventListener("click", () => {\n      clicks += 1;\n      const msg = "Interaction #" + clicks + " at " + new Date().toLocaleTimeString();\n      statusBox.textContent = msg;\n      console.log(msg);\n    });\n  }\n});\n`
  };
}

function generatePythonBridgeHtml(projectName: string, entrypoint: string, pyCode: string): string {
  const esc = (s: string) =>
    String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(projectName)} — Python Runtime Bridge</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(135deg, #1f1c2c 0%, #3a3456 50%, #24243e 100%);
      color: #ffffff;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .card {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 18px;
      padding: 20px;
    }
    .badge {
      display: inline-block;
      font-size: 11px;
      text-transform: uppercase;
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(0, 255, 200, 0.15);
      color: #00ffc8;
      margin-bottom: 10px;
    }
    .btn {
      margin-top: 12px;
      padding: 10px 16px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.25);
      background: rgba(255, 255, 255, 0.14);
      color: #fff;
      font-weight: 600;
      cursor: pointer;
    }
    pre {
      background: rgba(0, 0, 0, 0.45);
      border-radius: 12px;
      padding: 14px;
      font-family: monospace;
      font-size: 12px;
      color: #00ffc8;
      white-space: pre-wrap;
    }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">Python Hybrid Bridge • ${esc(entrypoint)}</span>
    <h1 style="font-size:20px;margin-bottom:6px;">${esc(projectName)}</h1>
    <p style="font-size:13px;color:rgba(255,255,255,0.75);">Embedded Python script packaged for Android WebView execution.</p>
    <button class="btn" onclick="runPythonSimulation()">▶ Execute ${esc(entrypoint)}</button>
  </div>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:8px;">Console Output</h2>
    <pre id="output-console">Ready.</pre>
  </div>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:8px;">Bundled Source (${esc(entrypoint)})</h2>
    <pre id="python-source">${esc(pyCode)}</pre>
  </div>
  <script>
    function runPythonSimulation() {
      var out = document.getElementById('output-console');
      var src = document.getElementById('python-source').textContent || '';
      var lines = ['[Python Runtime] Executing ${esc(entrypoint)}...'];
      var regex = /print\\s*\\(\\s*(?:f?["']([^"']*)["']|([^)]+))\\s*\\)/g;
      var m;
      while ((m = regex.exec(src)) !== null) {
        lines.push(m[1] !== undefined ? m[1] : String(m[2]));
      }
      if (lines.length === 1) lines.push('[Python Runtime] Script completed with exit code 0.');
      out.textContent = lines.join('\\n');
      console.log('[PythonBridge] Execution finished:', lines.join(' | '));
    }
    window.addEventListener('DOMContentLoaded', runPythonSimulation);
  </script>
</body>
</html>`;
}

function generateAnimationStylesheet(anim: AnimationConfig): string {
  const pulseDuration = Number(anim?.pulse_duration_s) || 2.0;
  const glassBlur = Number(anim?.glass_blur_px) ?? 30;
  const pageTransition = anim?.page_transition || 'fade';
  const buttonEffect = anim?.button_effect || 'scale-press';

  let transitionCss = '';
  if (pageTransition === 'fade') {
    transitionCss = 'body { animation: apkStudioFadeIn 0.45s cubic-bezier(0.16, 1, 0.3, 1); }';
  } else if (pageTransition === 'slide-up') {
    transitionCss = 'body { animation: apkStudioSlideUp 0.45s cubic-bezier(0.16, 1, 0.3, 1); }';
  } else if (pageTransition === 'zoom') {
    transitionCss = 'body { animation: apkStudioZoomIn 0.4s cubic-bezier(0.16, 1, 0.3, 1); }';
  }

  let buttonCss = '';
  if (buttonEffect === 'scale-press') {
    buttonCss = 'button, .btn, input[type="submit"] { transition: transform 0.15s ease; } button:active, .btn:active { transform: scale(0.96); }';
  } else if (buttonEffect === 'glow-hover') {
    buttonCss = 'button, .btn { transition: box-shadow 0.25s ease, transform 0.2s ease; } button:active, .btn:active { box-shadow: 0 0 18px rgba(0, 255, 200, 0.55); transform: translateY(-1px); }';
  } else if (buttonEffect === 'ripple') {
    buttonCss = 'button, .btn { position: relative; overflow: hidden; transition: background 0.2s ease; } button:active, .btn:active { opacity: 0.85; }';
  }

  return `/* Auto-generated by APK STUDIO Animation Studio */
:root {
  --apk-studio-pulse-duration: ${pulseDuration}s;
  --apk-studio-glass-blur: ${glassBlur}px;
}
@keyframes apkStudioFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes apkStudioSlideUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
@keyframes apkStudioZoomIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
@keyframes apkStudioPulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.04); opacity: 0.88; } }
.apk-studio-glass { backdrop-filter: blur(${glassBlur}px) saturate(180%); -webkit-backdrop-filter: blur(${glassBlur}px) saturate(180%); }
.apk-studio-pulse { animation: apkStudioPulse ${pulseDuration}s ease-in-out infinite; }
${transitionCss}
${buttonCss}
`;
}

let memoryWorkspace: StoredWorkspace | null = null;

function loadWorkspace(): StoredWorkspace {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw) as StoredWorkspace;
      parsed.preparedAndroidProjects = parsed.preparedAndroidProjects || {};
      return parsed;
    }
  } catch {
    // ignore storage read error
  }
  if (memoryWorkspace) return memoryWorkspace;

  const starterId = 'default-liquid-showcase';
  const now = new Date().toISOString();
  const initial: StoredWorkspace = {
    projects: [
      {
        id: starterId,
        name: 'Liquid Glass Showcase',
        type: 'html',
        status: 'ready',
        created_at: now,
        updated_at: now,
        app_name: 'Liquid Glass Showcase',
        package_id: 'com.apkstudio.liquidshowcase',
        version_name: '1.0.0',
        version_code: 1,
        last_build_status: null
      }
    ],
    customizations: {
      [starterId]: {
        app_name: 'Liquid Glass Showcase',
        package_id: 'com.apkstudio.liquidshowcase',
        version_name: '1.0.0',
        version_code: 1,
        orientation: 'portrait',
        fullscreen: false,
        status_bar_color: '#1f1c2c',
        nav_bar_color: '#1f1c2c',
        light_status_bar: false,
        theme_color: '#6c5ce7',
        background_color: '#1f1c2c',
        offline_mode: 'cache_first',
        allow_cleartext: true,
        enable_zoom: false,
        keep_screen_on: false,
        splash_enabled: true,
        splash_color: '#1f1c2c',
        splash_duration_ms: 1500,
        splash_animation: 'fade',
        icon_data_url: null,
        splash_image_data_url: null,
        permissions: ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']
      }
    },
    animations: {
      [starterId]: {
        splash_animation: 'fade',
        splash_duration_ms: 1500,
        pulse_duration_s: 2.0,
        glass_blur_px: 30,
        page_transition: 'fade',
        loader_style: 'spinner',
        button_effect: 'scale-press',
        inject_stylesheet: true
      }
    },
    files: {
      [starterId]: defaultStarterFiles('Liquid Glass Showcase', 'html')
    },
    builds: {},
    preparedAndroidProjects: {}
  };
  saveWorkspace(initial);
  return initial;
}

function saveWorkspace(ws: StoredWorkspace): void {
  memoryWorkspace = ws;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(ws));
    }
  } catch {
    // ignore quota error
  }
}

function normalizeRelPath(filePath: string): string {
  const cleaned = String(filePath || '')
    .replace(/\\/g, '/')
    .replace(/^\/+/, '');
  if (!cleaned || cleaned.includes('\0')) {
    throw new Error('Invalid file path.');
  }
  const parts = cleaned.split('/');
  for (const part of parts) {
    if (part === '..') {
      throw new Error('Access denied: Path traversal detected.');
    }
  }
  return parts.filter(Boolean).join('/');
}

function getExt(p: string): string {
  const idx = p.lastIndexOf('.');
  return idx >= 0 ? p.slice(idx).toLowerCase() : '';
}

/**
 * Pure JavaScript CRC32 & ZIP Archive Builder so users can export real `.zip`
 * Android Gradle projects directly from inside the Android WebView or browser.
 */
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function buildZipUint8Array(filesMap: Record<string, string>): Uint8Array {
  const encoder = new TextEncoder();
  const entries: Array<{
    nameBytes: Uint8Array;
    dataBytes: Uint8Array;
    crc: number;
    offset: number;
  }> = [];

  let offset = 0;
  const localChunks: Uint8Array[] = [];

  for (const [relPath, content] of Object.entries(filesMap)) {
    const nameBytes = encoder.encode(relPath);
    let dataBytes: Uint8Array;
    if (content.startsWith('data:') && content.includes(';base64,')) {
      const b64 = content.split(';base64,')[1] || '';
      const binStr = atob(b64);
      dataBytes = new Uint8Array(binStr.length);
      for (let i = 0; i < binStr.length; i++) dataBytes[i] = binStr.charCodeAt(i);
    } else {
      dataBytes = encoder.encode(content);
    }

    const crc = crc32(dataBytes);
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const view = new DataView(localHeader.buffer);
    view.setUint32(0, 0x04034b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 0, true);
    view.setUint16(8, 0, true); // STORED
    view.setUint16(10, 0, true);
    view.setUint16(12, 0x21, true);
    view.setUint32(14, crc, true);
    view.setUint32(18, dataBytes.length, true);
    view.setUint32(22, dataBytes.length, true);
    view.setUint16(26, nameBytes.length, true);
    view.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    entries.push({ nameBytes, dataBytes, crc, offset });
    localChunks.push(localHeader, dataBytes);
    offset += localHeader.length + dataBytes.length;
  }

  const centralChunks: Uint8Array[] = [];
  let centralSize = 0;
  for (const entry of entries) {
    const cHeader = new Uint8Array(46 + entry.nameBytes.length);
    const view = new DataView(cHeader.buffer);
    view.setUint32(0, 0x02014b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 20, true);
    view.setUint16(8, 0, true);
    view.setUint16(10, 0, true);
    view.setUint16(12, 0, true);
    view.setUint16(14, 0x21, true);
    view.setUint32(16, entry.crc, true);
    view.setUint32(20, entry.dataBytes.length, true);
    view.setUint32(24, entry.dataBytes.length, true);
    view.setUint16(28, entry.nameBytes.length, true);
    view.setUint16(30, 0, true);
    view.setUint16(32, 0, true);
    view.setUint16(34, 0, true);
    view.setUint16(36, 0, true);
    view.setUint32(38, 0, true);
    view.setUint32(42, entry.offset, true);
    cHeader.set(entry.nameBytes, 46);
    centralChunks.push(cHeader);
    centralSize += cHeader.length;
  }

  const eocd = new Uint8Array(22);
  const eView = new DataView(eocd.buffer);
  eView.setUint32(0, 0x06054b50, true);
  eView.setUint16(4, 0, true);
  eView.setUint16(6, 0, true);
  eView.setUint16(8, entries.length, true);
  eView.setUint16(10, entries.length, true);
  eView.setUint32(12, centralSize, true);
  eView.setUint32(16, offset, true);
  eView.setUint16(20, 0, true);

  const totalLen = offset + centralSize + 22;
  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const chunk of localChunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  for (const chunk of centralChunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  out.set(eocd, pos);
  return out;
}

/**
 * Pure browser/WebView binary ZIP reader supporting STORED (0) and DEFLATE (8).
 */
async function extractZipBuffer(buffer: ArrayBuffer): Promise<{
  files: Record<string, string>;
  extractedFiles: string[];
  skippedUnsupportedFiles: string[];
  flattenedRoot: boolean;
}> {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  if (bytes.length < 22 || view.getUint32(0, true) !== 0x04034b50) {
    throw new Error('Corrupted or invalid ZIP archive.');
  }

  // Locate End of Central Directory (0x06054b50)
  let eocdOffset = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset === -1) {
    throw new Error('Invalid ZIP archive: End of Central Directory not found.');
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const cdOffset = view.getUint32(eocdOffset + 16, true);
  const decoder = new TextDecoder('utf-8');

  const rawEntries: Array<{ path: string; content: string }> = [];
  const skippedUnsupportedFiles: string[] = [];
  let ptr = cdOffset;

  for (let idx = 0; idx < totalEntries; idx++) {
    if (ptr + 46 > bytes.length || view.getUint32(ptr, true) !== 0x02014b50) break;
    const compressionMethod = view.getUint16(ptr + 10, true);
    const compressedSize = view.getUint32(ptr + 20, true);
    const nameLen = view.getUint16(ptr + 28, true);
    const extraLen = view.getUint16(ptr + 30, true);
    const commentLen = view.getUint16(ptr + 32, true);
    const localHeaderOffset = view.getUint32(ptr + 42, true);

    const rawName = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + nameLen)).replace(/\\/g, '/');
    ptr += 46 + nameLen + extraLen + commentLen;

    if (rawName.startsWith('__MACOSX/') || rawName.endsWith('.DS_Store')) continue;
    if (rawName.startsWith('/') || rawName.includes('../') || rawName.startsWith('..')) {
      throw new Error(`Malicious zip entry path detected: ${rawName}`);
    }
    if (rawName.endsWith('/')) continue;

    const ext = getExt(rawName);
    if (UNSUPPORTED_EXTS.has(ext)) {
      skippedUnsupportedFiles.push(rawName);
      continue;
    }

    const localNameLen = view.getUint16(localHeaderOffset + 26, true);
    const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
    const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
    const compressedSlice = bytes.subarray(dataStart, dataStart + compressedSize);

    let uncompressedBytes: Uint8Array;
    if (compressionMethod === 0) {
      uncompressedBytes = compressedSlice;
    } else if (compressionMethod === 8 && typeof DecompressionStream !== 'undefined') {
      const ds = new DecompressionStream('deflate-raw');
      const writer = ds.writable.getWriter();
      writer.write(compressedSlice);
      writer.close();
      const resp = new Response(ds.readable);
      uncompressedBytes = new Uint8Array(await resp.arrayBuffer());
    } else {
      throw new Error(`Unsupported ZIP compression method (${compressionMethod}) for ${rawName}`);
    }

    let contentStr: string;
    if (BINARY_EXTS.has(ext)) {
      let binary = '';
      for (let i = 0; i < uncompressedBytes.length; i++) {
        binary += String.fromCharCode(uncompressedBytes[i]);
      }
      contentStr = `data:application/octet-stream;base64,${btoa(binary)}`;
    } else {
      contentStr = decoder.decode(uncompressedBytes);
    }

    rawEntries.push({ path: rawName, content: contentStr });
  }

  const topHasIndex = rawEntries.some((e) => e.path.toLowerCase() === 'index.html');
  const hasRootFiles = rawEntries.some((e) => !e.path.includes('/'));
  const firstSegments = new Set(
    rawEntries.filter((e) => e.path.includes('/')).map((e) => e.path.split('/')[0])
  );

  let flattenedRoot = false;
  let prefix = '';
  if (!topHasIndex && !hasRootFiles && firstSegments.size === 1) {
    flattenedRoot = true;
    prefix = `${Array.from(firstSegments)[0]}/`;
  }

  const files: Record<string, string> = {};
  const extractedFiles: string[] = [];
  for (const item of rawEntries) {
    const finalPath = flattenedRoot && item.path.startsWith(prefix)
      ? item.path.slice(prefix.length)
      : item.path;
    if (!finalPath) continue;
    files[finalPath] = item.content;
    extractedFiles.push(finalPath);
  }

  return { files, extractedFiles, skippedUnsupportedFiles, flattenedRoot };
}

export const LocalEngine = {
  getRemoteBackendUrl(): string {
    try {
      return (typeof localStorage !== 'undefined' && localStorage.getItem(BACKEND_URL_KEY)) || '';
    } catch {
      return '';
    }
  },

  setRemoteBackendUrl(url: string): void {
    try {
      if (typeof localStorage !== 'undefined') {
        const cleaned = url.trim().replace(/\/+$/, '');
        if (cleaned) localStorage.setItem(BACKEND_URL_KEY, cleaned);
        else localStorage.removeItem(BACKEND_URL_KEY);
      }
    } catch {
      // ignore
    }
  },

  getSystemDiagnostics(): {
    status: string;
    toolchain: ToolchainDiagnostics;
    supportedPermissions: string[];
  } {
    return {
      status: 'on-device-webview',
      toolchain: {
        readyForNativeBuild: false,
        javaAvailable: false,
        javaVersion: null,
        javacAvailable: false,
        javacVersion: null,
        androidSdkAvailable: false,
        androidHomePath: '/opt/android-sdk',
        platform34Installed: false,
        buildToolsInstalled: false,
        gradleAvailable: false,
        gradleVersion: null,
        missingComponents: [
          'Remote Build Server or Host Android SDK (running in On-Device Standalone Mode)'
        ],
        setupInstructions: [
          'Click "Export Android Gradle Project (.zip)" below to download the ready-to-compile Android project with GitHub Actions & Gradle Wrapper.',
          'Or configure a Remote Build Server URL in the top header bar to delegate Gradle compilation to a workstation or Docker host.'
        ]
      },
      supportedPermissions: SUPPORTED_PERMISSIONS_LIST
    };
  },

  listProjects(): Project[] {
    const ws = loadWorkspace();
    return ws.projects.slice().sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  },

  createProject(name: string, type: 'html' | 'python'): Project {
    const trimmed = (name || '').trim();
    if (!trimmed || !['html', 'python'].includes(type)) {
      throw new Error("Valid project name and type ('html' or 'python') are required.");
    }
    const ws = loadWorkspace();
    const id = randomId();
    const now = new Date().toISOString();
    const cleanPkg = trimmed.toLowerCase().replace(/[^a-z0-9]/g, '');
    const safeSeg = cleanPkg && /^[a-z]/.test(cleanPkg) ? cleanPkg : `app${cleanPkg}`;
    const packageId = `com.apkstudio.${safeSeg}`;

    const project: Project = {
      id,
      name: trimmed,
      type,
      status: 'ready',
      created_at: now,
      updated_at: now,
      app_name: trimmed,
      package_id: packageId,
      version_name: '1.0.0',
      version_code: 1,
      last_build_status: null
    };

    ws.projects.unshift(project);
    ws.customizations[id] = {
      app_name: trimmed,
      package_id: packageId,
      version_name: '1.0.0',
      version_code: 1,
      orientation: 'portrait',
      fullscreen: false,
      status_bar_color: '#1f1c2c',
      nav_bar_color: '#1f1c2c',
      light_status_bar: false,
      theme_color: '#6c5ce7',
      background_color: '#1f1c2c',
      offline_mode: 'cache_first',
      allow_cleartext: true,
      enable_zoom: false,
      keep_screen_on: false,
      splash_enabled: true,
      splash_color: '#1f1c2c',
      splash_duration_ms: 1500,
      splash_animation: 'fade',
      icon_data_url: null,
      splash_image_data_url: null,
      permissions: ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']
    };
    ws.animations[id] = {
      splash_animation: 'fade',
      splash_duration_ms: 1500,
      pulse_duration_s: 2.0,
      glass_blur_px: 30,
      page_transition: 'fade',
      loader_style: 'spinner',
      button_effect: 'scale-press',
      inject_stylesheet: true
    };
    ws.files[id] = defaultStarterFiles(trimmed, type);
    saveWorkspace(ws);
    return project;
  },

  getProject(id: string): {
    project: Project;
    customization: CustomizationSettings;
    animations: AnimationConfig;
  } {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    return {
      project,
      customization: ws.customizations[id],
      animations: ws.animations[id]
    };
  },

  renameProject(id: string, name: string): Project {
    const trimmed = (name || '').trim();
    if (!trimmed) throw new Error('A non-empty project name is required.');
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    project.name = trimmed;
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return project;
  },

  duplicateProject(id: string, customName?: string): Project {
    const ws = loadWorkspace();
    const src = ws.projects.find((p) => p.id === id);
    if (!src) throw new Error('Source project not found');
    const newId = randomId();
    const now = new Date().toISOString();
    const newName = (customName && customName.trim()) || `${src.name} (Copy)`;
    const suffix = Math.random().toString(36).substring(2, 6);
    const srcCust = ws.customizations[id];
    const newPkg = `${srcCust?.package_id || 'com.apkstudio.app'}copy${suffix}`;

    const duplicated: Project = {
      ...src,
      id: newId,
      name: newName,
      app_name: newName,
      package_id: newPkg,
      created_at: now,
      updated_at: now,
      last_build_status: null
    };

    ws.projects.unshift(duplicated);
    ws.customizations[newId] = {
      ...srcCust,
      app_name: newName,
      package_id: newPkg
    };
    ws.animations[newId] = { ...ws.animations[id] };
    ws.files[newId] = { ...(ws.files[id] || {}) };
    saveWorkspace(ws);
    return duplicated;
  },

  updateCustomization(
    id: string,
    settings: CustomizationSettings
  ): { success: boolean; customization: CustomizationSettings } {
    const errs = validateCustomizationClient(settings);
    if (errs.length > 0) {
      throw new Error(errs.join(' '));
    }
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    ws.customizations[id] = { ...settings };
    project.app_name = settings.app_name;
    project.package_id = settings.package_id;
    project.version_name = settings.version_name;
    project.version_code = settings.version_code;
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return { success: true, customization: ws.customizations[id] };
  },

  updateAnimations(
    id: string,
    animations: AnimationConfig
  ): { success: boolean; animations: AnimationConfig } {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    ws.animations[id] = { ...animations };
    if (ws.customizations[id]) {
      ws.customizations[id].splash_animation = animations.splash_animation;
      ws.customizations[id].splash_duration_ms = animations.splash_duration_ms;
    }
    if (animations.inject_stylesheet !== false) {
      ws.files[id] = ws.files[id] || {};
      ws.files[id]['apk_studio_animations.css'] = generateAnimationStylesheet(animations);
    }
    project.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    return { success: true, animations: ws.animations[id] };
  },

  deleteProject(id: string): void {
    const ws = loadWorkspace();
    ws.projects = ws.projects.filter((p) => p.id !== id);
    delete ws.customizations[id];
    delete ws.animations[id];
    delete ws.files[id];
    for (const [bId, b] of Object.entries(ws.builds)) {
      if (b.project_id === id) {
        delete ws.builds[bId];
        delete ws.preparedAndroidProjects[bId];
      }
    }
    saveWorkspace(ws);
  },

  getFileTree(projectId: string): FileTreeNode[] {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    const rootNodes: FileTreeNode[] = [];

    for (const [relPath, content] of Object.entries(fileMap)) {
      const parts = relPath.split('/').filter(Boolean);
      let currentLevel = rootNodes;
      let builtPath = '';

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        builtPath = builtPath ? `${builtPath}/${part}` : part;
        const isLast = i === parts.length - 1;

        if (isLast) {
          const ext = getExt(part);
          const isBin = BINARY_EXTS.has(ext) || content.startsWith('data:image/');
          currentLevel.push({
            name: part,
            path: builtPath,
            isDirectory: false,
            size: content.length,
            isBinary: isBin
          });
        } else {
          let dirNode = currentLevel.find((n) => n.isDirectory && n.name === part);
          if (!dirNode) {
            dirNode = {
              name: part,
              path: builtPath,
              isDirectory: true,
              children: []
            };
            currentLevel.push(dirNode);
          }
          currentLevel = dirNode.children!;
        }
      }
    }

    const sortTree = (nodes: FileTreeNode[]) => {
      nodes.sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name);
      });
      for (const n of nodes) {
        if (n.children) sortTree(n.children);
      }
    };
    sortTree(rootNodes);
    return rootNodes;
  },

  getFile(projectId: string, filePath: string): { content: string; isBinary: boolean; path: string } {
    const norm = normalizeRelPath(filePath);
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    if (fileMap[norm] === undefined) {
      throw new Error(`File not found: ${norm}`);
    }
    const raw = fileMap[norm];
    const isBinary = BINARY_EXTS.has(getExt(norm)) || raw.startsWith('data:application/octet-stream');
    return {
      content: isBinary ? `/* Binary asset (${norm}, ${raw.length} bytes) */` : raw,
      isBinary,
      path: norm
    };
  },

  saveFile(projectId: string, filePath: string, content: string): void {
    const norm = normalizeRelPath(filePath);
    const ext = getExt(norm);
    if (UNSUPPORTED_EXTS.has(ext)) {
      throw new Error(`Unsupported executable file type: ${ext}`);
    }
    const ws = loadWorkspace();
    ws.files[projectId] = ws.files[projectId] || {};
    ws.files[projectId][norm] = String(content);
    const p = ws.projects.find((proj) => proj.id === projectId);
    if (p) p.updated_at = new Date().toISOString();
    saveWorkspace(ws);
  },

  deleteFile(projectId: string, filePath: string): void {
    const norm = normalizeRelPath(filePath);
    const ws = loadWorkspace();
    if (ws.files[projectId]) {
      delete ws.files[projectId][norm];
      for (const k of Object.keys(ws.files[projectId])) {
        if (k.startsWith(`${norm}/`)) delete ws.files[projectId][k];
      }
      saveWorkspace(ws);
    }
  },

  async importSingleFile(
    projectId: string,
    file: File,
    targetPath?: string
  ): Promise<{ success: boolean; importedFile: string }> {
    const norm = normalizeRelPath(targetPath || file.name || 'index.html');
    const ext = getExt(norm);
    if (UNSUPPORTED_EXTS.has(ext)) {
      throw new Error(`Unsupported file type: ${ext}`);
    }
    const content: string = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('Failed to read imported file'));
      if (BINARY_EXTS.has(ext)) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
    this.saveFile(projectId, norm, content);
    return { success: true, importedFile: norm };
  },

  async uploadZip(
    projectId: string,
    file: File
  ): Promise<{
    success: boolean;
    filesExtracted: string[];
    skippedUnsupportedFiles: string[];
    flattenedRoot: boolean;
    hasIndexHtml: boolean;
    warnings: string[];
  }> {
    const buffer = await file.arrayBuffer();
    const extracted = await extractZipBuffer(buffer);
    const ws = loadWorkspace();
    ws.files[projectId] = ws.files[projectId] || {};
    for (const [k, v] of Object.entries(extracted.files)) {
      ws.files[projectId][k] = v;
    }
    const p = ws.projects.find((proj) => proj.id === projectId);
    if (p) p.updated_at = new Date().toISOString();
    saveWorkspace(ws);
    const hasIndexHtml = Boolean(ws.files[projectId]['index.html']);
    return {
      success: true,
      filesExtracted: extracted.extractedFiles,
      skippedUnsupportedFiles: extracted.skippedUnsupportedFiles,
      flattenedRoot: extracted.flattenedRoot,
      hasIndexHtml,
      warnings: hasIndexHtml
        ? []
        : ["Uploaded archive does not contain an 'index.html' file at the root level."]
    };
  },

  inspectPython(projectId: string): PythonInspectionResult {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    const entryCandidates = ['main.py', 'app.py', 'index.py', 'server.py'];
    const detectedEntry = entryCandidates.find((e) => fileMap[e] !== undefined) || null;
    const pyFiles = Object.keys(fileMap)
      .filter((f) => f.endsWith('.py'))
      .sort();
    const hasHtmlBridge = fileMap['index.html'] !== undefined;

    if (!detectedEntry) {
      return {
        supported: false,
        classification: 'unsupported',
        entrypoint: null,
        has_html_bridge: hasHtmlBridge,
        python_files: pyFiles,
        detected_imports: [],
        declared_dependencies: [],
        native_or_heavy_dependencies: [],
        modification_reasons: [],
        unsupported_modules: [],
        recommendations: ['Create or rename your primary Python file to main.py or app.py.'],
        error: 'Missing main entrypoint. Provide main.py, app.py, index.py, or server.py.'
      };
    }

    const imports = new Set<string>();
    const unsupported: Array<{ module: string; reason: string; file?: string }> = [];
    let usesBlockingInput = false;

    for (const pyFile of pyFiles) {
      const src = fileMap[pyFile] || '';
      const lines = src.split(/\r?\n/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const impMatch = trimmed.match(/^import\s+([a-zA-Z0-9_.,\s]+)/);
        if (impMatch) {
          for (const part of impMatch[1].split(',')) {
            const mod = part.trim().split(/\s+as\s+/)[0].split('.')[0];
            if (mod) {
              imports.add(mod);
              if (PROHIBITED_PY_MODULES[mod.toLowerCase()]) {
                unsupported.push({
                  module: mod,
                  reason: PROHIBITED_PY_MODULES[mod.toLowerCase()],
                  file: pyFile
                });
              }
            }
          }
        }
        const fromMatch = trimmed.match(/^from\s+([a-zA-Z0-9_.]+)\s+import\s+/);
        if (fromMatch) {
          const mod = fromMatch[1].split('.')[0];
          if (mod) {
            imports.add(mod);
            if (PROHIBITED_PY_MODULES[mod.toLowerCase()]) {
              unsupported.push({
                module: mod,
                reason: PROHIBITED_PY_MODULES[mod.toLowerCase()],
                file: pyFile
              });
            }
          }
        }
        if (/\binput\s*\(/.test(trimmed)) {
          usesBlockingInput = true;
        }
      }
    }

    const reqContent = fileMap['requirements.txt'] || '';
    const dependencies = reqContent
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'));

    if (unsupported.length > 0) {
      return {
        supported: false,
        classification: 'unsupported',
        entrypoint: detectedEntry,
        has_html_bridge: hasHtmlBridge,
        python_files: pyFiles,
        detected_imports: Array.from(imports).sort(),
        declared_dependencies: dependencies,
        native_or_heavy_dependencies: [],
        modification_reasons: [],
        unsupported_modules: unsupported,
        recommendations: unsupported.map((u) => `Replace ${u.module} (${u.reason})`),
        error: 'Incompatible desktop/native modules detected.'
      };
    }

    const nativeDeps: Array<{ package: string; note: string }> = [];
    for (const imp of Array.from(imports)) {
      if (NATIVE_WHEEL_PACKAGES[imp.toLowerCase()]) {
        nativeDeps.push({ package: imp, note: NATIVE_WHEEL_PACKAGES[imp.toLowerCase()] });
      }
    }

    const modReasons: string[] = [];
    const recommendations: string[] = [];
    if (!hasHtmlBridge) {
      modReasons.push(
        'Missing index.html WebView UI bridge. Android WebView requires an HTML entrypoint to display output.'
      );
      recommendations.push(
        "Use 'Generate / Refresh HTML Bridge' to create an index.html wrapper for your Python script."
      );
    }
    if (usesBlockingInput) {
      modReasons.push(
        'Uses blocking standard input `input()`, which hangs in non-interactive WebView environments.'
      );
    }
    if (nativeDeps.length > 0) {
      modReasons.push(
        `Uses native/C-extension packages (${nativeDeps.map((d) => d.package).join(', ')}) requiring Chaquopy or Pyodide wheels.`
      );
    }

    return {
      supported: true,
      classification: modReasons.length > 0 ? 'requires_modification' : 'supported',
      entrypoint: detectedEntry,
      has_html_bridge: hasHtmlBridge,
      python_files: pyFiles,
      detected_imports: Array.from(imports).sort(),
      declared_dependencies: dependencies,
      native_or_heavy_dependencies: nativeDeps,
      modification_reasons: modReasons,
      unsupported_modules: [],
      recommendations:
        recommendations.length > 0
          ? recommendations
          : ['Project is clean and ready for hybrid Android WebView packaging.']
    };
  },

  generatePythonBridge(
    projectId: string,
    entrypoint = 'main.py'
  ): { success: boolean; generatedFile: string; inspection: PythonInspectionResult } {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === projectId);
    if (!project) throw new Error('Project not found');
    const pyCode = (ws.files[projectId] && ws.files[projectId][entrypoint]) || '# Python script';
    const html = generatePythonBridgeHtml(project.name, entrypoint, pyCode);
    this.saveFile(projectId, 'index.html', html);
    return {
      success: true,
      generatedFile: 'index.html',
      inspection: this.inspectPython(projectId)
    };
  },

  /**
   * Compiles a self-contained HTML `srcdoc` string for LivePreviewPane so live preview
   * works identically inside the Android APK WebView (`file://`) and standard browsers.
   */
  compileLivePreviewSrcDoc(projectId: string): string {
    const ws = loadWorkspace();
    const fileMap = ws.files[projectId] || {};
    let html = fileMap['index.html'] || '<!DOCTYPE html><html><body><p>No index.html found.</p></body></html>';

    // Inline local CSS <link rel="stylesheet" href="...">
    html = html.replace(
      /<link\s+[^>]*href=["']([^"']+\.css)["'][^>]*>/gi,
      (fullMatch, href) => {
        const cleanHref = href.replace(/^\.?\//, '');
        if (fileMap[cleanHref] !== undefined) {
          return `<style data-source="${cleanHref}">\n${fileMap[cleanHref]}\n</style>`;
        }
        return fullMatch;
      }
    );

    if (fileMap['apk_studio_animations.css'] && !html.includes('apk_studio_animations.css')) {
      const animStyle = `<style data-source="apk_studio_animations.css">\n${fileMap['apk_studio_animations.css']}\n</style>`;
      html = html.includes('</head>')
        ? html.replace('</head>', `${animStyle}\n</head>`)
        : `${animStyle}\n${html}`;
    }

    // Inline local JS <script src="..."></script>
    html = html.replace(
      /<script\s+[^>]*src=["']([^"']+\.js)["'][^>]*>\s*<\/script>/gi,
      (fullMatch, src) => {
        const cleanSrc = src.replace(/^\.?\//, '');
        if (fileMap[cleanSrc] !== undefined) {
          return `<script data-source="${cleanSrc}">\n${fileMap[cleanSrc]}\n</script>`;
        }
        return fullMatch;
      }
    );

    const bridgeScript = `<script>
(function() {
  function sendToStudio(level, args) {
    try {
      var msg = Array.prototype.slice.call(args).map(function(a) {
        if (a instanceof Error) return a.stack || a.message;
        if (typeof a === 'object') { try { return JSON.stringify(a); } catch(e) { return String(a); } }
        return String(a);
      }).join(' ');
      window.parent.postMessage({
        source: 'apk-studio-preview',
        level: level,
        message: msg,
        timestamp: new Date().toISOString()
      }, '*');
    } catch (e) {}
  }
  var origLog = console.log;
  var origWarn = console.warn;
  var origError = console.error;
  console.log = function() { sendToStudio('info', arguments); origLog.apply(console, arguments); };
  console.warn = function() { sendToStudio('warn', arguments); origWarn.apply(console, arguments); };
  console.error = function() { sendToStudio('error', arguments); origError.apply(console, arguments); };
  window.addEventListener('error', function(ev) {
    sendToStudio('error', [ev.message + (ev.filename ? ' (' + ev.filename + ':' + ev.lineno + ')' : '')]);
  });
})();
</script>`;

    return html.includes('<head>')
      ? html.replace('<head>', `<head>${bridgeScript}`)
      : `${bridgeScript}${html}`;
  },

  triggerBuild(
    projectId: string,
    buildType: 'debug' | 'release' = 'debug'
  ): { buildId: string; status: string; buildType: string } {
    const ws = loadWorkspace();
    const project = ws.projects.find((p) => p.id === projectId);
    if (!project) throw new Error('Project not found');
    const config = ws.customizations[projectId];
    const anim = ws.animations[projectId];
    const fileMap = ws.files[projectId] || {};

    const buildId = randomId();
    const now = new Date().toISOString();
    let log = `[Build Engine] Initializing ${buildType.toUpperCase()} build for project "${project.name}" (${projectId})\n`;
    log += `[Stage 1/7] Validating project structure and customization parameters...\n`;

    if (!fileMap['index.html'] && project.type === 'python') {
      const pyRes = this.inspectPython(projectId);
      if (!pyRes.supported || pyRes.classification === 'unsupported') {
        const failedRecord: BuildRecord = {
          id: buildId,
          project_id: projectId,
          build_type: buildType,
          status: 'failed',
          stage: 'failed',
          progress: 20,
          started_at: now,
          completed_at: new Date().toISOString(),
          log: log + `\n[Build Engine ERROR] ${pyRes.error || 'Unsupported Python modules.'}\n`,
          error_summary: pyRes.error || 'Unsupported Python modules.'
        };
        ws.builds[buildId] = failedRecord;
        project.last_build_status = 'failed';
        saveWorkspace(ws);
        return { buildId, status: 'failed', buildType };
      }
      this.generatePythonBridge(projectId, pyRes.entrypoint || 'main.py');
    }

    const updatedFiles = loadWorkspace().files[projectId] || {};
    if (!updatedFiles['index.html']) {
      const failedRecord: BuildRecord = {
        id: buildId,
        project_id: projectId,
        build_type: buildType,
        status: 'failed',
        stage: 'failed',
        progress: 20,
        started_at: now,
        completed_at: new Date().toISOString(),
        log: log + "\n[Build Engine ERROR] Project must contain an 'index.html' entrypoint at its root.\n",
        error_summary: "Project must contain an 'index.html' entrypoint at its root."
      };
      ws.builds[buildId] = failedRecord;
      project.last_build_status = 'failed';
      saveWorkspace(ws);
      return { buildId, status: 'failed', buildType };
    }

    log += `[Stage 2/7] Preparing isolated Android Gradle project in build workspace...\n`;
    log += `[Stage 3/7] Applying package ID (${config.package_id}), version ${config.version_name} (${config.version_code}), permissions, and theme...\n`;
    log += `[Stage 4/7] Packaging ${Object.keys(updatedFiles).length} project file(s) and Animation Studio presets into app/src/main/assets/webapp/...\n`;
    log += `[Stage 5/7] Checking host Android SDK, JDK compiler, and Gradle toolchain...\n`;
    log += `  - Running in On-Device Standalone Mode (no local Android SDK/Gradle daemon on mobile WebView).\n`;
    log += `\n[Build Engine READY FOR EXPORT OR REMOTE COMPILATION]\n`;
    log += `  • Your complete Android Studio Gradle project (${config.package_id}) has been generated and verified.\n`;
    log += `  • Click "Export Android Gradle Project (.zip)" above to download the ready-to-compile Android project (includes Gradle Wrapper & GitHub Actions workflow).\n`;
    log += `  • Or connect a Remote Build Server URL in the top navigation bar to compile the APK binary over the network.\n`;

    // Store prepared Android project files for instant ZIP export
    const preparedFiles: Record<string, string> = {
      'settings.gradle': `pluginManagement {\n    repositories {\n        google()\n        mavenCentral()\n        gradlePluginPortal()\n    }\n}\ndependencyResolutionManagement {\n    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n    repositories {\n        google()\n        mavenCentral()\n    }\n}\nrootProject.name = "APKStudioApp"\ninclude ':app'\n`,
      'build.gradle': `plugins {\n    id 'com.android.application' version '8.2.2' apply false\n}\n`,
      'gradle.properties': `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nandroid.enableJetifier=true\nandroid.nonTransitiveRClass=true\n`,
      'gradle/wrapper/gradle-wrapper.properties': `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\n`,
      'app/build.gradle': `plugins {\n    id 'com.android.application'\n}\nandroid {\n    namespace 'com.apkstudio.app'\n    compileSdk 34\n    defaultConfig {\n        applicationId "${config.package_id}"\n        minSdk 24\n        targetSdk 34\n        versionCode ${config.version_code}\n        versionName "${config.version_name}"\n    }\n    compileOptions {\n        sourceCompatibility JavaVersion.VERSION_17\n        targetCompatibility JavaVersion.VERSION_17\n    }\n}\ndependencies {\n    implementation 'androidx.appcompat:appcompat:1.6.1'\n    implementation 'com.google.android.material:material:1.11.0'\n    implementation 'androidx.webkit:webkit:1.10.0'\n    implementation 'androidx.activity:activity:1.8.2'\n}\n`,
      'app/src/main/res/values/strings.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">${config.app_name.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</string>\n</resources>\n`,
      'app/src/main/res/values/colors.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="status_bar_color">${config.status_bar_color}</color>\n    <color name="nav_bar_color">${config.nav_bar_color}</color>\n    <color name="theme_color">${config.theme_color || '#6C5CE7'}</color>\n    <color name="background_color">${config.background_color || '#1F1C2C'}</color>\n    <color name="splash_color">${config.splash_color || '#1F1C2C'}</color>\n</resources>\n`,
      'app/src/main/res/values/styles.xml': `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <style name="Theme.APKStudioApp" parent="Theme.MaterialComponents.DayNight.NoActionBar">\n        <item name="colorPrimary">@color/theme_color</item>\n        <item name="android:windowBackground">@color/background_color</item>\n        <item name="android:statusBarColor">@color/status_bar_color</item>\n        <item name="android:windowLightStatusBar">${config.light_status_bar ? 'true' : 'false'}</item>\n        <item name="android:navigationBarColor">@color/nav_bar_color</item>\n    </style>\n</resources>\n`,
      'app/src/main/AndroidManifest.xml': `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n${(config.permissions || ['android.permission.INTERNET']).map((p) => `    <uses-permission android:name="${p}" />`).join('\n')}\n    <application\n        android:allowBackup="true"\n        android:hardwareAccelerated="true"\n        android:label="@string/app_name"\n        android:supportsRtl="true"\n        android:theme="@style/Theme.APKStudioApp"\n        android:usesCleartextTraffic="${config.allow_cleartext !== false ? 'true' : 'false'}">\n        <activity\n            android:name="com.apkstudio.app.MainActivity"\n            android:exported="true"\n            android:configChanges="orientation|screenSize|keyboardHidden|uiMode"\n            android:screenOrientation="${config.orientation || 'portrait'}"\n            android:theme="@style/Theme.APKStudioApp">\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>\n`,
      '.github/workflows/build-apk.yml': `name: Build Android APK\non:\n  workflow_dispatch:\n  push:\n    branches: [ main, master ]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-java@v4\n        with:\n          distribution: 'temurin'\n          java-version: '17'\n      - uses: android-actions/setup-android@v3\n      - uses: gradle/actions/setup-gradle@v3\n        with:\n          gradle-version: '8.5'\n      - run: gradle assembleDebug --no-daemon\n      - uses: actions/upload-artifact@v4\n        with:\n          name: Android-APK\n          path: app/build/outputs/apk/**/*.apk\n`
    };

    for (const [k, v] of Object.entries(updatedFiles)) {
      preparedFiles[`app/src/main/assets/webapp/${k}`] = v;
    }
    if (anim && anim.inject_stylesheet !== false) {
      preparedFiles['app/src/main/assets/webapp/apk_studio_animations.css'] =
        generateAnimationStylesheet(anim);
    }

    ws.preparedAndroidProjects[buildId] = preparedFiles;
    ws.builds[buildId] = {
      id: buildId,
      project_id: projectId,
      build_type: buildType,
      status: 'failed',
      stage: 'checking_toolchain',
      progress: 65,
      started_at: now,
      completed_at: new Date().toISOString(),
      log,
      error_summary:
        'Prepared Android Gradle project is ready for export. Native Gradle compilation requires a connected Build Server or exporting the Android Gradle ZIP.'
    };
    project.last_build_status = 'failed';
    saveWorkspace(ws);
    return { buildId, status: 'failed', buildType };
  },

  getBuildStatus(buildId: string): BuildRecord {
    const ws = loadWorkspace();
    const rec = ws.builds[buildId];
    if (!rec) throw new Error('Build ID not found');
    return rec;
  },

  listBuilds(projectId: string): BuildRecord[] {
    const ws = loadWorkspace();
    return Object.values(ws.builds)
      .filter((b) => b.project_id === projectId)
      .sort((a, b) => b.started_at.localeCompare(a.started_at));
  },

  exportPreparedProjectZip(buildId: string): void {
    const ws = loadWorkspace();
    const filesMap = ws.preparedAndroidProjects[buildId];
    if (!filesMap) {
      throw new Error('Prepared Android project files not found for this build.');
    }
    const zipBytes = buildZipUint8Array(filesMap);
    const filename = `android-project-${buildId.substring(0, 8)}.zip`;

    const win = window as any;
    if (win.AndroidStudioBridge && typeof win.AndroidStudioBridge.saveBase64File === 'function') {
      let binary = '';
      for (let i = 0; i < zipBytes.length; i++) {
        binary += String.fromCharCode(zipBytes[i]);
      }
      win.AndroidStudioBridge.saveBase64File(btoa(binary), filename, 'application/zip');
      return;
    }

    const blob = new Blob([zipBytes], { type: 'application/zip' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
};
