import {
  Project,
  CustomizationSettings,
  AnimationConfig,
  FileTreeNode,
  BuildRecord,
  PythonInspectionResult,
  ToolchainDiagnostics
} from '../types';
import { LocalEngine } from './localEngine';

function getApiBaseUrl(): string {
  const custom = LocalEngine.getRemoteBackendUrl();
  if (custom) {
    return custom.endsWith('/api') ? custom : `${custom}/api`;
  }
  return '/api';
}

function isFileProtocolWithoutRemote(): boolean {
  if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
    return !LocalEngine.getRemoteBackendUrl();
  }
  return false;
}

async function fetchBackendOrFallback<T>(
  pathSuffix: string,
  options: RequestInit | undefined,
  fallbackFn: () => T | Promise<T>
): Promise<T> {
  if (isFileProtocolWithoutRemote()) {
    return await fallbackFn();
  }
  try {
    const res = await fetch(`${getApiBaseUrl()}${pathSuffix}`, options);
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return await fallbackFn();
    }
    const data = await res.json();
    if (!res.ok) {
      throw new Error((data as any).error || `Request failed with status ${res.status}`);
    }
    return data as T;
  } catch (err: any) {
    // If network/fetch fails because backend server isn't running locally, use LocalEngine
    if (
      err instanceof TypeError ||
      (err?.message && (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')))
    ) {
      return await fallbackFn();
    }
    throw err;
  }
}

export const API = {
  getRemoteBackendUrl: () => LocalEngine.getRemoteBackendUrl(),
  setRemoteBackendUrl: (url: string) => LocalEngine.setRemoteBackendUrl(url),
  isStandaloneWebViewMode: () => isFileProtocolWithoutRemote(),

  async getSystemDiagnostics(): Promise<{
    status: string;
    toolchain: ToolchainDiagnostics;
    supportedPermissions: string[];
  }> {
    return fetchBackendOrFallback('/system/diagnostics', undefined, () =>
      LocalEngine.getSystemDiagnostics()
    );
  },

  async listProjects(): Promise<Project[]> {
    return fetchBackendOrFallback('/projects', undefined, () => LocalEngine.listProjects());
  },

  async createProject(name: string, type: 'html' | 'python'): Promise<Project> {
    return fetchBackendOrFallback(
      '/projects',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type })
      },
      () => LocalEngine.createProject(name, type)
    );
  },

  async getProject(id: string): Promise<{
    project: Project;
    customization: CustomizationSettings;
    animations: AnimationConfig;
  }> {
    return fetchBackendOrFallback(`/projects/${id}`, undefined, () => LocalEngine.getProject(id));
  },

  async renameProject(id: string, name: string): Promise<Project> {
    return fetchBackendOrFallback(
      `/projects/${id}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      },
      () => LocalEngine.renameProject(id, name)
    );
  },

  async duplicateProject(id: string, name?: string): Promise<Project> {
    return fetchBackendOrFallback(
      `/projects/${id}/duplicate`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      },
      () => LocalEngine.duplicateProject(id, name)
    );
  },

  async updateCustomization(
    id: string,
    settings: CustomizationSettings
  ): Promise<{ success: boolean; customization: CustomizationSettings }> {
    return fetchBackendOrFallback(
      `/projects/${id}/customization`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      },
      () => LocalEngine.updateCustomization(id, settings)
    );
  },

  async updateAnimations(
    id: string,
    animations: AnimationConfig
  ): Promise<{ success: boolean; animations: AnimationConfig }> {
    return fetchBackendOrFallback(
      `/projects/${id}/animations`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(animations)
      },
      () => LocalEngine.updateAnimations(id, animations)
    );
  },

  async deleteProject(id: string): Promise<void> {
    await fetchBackendOrFallback(
      `/projects/${id}`,
      { method: 'DELETE' },
      () => {
        LocalEngine.deleteProject(id);
      }
    );
  },

  async getFileTree(projectId: string): Promise<FileTreeNode[]> {
    return fetchBackendOrFallback(`/projects/${projectId}/files`, undefined, () =>
      LocalEngine.getFileTree(projectId)
    );
  },

  async getFile(
    projectId: string,
    filePath: string
  ): Promise<{ content: string; isBinary: boolean; path: string }> {
    return fetchBackendOrFallback(
      `/projects/${projectId}/file?path=${encodeURIComponent(filePath)}`,
      undefined,
      () => LocalEngine.getFile(projectId, filePath)
    );
  },

  async saveFile(projectId: string, filePath: string, content: string): Promise<void> {
    await fetchBackendOrFallback(
      `/projects/${projectId}/file`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: filePath, content })
      },
      () => {
        LocalEngine.saveFile(projectId, filePath, content);
      }
    );
  },

  async deleteFile(projectId: string, filePath: string): Promise<void> {
    await fetchBackendOrFallback(
      `/projects/${projectId}/file?path=${encodeURIComponent(filePath)}`,
      { method: 'DELETE' },
      () => {
        LocalEngine.deleteFile(projectId, filePath);
      }
    );
  },

  async importSingleFile(
    projectId: string,
    file: File,
    targetPath?: string
  ): Promise<{ success: boolean; importedFile: string }> {
    const formData = new FormData();
    formData.append('file', file);
    if (targetPath) formData.append('targetPath', targetPath);
    return fetchBackendOrFallback(
      `/projects/${projectId}/import-file`,
      {
        method: 'POST',
        body: formData
      },
      () => LocalEngine.importSingleFile(projectId, file, targetPath)
    );
  },

  async uploadZip(
    projectId: string,
    file: File
  ): Promise<{
    success: boolean;
    filesExtracted: string[];
    skippedUnsupportedFiles: string[];
    flattenedRoot: boolean;
    hasIndexHtml: boolean;
    warnings: string[];
  }> {
    const formData = new FormData();
    formData.append('zipfile', file);
    return fetchBackendOrFallback(
      `/projects/${projectId}/upload-zip`,
      {
        method: 'POST',
        body: formData
      },
      () => LocalEngine.uploadZip(projectId, file)
    );
  },

  async inspectPython(projectId: string): Promise<PythonInspectionResult> {
    return fetchBackendOrFallback(`/projects/${projectId}/python-inspect`, undefined, () =>
      LocalEngine.inspectPython(projectId)
    );
  },

  async generatePythonBridge(
    projectId: string,
    entrypoint?: string
  ): Promise<{ success: boolean; generatedFile: string; inspection: PythonInspectionResult }> {
    return fetchBackendOrFallback(
      `/projects/${projectId}/python-bridge`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entrypoint })
      },
      () => LocalEngine.generatePythonBridge(projectId, entrypoint)
    );
  },

  async triggerBuild(
    projectId: string,
    buildType: 'debug' | 'release' = 'debug'
  ): Promise<{ buildId: string; status: string; buildType: string }> {
    return fetchBackendOrFallback(
      `/projects/${projectId}/builds`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ buildType })
      },
      () => LocalEngine.triggerBuild(projectId, buildType)
    );
  },

  async getBuildStatus(buildId: string): Promise<BuildRecord> {
    return fetchBackendOrFallback(`/builds/${buildId}`, undefined, () =>
      LocalEngine.getBuildStatus(buildId)
    );
  },

  async listBuilds(projectId: string): Promise<BuildRecord[]> {
    return fetchBackendOrFallback(`/projects/${projectId}/builds`, undefined, () =>
      LocalEngine.listBuilds(projectId)
    );
  },

  compileLivePreviewSrcDoc(projectId: string): string {
    return LocalEngine.compileLivePreviewSrcDoc(projectId);
  },

  async exportAndroidGradleProject(buildId: string): Promise<void> {
    if (isFileProtocolWithoutRemote()) {
      LocalEngine.exportPreparedProjectZip(buildId);
      return;
    }
    try {
      const res = await fetch(`${getApiBaseUrl()}/builds/${buildId}/export-project`);
      if (!res.ok) {
        LocalEngine.exportPreparedProjectZip(buildId);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `android-project-${buildId.substring(0, 8)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch {
      LocalEngine.exportPreparedProjectZip(buildId);
    }
  }
};
