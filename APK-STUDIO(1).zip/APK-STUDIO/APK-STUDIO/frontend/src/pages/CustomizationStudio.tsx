import React, { useState } from 'react';
import { CustomizationSettings } from '../types';
import { API } from '../services/api';
import { GlassButton } from '../components/GlassButton';
import { validateCustomizationClient } from '../utils/validation';
import { Upload, CheckCircle2, AlertTriangle } from 'lucide-react';

interface Props {
  projectId: string;
  initialSettings: CustomizationSettings;
  onUpdated: (updated: CustomizationSettings) => void;
}

const PERMISSION_OPTIONS = [
  { id: 'android.permission.INTERNET', label: 'Internet Access (HTTP/HTTPS)' },
  { id: 'android.permission.ACCESS_NETWORK_STATE', label: 'Network Connectivity State' },
  { id: 'android.permission.CAMERA', label: 'Camera / WebRTC Video' },
  { id: 'android.permission.RECORD_AUDIO', label: 'Microphone / Audio Capture' },
  { id: 'android.permission.ACCESS_FINE_LOCATION', label: 'Precise GPS Location' },
  { id: 'android.permission.ACCESS_COARSE_LOCATION', label: 'Approximate Location' },
  { id: 'android.permission.VIBRATE', label: 'Haptic Vibration Feedback' },
  { id: 'android.permission.POST_NOTIFICATIONS', label: 'Push / Local Notifications' },
  { id: 'android.permission.WAKE_LOCK', label: 'Background Wake Lock' }
];

export const CustomizationStudio: React.FC<Props> = ({
  projectId,
  initialSettings,
  onUpdated
}) => {
  const [settings, setSettings] = useState<CustomizationSettings>(initialSettings);
  const [status, setStatus] = useState<{ message: string; isError?: boolean } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSettings((prev) => ({ ...prev, icon_data_url: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const togglePermission = (permId: string) => {
    setSettings((prev) => {
      const current = new Set(prev.permissions || []);
      if (current.has(permId)) {
        current.delete(permId);
      } else {
        current.add(permId);
      }
      return { ...prev, permissions: Array.from(current) };
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const clientErrors = validateCustomizationClient(settings);
    if (clientErrors.length > 0) {
      setStatus({ message: clientErrors.join(' '), isError: true });
      return;
    }

    setIsSaving(true);
    setStatus(null);
    try {
      const res = await API.updateCustomization(projectId, settings);
      onUpdated(res.customization);
      setStatus({
        message: 'Customization validated and synchronized with Android Gradle & Manifest config.'
      });
    } catch (err: any) {
      setStatus({ message: err.message, isError: true });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="glass-panel" style={{ width: '100%', maxWidth: 860, padding: 32 }}>
      <h2 style={{ fontSize: 24, marginBottom: 6 }}>App Customization Studio</h2>
      <p style={{ color: 'rgba(255,255,255,0.72)', fontSize: 14, marginBottom: 24 }}>
        Configure Android package identity, icons, splash screen, system bars, offline behavior, and
        manifest permissions.
      </p>

      <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Application Identity */}
        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Application Name
            </label>
            <input
              className="glass-input"
              value={settings.app_name}
              onChange={(e) => setSettings({ ...settings, app_name: e.target.value })}
            />
          </div>
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Android Package ID
            </label>
            <input
              className="glass-input"
              placeholder="com.company.appname"
              value={settings.package_id}
              onChange={(e) => setSettings({ ...settings, package_id: e.target.value })}
            />
          </div>
        </div>

        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Version Name
            </label>
            <input
              className="glass-input"
              value={settings.version_name}
              onChange={(e) => setSettings({ ...settings, version_name: e.target.value })}
            />
          </div>
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Version Code (Integer)
            </label>
            <input
              type="number"
              min={1}
              className="glass-input"
              value={settings.version_code}
              onChange={(e) =>
                setSettings({ ...settings, version_code: parseInt(e.target.value, 10) || 1 })
              }
            />
          </div>
        </div>

        {/* App Icon & Orientation */}
        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Launcher App Icon (PNG)
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div
                className="app-icon"
                style={{ width: 52, height: 52, margin: 0, borderRadius: 14, overflow: 'hidden' }}
              >
                {settings.icon_data_url ? (
                  <img
                    src={settings.icon_data_url}
                    alt="App Icon"
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  <svg viewBox="0 0 24 24" style={{ width: 24, height: 24, fill: 'none' }}>
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                  </svg>
                )}
              </div>
              <label className="liquid-glass-btn" style={{ width: 'auto', padding: '8px 14px', fontSize: 12 }}>
                <Upload size={14} /> Upload Icon
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleIconUpload}
                  style={{ display: 'none' }}
                />
              </label>
            </div>
          </div>

          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Screen Orientation &amp; Offline Strategy
            </label>
            <div style={{ display: 'flex', gap: 10 }}>
              <select
                className="glass-input"
                value={settings.orientation}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    orientation: e.target.value as CustomizationSettings['orientation']
                  })
                }
              >
                <option value="portrait" style={{ background: '#1f1c2c' }}>
                  Portrait
                </option>
                <option value="landscape" style={{ background: '#1f1c2c' }}>
                  Landscape
                </option>
                <option value="unspecified" style={{ background: '#1f1c2c' }}>
                  Auto-Sensor
                </option>
              </select>

              <select
                className="glass-input"
                value={settings.offline_mode || 'cache_first'}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    offline_mode: e.target.value as CustomizationSettings['offline_mode']
                  })
                }
              >
                <option value="cache_first" style={{ background: '#1f1c2c' }}>
                  Cache Fallback
                </option>
                <option value="network_first" style={{ background: '#1f1c2c' }}>
                  Network Default
                </option>
                <option value="offline_only" style={{ background: '#1f1c2c' }}>
                  Offline Bundle Only
                </option>
              </select>
            </div>
          </div>
        </div>

        {/* Theme, Background, Status Bar & Navigation Bar Colors */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
            gap: 14
          }}
        >
          <div>
            <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 }}>
              Status Bar Color
            </label>
            <input
              type="color"
              className="glass-input"
              value={settings.status_bar_color || '#1f1c2c'}
              onChange={(e) => setSettings({ ...settings, status_bar_color: e.target.value })}
              style={{ height: 42, padding: 4 }}
            />
          </div>
          <div>
            <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 }}>
              Navigation Bar Color
            </label>
            <input
              type="color"
              className="glass-input"
              value={settings.nav_bar_color || '#1f1c2c'}
              onChange={(e) => setSettings({ ...settings, nav_bar_color: e.target.value })}
              style={{ height: 42, padding: 4 }}
            />
          </div>
          <div>
            <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 }}>
              Theme Accent Color
            </label>
            <input
              type="color"
              className="glass-input"
              value={settings.theme_color || '#6c5ce7'}
              onChange={(e) => setSettings({ ...settings, theme_color: e.target.value })}
              style={{ height: 42, padding: 4 }}
            />
          </div>
          <div>
            <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 4 }}>
              Splash Background
            </label>
            <input
              type="color"
              className="glass-input"
              value={settings.splash_color || '#1f1c2c'}
              onChange={(e) => setSettings({ ...settings, splash_color: e.target.value })}
              style={{ height: 42, padding: 4 }}
            />
          </div>
        </div>

        {/* Splash Screen Controls */}
        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Splash Screen Duration (ms)
            </label>
            <input
              type="number"
              min={0}
              max={10000}
              step={100}
              className="glass-input"
              value={settings.splash_duration_ms ?? 1500}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  splash_duration_ms: parseInt(e.target.value, 10) || 0
                })
              }
            />
          </div>
          <div>
            <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
              Splash Exit Animation
            </label>
            <select
              className="glass-input"
              value={settings.splash_animation || 'fade'}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  splash_animation: e.target.value as CustomizationSettings['splash_animation']
                })
              }
            >
              <option value="fade" style={{ background: '#1f1c2c' }}>
                Smooth Fade Out
              </option>
              <option value="scale" style={{ background: '#1f1c2c' }}>
                Zoom Scale Transition
              </option>
              <option value="slide" style={{ background: '#1f1c2c' }}>
                Slide Up Dismissal
              </option>
              <option value="pulse" style={{ background: '#1f1c2c' }}>
                Liquid Pulse &amp; Fade
              </option>
              <option value="none" style={{ background: '#1f1c2c' }}>
                Instant (No Animation)
              </option>
            </select>
          </div>
        </div>

        {/* Toggles */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
            gap: 12,
            padding: 16,
            borderRadius: 14,
            background: 'rgba(0,0,0,0.22)',
            border: '1px solid rgba(255,255,255,0.1)'
          }}
        >
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={Boolean(settings.fullscreen)}
              onChange={(e) => setSettings({ ...settings, fullscreen: e.target.checked })}
            />
            Fullscreen Immersive Mode
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={settings.splash_enabled !== false}
              onChange={(e) => setSettings({ ...settings, splash_enabled: e.target.checked })}
            />
            Show Native Launch Splash Screen
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={Boolean(settings.light_status_bar)}
              onChange={(e) => setSettings({ ...settings, light_status_bar: e.target.checked })}
            />
            Dark Status Bar Icons (Light Theme)
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={Boolean(settings.keep_screen_on)}
              onChange={(e) => setSettings({ ...settings, keep_screen_on: e.target.checked })}
            />
            Keep Screen Awake While Active
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={Boolean(settings.enable_zoom)}
              onChange={(e) => setSettings({ ...settings, enable_zoom: e.target.checked })}
            />
            Enable WebView Pinch-to-Zoom
          </label>

          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={settings.allow_cleartext !== false}
              onChange={(e) => setSettings({ ...settings, allow_cleartext: e.target.checked })}
            />
            Allow Cleartext HTTP Traffic
          </label>
        </div>

        {/* Supported Android Permissions */}
        <div>
          <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 8 }}>
            Android Manifest Permissions
          </label>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
              gap: 10,
              padding: 14,
              borderRadius: 14,
              background: 'rgba(0,0,0,0.22)',
              border: '1px solid rgba(255,255,255,0.1)'
            }}
          >
            {PERMISSION_OPTIONS.map((perm) => (
              <label
                key={perm.id}
                style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, cursor: 'pointer' }}
              >
                <input
                  type="checkbox"
                  checked={(settings.permissions || []).includes(perm.id)}
                  onChange={() => togglePermission(perm.id)}
                />
                <span>{perm.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 6 }}>
          <GlassButton type="submit" disabled={isSaving}>
            {isSaving ? 'Validating & Saving...' : 'Save Android Customization'}
          </GlassButton>
        </div>

        {status && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              fontSize: 13,
              color: status.isError ? '#ff6b6b' : '#00ffc8',
              textAlign: 'center'
            }}
          >
            {status.isError ? <AlertTriangle size={16} /> : <CheckCircle2 size={16} />}
            <span>{status.message}</span>
          </div>
        )}
      </form>
    </div>
  );
};
