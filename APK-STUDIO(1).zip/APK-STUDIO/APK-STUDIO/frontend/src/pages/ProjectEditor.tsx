import React, { useEffect, useState } from 'react';
import { Project, FileTreeNode, PythonInspectionResult } from '../types';
import { API } from '../services/api';
import { GlassButton } from '../components/GlassButton';
import { GlassModal } from '../components/GlassModal';
import { FileTreeView } from '../features/editor/FileTreeView';
import { LivePreviewPane } from '../features/editor/LivePreviewPane';
import { PythonInspectorPanel } from '../features/python/PythonInspectorPanel';
import { useUnsavedChanges } from '../hooks/useUnsavedChanges';
import { detectLanguageFromPath, getSyntaxAccentColor } from '../utils/syntaxHighlight';
import { Save, UploadCloud, FilePlus, FileUp } from 'lucide-react';

interface Props {
  project: Project;
}

export const ProjectEditor: React.FC<Props> = ({ project }) => {
  const [fileTree, setFileTree] = useState<FileTreeNode[]>([]);
  const [activeFile, setActiveFile] = useState<string>('index.html');
  const [fileContent, setFileContent] = useState<string>('');
  const [savedContent, setSavedContent] = useState<string>('');
  const [isBinaryFile, setIsBinaryFile] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState(false);
  const [previewKey, setPreviewKey] = useState(Date.now());
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError?: boolean } | null>(
    null
  );

  const [isNewFileModalOpen, setIsNewFileModalOpen] = useState(false);
  const [newFilePath, setNewFilePath] = useState('');

  const [pythonInspection, setPythonInspection] = useState<PythonInspectionResult | null>(null);
  const [isGeneratingBridge, setIsGeneratingBridge] = useState(false);

  const isDirty = !isBinaryFile && fileContent !== savedContent;
  useUnsavedChanges(isDirty);

  const loadTree = async () => {
    const tree = await API.getFileTree(project.id);
    setFileTree(tree);
  };

  const loadPythonDiagnostics = async () => {
    if (project.type === 'python') {
      const res = await API.inspectPython(project.id);
      setPythonInspection(res);
    } else {
      setPythonInspection(null);
    }
  };

  const loadContent = async (targetPath: string, force = false) => {
    if (!force && isDirty) {
      const proceed = window.confirm(
        `You have unsaved changes in ${activeFile}. Discard changes and open ${targetPath}?`
      );
      if (!proceed) return;
    }
    try {
      const res = await API.getFile(project.id, targetPath);
      setActiveFile(targetPath);
      setFileContent(res.content);
      setSavedContent(res.content);
      setIsBinaryFile(Boolean(res.isBinary));
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to read file', isError: true });
    }
  };

  useEffect(() => {
    loadTree();
    loadPythonDiagnostics();
    const defaultEntry = project.type === 'python' ? 'main.py' : 'index.html';
    loadContent(defaultEntry, true);
  }, [project.id]);

  const handleSave = async () => {
    if (isBinaryFile) return;
    setIsSaving(true);
    setStatusMessage(null);
    try {
      await API.saveFile(project.id, activeFile, fileContent);
      setSavedContent(fileContent);
      setPreviewKey(Date.now());
      await loadPythonDiagnostics();
      setStatusMessage({ text: `Saved ${activeFile}` });
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSingleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    setStatusMessage(null);
    try {
      const res = await API.importSingleFile(project.id, file, file.name);
      await loadTree();
      await loadPythonDiagnostics();
      await loadContent(res.importedFile, true);
      setPreviewKey(Date.now());
      setStatusMessage({ text: `Imported ${res.importedFile}` });
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      e.target.value = '';
    }
  };

  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    setStatusMessage(null);
    try {
      const res = await API.uploadZip(project.id, file);
      await loadTree();
      await loadPythonDiagnostics();
      if (res.hasIndexHtml) {
        await loadContent('index.html', true);
      } else if (res.filesExtracted.length > 0) {
        await loadContent(res.filesExtracted[0], true);
      }
      setPreviewKey(Date.now());
      const warnNote =
        res.skippedUnsupportedFiles.length > 0
          ? ` (Skipped ${res.skippedUnsupportedFiles.length} unsupported binary file(s))`
          : '';
      setStatusMessage({
        text: `Extracted ${res.filesExtracted.length} file(s) from archive.${warnNote}`
      });
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      e.target.value = '';
    }
  };

  const handleCreateNewFile = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newFilePath.trim().replace(/^[/\\]+/, '');
    if (!cleaned) return;
    try {
      await API.saveFile(project.id, cleaned, '');
      setIsNewFileModalOpen(false);
      setNewFilePath('');
      await loadTree();
      await loadContent(cleaned, true);
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    }
  };

  const handleDeleteFile = async (targetPath: string) => {
    try {
      await API.deleteFile(project.id, targetPath);
      await loadTree();
      await loadPythonDiagnostics();
      if (activeFile === targetPath) {
        await loadContent('index.html', true);
      }
      setPreviewKey(Date.now());
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    }
  };

  const handleGeneratePythonBridge = async () => {
    setIsGeneratingBridge(true);
    try {
      const res = await API.generatePythonBridge(
        project.id,
        pythonInspection?.entrypoint || 'main.py'
      );
      setPythonInspection(res.inspection);
      await loadTree();
      setPreviewKey(Date.now());
      setStatusMessage({ text: 'Generated index.html WebView bridge for Python script.' });
    } catch (err: any) {
      setStatusMessage({ text: err.message, isError: true });
    } finally {
      setIsGeneratingBridge(false);
    }
  };

  const currentLang = detectLanguageFromPath(activeFile);
  const syntaxColor = getSyntaxAccentColor(currentLang);
  const lineCount = fileContent.split('\n').length;

  return (
    <div className="editor-layout">
      {/* Left Column: Explorer & Import Actions */}
      <div
        className="glass-panel"
        style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 10 }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: 15, fontWeight: 600 }}>Project Files</h3>
          <button
            type="button"
            title="New File"
            onClick={() => setIsNewFileModalOpen(true)}
            style={{
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.18)',
              borderRadius: 8,
              color: '#fff',
              padding: '5px 8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 4,
              fontSize: 11
            }}
          >
            <FilePlus size={13} /> New
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <label className="liquid-glass-btn" style={{ fontSize: 12, padding: '8px 12px', minHeight: 36 }}>
            <FileUp size={15} /> Import HTML / Asset File
            <input
              type="file"
              accept=".html,.htm,.css,.js,.json,.py,.txt,.svg,.png,.jpg,.jpeg,.webp"
              onChange={handleSingleFileUpload}
              style={{ display: 'none' }}
            />
          </label>

          <label className="liquid-glass-btn" style={{ fontSize: 12, padding: '8px 12px', minHeight: 36 }}>
            <UploadCloud size={15} /> Import Website ZIP
            <input
              type="file"
              accept=".zip"
              onChange={handleZipUpload}
              style={{ display: 'none' }}
            />
          </label>
        </div>

        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            marginTop: 6,
            paddingRight: 4,
            maxHeight: 540
          }}
        >
          <FileTreeView
            nodes={fileTree}
            activeFile={activeFile}
            onSelectFile={(p) => loadContent(p)}
            onDeleteFile={handleDeleteFile}
          />
        </div>
      </div>

      {/* Center Column: Multi-file Code Editor & Python Diagnostics */}
      <div
        className="glass-panel"
        style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: 18 }}
      >
        {project.type === 'python' && (
          <PythonInspectorPanel
            inspection={pythonInspection}
            onGenerateBridge={handleGeneratePythonBridge}
            isGeneratingBridge={isGeneratingBridge}
          />
        )}

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 10,
            marginBottom: 12
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>{activeFile}</span>
            <span
              style={{
                fontSize: 11,
                padding: '2px 8px',
                borderRadius: 6,
                background: 'rgba(255,255,255,0.1)',
                color: syntaxColor
              }}
            >
              {currentLang} • {lineCount} lines
            </span>
            {isDirty && (
              <span
                style={{
                  fontSize: 11,
                  padding: '2px 8px',
                  borderRadius: 6,
                  background: 'rgba(254, 202, 87, 0.2)',
                  color: '#feca57',
                  fontWeight: 600
                }}
              >
                Unsaved edits
              </span>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {statusMessage && (
              <span
                style={{
                  fontSize: 12,
                  color: statusMessage.isError ? '#ff6b6b' : '#00ffc8'
                }}
              >
                {statusMessage.text}
              </span>
            )}
            <div style={{ width: 130 }}>
              <GlassButton onClick={handleSave} disabled={isSaving || isBinaryFile}>
                <Save size={15} /> {isSaving ? 'Saving...' : 'Save File'}
              </GlassButton>
            </div>
          </div>
        </div>

        <textarea
          value={fileContent}
          disabled={isBinaryFile}
          onChange={(e) => setFileContent(e.target.value)}
          spellCheck={false}
          style={{
            flex: 1,
            minHeight: 420,
            width: '100%',
            background: 'rgba(0, 0, 0, 0.36)',
            color: syntaxColor,
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            fontSize: 13.5,
            lineHeight: 1.55,
            padding: 16,
            borderRadius: 14,
            border: '1px solid rgba(255,255,255,0.12)',
            outline: 'none',
            resize: 'none'
          }}
        />
      </div>

      {/* Right Column: Live Preview & Console */}
      <LivePreviewPane
        projectId={project.id}
        previewKey={previewKey}
        onRefresh={() => setPreviewKey(Date.now())}
      />

      {/* New File Modal */}
      <GlassModal
        isOpen={isNewFileModalOpen}
        title="Create New File"
        onClose={() => setIsNewFileModalOpen(false)}
      >
        <form onSubmit={handleCreateNewFile}>
          <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 }}>
            Relative File Path (e.g. <code>pages/about.html</code> or <code>js/utils.js</code>)
          </label>
          <input
            className="glass-input"
            placeholder="styles/custom.css"
            value={newFilePath}
            onChange={(e) => setNewFilePath(e.target.value)}
            autoFocus
            style={{ marginBottom: 18 }}
          />
          <div style={{ display: 'flex', gap: 12 }}>
            <GlassButton type="submit">Create File</GlassButton>
            <button
              type="button"
              onClick={() => setIsNewFileModalOpen(false)}
              style={{
                flex: 1,
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.15)',
                borderRadius: 14,
                color: 'rgba(255,255,255,0.75)',
                cursor: 'pointer'
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      </GlassModal>
    </div>
  );
};
