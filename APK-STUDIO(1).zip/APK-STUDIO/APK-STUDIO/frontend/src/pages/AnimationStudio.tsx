import React, { useState } from 'react';
import { AnimationConfig } from '../types';
import { API } from '../services/api';
import { GlassButton } from '../components/GlassButton';
import { Sparkles, CheckCircle2 } from 'lucide-react';

interface Props {
  projectId: string;
  initialAnimations: AnimationConfig;
  onUpdated: (updated: AnimationConfig) => void;
}

const ANIMATION_PRESETS: Array<{ name: string; config: Omit<AnimationConfig, 'project_id'> }> = [
  {
    name: 'Liquid Glass Default',
    config: {
      splash_animation: 'fade',
      splash_duration_ms: 1500,
      pulse_duration_s: 2.0,
      glass_blur_px: 30,
      page_transition: 'fade',
      loader_style: 'spinner',
      button_effect: 'scale-press',
      inject_stylesheet: true
    }
  },
  {
    name: 'Dynamic Scale & Glow',
    config: {
      splash_animation: 'scale',
      splash_duration_ms: 1800,
      pulse_duration_s: 1.4,
      glass_blur_px: 40,
      page_transition: 'zoom',
      loader_style: 'pulse-ring',
      button_effect: 'glow-hover',
      inject_stylesheet: true
    }
  },
  {
    name: 'Snappy Minimal',
    config: {
      splash_animation: 'slide',
      splash_duration_ms: 900,
      pulse_duration_s: 3.5,
      glass_blur_px: 18,
      page_transition: 'slide-up',
      loader_style: 'progress-bar',
      button_effect: 'scale-press',
      inject_stylesheet: true
    }
  }
];

export const AnimationStudio: React.FC<Props> = ({
  projectId,
  initialAnimations,
  onUpdated
}) => {
  const [config, setConfig] = useState<AnimationConfig>(initialAnimations);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const res = await API.updateAnimations(projectId, config);
      onUpdated(res.animations);
      setStatusMessage(
        'Animation preset saved to database, linked to MainActivity splash config, and written to apk_studio_animations.css.'
      );
    } catch (err: any) {
      setStatusMessage(`Error: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="glass-panel" style={{ width: '100%', maxWidth: 820, padding: 32 }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 12,
          marginBottom: 20
        }}
      >
        <div>
          <h2 style={{ fontSize: 24, marginBottom: 4 }}>Animation Studio</h2>
          <p style={{ color: 'rgba(255,255,255,0.72)', fontSize: 14 }}>
            Configure native splash transitions, button micro-interactions, loaders, and frosted
            glass effects injected into your packaged APK.
          </p>
        </div>

        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {ANIMATION_PRESETS.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => setConfig({ ...preset.config })}
              style={{
                padding: '6px 12px',
                borderRadius: 10,
                border: '1px solid rgba(255,255,255,0.2)',
                background: 'rgba(255,255,255,0.1)',
                color: '#fff',
                fontSize: 12,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 5
              }}
            >
              <Sparkles size={12} color="#00ffc8" />
              {preset.name}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Live Preview Stage */}
      <div
        style={{
          height: 210,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 14,
          background: 'rgba(0, 0, 0, 0.28)',
          borderRadius: 20,
          marginBottom: 24,
          border: '1px solid rgba(255, 255, 255, 0.12)',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <div
          className="app-icon"
          style={{
            margin: 0,
            animation: `studioPulse ${config.pulse_duration_s}s ease-in-out infinite`,
            backdropFilter: `blur(${config.glass_blur_px}px)`,
            WebkitBackdropFilter: `blur(${config.glass_blur_px}px)`
          }}
        >
          <svg viewBox="0 0 24 24" style={{ fill: 'none' }}>
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
        </div>

        {/* Loader preview */}
        {config.loader_style !== 'none' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#00ffc8' }}>
            <div
              style={{
                width: 16,
                height: 16,
                borderRadius: '50%',
                border: '2px solid rgba(0,255,200,0.3)',
                borderTopColor: '#00ffc8',
                animation: 'studioSpin 1s linear infinite'
              }}
            />
            <span>
              Splash: {config.splash_animation.toUpperCase()} ({config.splash_duration_ms}ms) •
              Loader: {config.loader_style}
            </span>
          </div>
        )}

        <button
          type="button"
          style={{
            padding: '8px 18px',
            borderRadius: 10,
            border: '1px solid rgba(255,255,255,0.28)',
            background: 'rgba(255,255,255,0.14)',
            color: '#fff',
            fontSize: 12,
            fontWeight: 600,
            cursor: 'pointer',
            boxShadow:
              config.button_effect === 'glow-hover'
                ? '0 0 16px rgba(0, 255, 200, 0.45)'
                : 'none'
          }}
        >
          Interactive Button ({config.button_effect})
        </button>
      </div>

      {/* Controls Grid */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Splash Screen Transition
            </label>
            <select
              className="glass-input"
              value={config.splash_animation}
              onChange={(e) =>
                setConfig({
                  ...config,
                  splash_animation: e.target.value as AnimationConfig['splash_animation']
                })
              }
            >
              <option value="fade" style={{ background: '#1f1c2c' }}>
                Fade Out
              </option>
              <option value="scale" style={{ background: '#1f1c2c' }}>
                Scale Zoom
              </option>
              <option value="slide" style={{ background: '#1f1c2c' }}>
                Slide Up
              </option>
              <option value="pulse" style={{ background: '#1f1c2c' }}>
                Pulse &amp; Dissolve
              </option>
              <option value="none" style={{ background: '#1f1c2c' }}>
                None
              </option>
            </select>
          </div>

          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Splash Duration (ms)
            </label>
            <input
              type="number"
              min={0}
              max={10000}
              step={100}
              className="glass-input"
              value={config.splash_duration_ms}
              onChange={(e) =>
                setConfig({
                  ...config,
                  splash_duration_ms: parseInt(e.target.value, 10) || 0
                })
              }
            />
          </div>
        </div>

        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Page Enter Transition
            </label>
            <select
              className="glass-input"
              value={config.page_transition}
              onChange={(e) =>
                setConfig({
                  ...config,
                  page_transition: e.target.value as AnimationConfig['page_transition']
                })
              }
            >
              <option value="fade" style={{ background: '#1f1c2c' }}>
                Smooth Opacity Fade
              </option>
              <option value="slide-up" style={{ background: '#1f1c2c' }}>
                Slide Up Entrance
              </option>
              <option value="zoom" style={{ background: '#1f1c2c' }}>
                Scale Zoom Entrance
              </option>
              <option value="none" style={{ background: '#1f1c2c' }}>
                No Page Transition
              </option>
            </select>
          </div>

          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Button Micro-Interaction
            </label>
            <select
              className="glass-input"
              value={config.button_effect}
              onChange={(e) =>
                setConfig({
                  ...config,
                  button_effect: e.target.value as AnimationConfig['button_effect']
                })
              }
            >
              <option value="scale-press" style={{ background: '#1f1c2c' }}>
                Tactile Scale Press
              </option>
              <option value="glow-hover" style={{ background: '#1f1c2c' }}>
                Luminous Glow
              </option>
              <option value="ripple" style={{ background: '#1f1c2c' }}>
                Soft Opacity Ripple
              </option>
              <option value="none" style={{ background: '#1f1c2c' }}>
                None
              </option>
            </select>
          </div>
        </div>

        <div className="form-row-2">
          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Pulse Cycle Duration: {config.pulse_duration_s}s
            </label>
            <input
              type="range"
              min="0.5"
              max="10"
              step="0.1"
              value={config.pulse_duration_s}
              onChange={(e) =>
                setConfig({ ...config, pulse_duration_s: parseFloat(e.target.value) })
              }
              style={{ width: '100%' }}
            />
          </div>

          <div>
            <label style={{ fontSize: 13, display: 'block', marginBottom: 6 }}>
              Frosted Glass Surface Blur: {config.glass_blur_px}px
            </label>
            <input
              type="range"
              min="0"
              max="60"
              value={config.glass_blur_px}
              onChange={(e) =>
                setConfig({ ...config, glass_blur_px: parseInt(e.target.value, 10) })
              }
              style={{ width: '100%' }}
            />
          </div>
        </div>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={config.inject_stylesheet !== false}
            onChange={(e) => setConfig({ ...config, inject_stylesheet: e.target.checked })}
          />
          Inject <code>apk_studio_animations.css</code> into packaged Android WebView assets
        </label>

        <div style={{ marginTop: 8 }}>
          <GlassButton type="button" onClick={handleSave} disabled={isSaving}>
            {isSaving ? 'Saving Animation Preset...' : 'Save & Apply Animation Configuration'}
          </GlassButton>
        </div>

        {statusMessage && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              fontSize: 13,
              color: '#00ffc8',
              textAlign: 'center'
            }}
          >
            <CheckCircle2 size={16} />
            <span>{statusMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};
