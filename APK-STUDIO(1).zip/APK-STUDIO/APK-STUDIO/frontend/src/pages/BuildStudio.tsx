import React, { useEffect, useState } from 'react';
import { BuildRecord, ToolchainDiagnostics } from '../types';
import { API } from '../services/api';
import { GlassButton } from '../components/GlassButton';
import { StatusBadge } from '../components/StatusBadge';
import {
  Terminal,
  Download,
  Play,
  AlertCircle,
  CheckCircle,
  FolderArchive,
  Wrench
} from 'lucide-react';

interface Props {
  projectId: string;
}

export const BuildStudio: React.FC<Props> = ({ projectId }) => {
  const [builds, setBuilds] = useState<BuildRecord[]>([]);
  const [activeBuild, setActiveBuild] = useState<BuildRecord | null>(null);
  const [buildType, setBuildType] = useState<'debug' | 'release'>('debug');
  const [isTriggering, setIsTriggering] = useState(false);
  const [toolchain, setToolchain] = useState<ToolchainDiagnostics | null>(null);
  const [exportStatus, setExportStatus] = useState<string | null>(null);

  const loadBuilds = async () => {
    const list = await API.listBuilds(projectId);
    setBuilds(list);
    if (list.length > 0 && !activeBuild) {
      setActiveBuild(list[0]);
    }
  };

  const loadDiagnostics = async () => {
    try {
      const diag = await API.getSystemDiagnostics();
      setToolchain(diag.toolchain);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    loadBuilds();
    loadDiagnostics();
  }, [projectId]);

  useEffect(() => {
    if (!activeBuild || ['success', 'failed'].includes(activeBuild.status)) return;
    const interval = setInterval(async () => {
      const updated = await API.getBuildStatus(activeBuild.id);
      setActiveBuild(updated);
      if (['success', 'failed'].includes(updated.status)) {
        loadBuilds();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [activeBuild]);

  const handleStartBuild = async () => {
    setIsTriggering(true);
    setExportStatus(null);
    try {
      const { buildId } = await API.triggerBuild(projectId, buildType);
      const initialRecord = await API.getBuildStatus(buildId);
      setActiveBuild(initialRecord);
      await loadBuilds();
    } finally {
      setIsTriggering(false);
    }
  };

  const handleExportAndroidProject = async () => {
    if (!activeBuild) return;
    setExportStatus('Packaging Android Gradle project (.zip)...');
    try {
      await API.exportAndroidGradleProject(activeBuild.id);
      setExportStatus('Exported Android Gradle project (.zip) successfully.');
    } catch (err: any) {
      setExportStatus(`Export failed: ${err.message}`);
    }
  };

  const remoteBase = API.getRemoteBackendUrl();
  const downloadApkHref = activeBuild
    ? `${remoteBase || ''}/api/builds/${activeBuild.id}/download`
    : '#';

  return (
    <div style={{ width: '100%', maxWidth: 1200, display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Host Toolchain Readiness Banner */}
      {toolchain && (
        <div
          className="glass-panel"
          style={{
            padding: '16px 22px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 12
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Wrench
              size={18}
              color={toolchain.readyForNativeBuild ? '#00ffc8' : '#feca57'}
            />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>
                Android Build Environment:{' '}
                {toolchain.readyForNativeBuild
                  ? 'Native SDK & Gradle Ready'
                  : 'Standalone / Host Missing Native Android SDK'}
              </div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.68)' }}>
                Java: {toolchain.javaAvailable ? 'OK' : 'Missing'} • javac:{' '}
                {toolchain.javacAvailable ? 'OK' : 'Missing'} • Android SDK 34:{' '}
                {toolchain.platform34Installed ? 'OK' : 'Missing'} • Gradle:{' '}
                {toolchain.gradleAvailable ? 'OK' : 'Missing'}
              </div>
            </div>
          </div>
          <StatusBadge
            status={toolchain.readyForNativeBuild ? 'ready' : 'warn'}
            label={
              toolchain.readyForNativeBuild
                ? 'Full APK Compilation Ready'
                : 'Generates Android Gradle Project (.zip)'
            }
          />
        </div>
      )}

      <div className="build-layout">
        {/* Left: Build Controls & History */}
        <div
          className="glass-panel"
          style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 14 }}
        >
          <h3 style={{ fontSize: 18 }}>Compilation Engine</h3>

          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={() => setBuildType('debug')}
              style={{
                flex: 1,
                padding: '9px',
                borderRadius: 10,
                border: '1px solid rgba(255,255,255,0.2)',
                background: buildType === 'debug' ? 'rgba(255,255,255,0.2)' : 'transparent',
                color: '#fff',
                fontSize: 12.5,
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              Debug APK
            </button>
            <button
              type="button"
              onClick={() => setBuildType('release')}
              style={{
                flex: 1,
                padding: '9px',
                borderRadius: 10,
                border: '1px solid rgba(255,255,255,0.2)',
                background: buildType === 'release' ? 'rgba(255,255,255,0.2)' : 'transparent',
                color: '#fff',
                fontSize: 12.5,
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              Release APK
            </button>
          </div>

          <GlassButton
            onClick={handleStartBuild}
            disabled={isTriggering || activeBuild?.status === 'building'}
          >
            <Play size={16} />{' '}
            {activeBuild?.status === 'building'
              ? 'Compiling...'
              : `Compile Android ${buildType.toUpperCase()} APK`}
          </GlassButton>

          <h4
            style={{
              fontSize: 13,
              marginTop: 10,
              color: 'rgba(255,255,255,0.72)',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}
          >
            Build History ({builds.length})
          </h4>

          <div
            style={{
              flex: 1,
              maxHeight: 420,
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: 8
            }}
          >
            {builds.length === 0 ? (
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>
                No build attempts recorded yet.
              </div>
            ) : (
              builds.map((b) => (
                <div
                  key={b.id}
                  onClick={() => setActiveBuild(b)}
                  style={{
                    padding: 12,
                    borderRadius: 12,
                    cursor: 'pointer',
                    background:
                      activeBuild?.id === b.id ? 'rgba(255,255,255,0.16)' : 'rgba(0,0,0,0.24)',
                    border: '1px solid rgba(255,255,255,0.1)'
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: 4
                    }}
                  >
                    <span style={{ fontSize: 13, fontWeight: 600 }}>
                      #{b.id.substring(0, 8)} ({b.build_type || 'debug'})
                    </span>
                    {b.status === 'success' && <CheckCircle size={15} color="#00ffc8" />}
                    {b.status === 'failed' && <AlertCircle size={15} color="#ff6b6b" />}
                    {['queued', 'building'].includes(b.status) && (
                      <span style={{ fontSize: 11, color: '#feca57' }}>
                        {b.stage || 'Building...'}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: 'rgba(255,255,255,0.55)',
                      display: 'flex',
                      justifyContent: 'space-between'
                    }}
                  >
                    <span>{new Date(b.started_at).toLocaleString()}</span>
                    <span>{b.status.toUpperCase()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Stage Progress, Artifact Downloads & Console Output */}
        <div
          className="glass-panel"
          style={{ flex: 1, padding: 24, display: 'flex', flexDirection: 'column', gap: 14 }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 10
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Terminal size={18} color="#00ffc8" />
              <h3 style={{ fontSize: 16 }}>
                Build Pipeline Output{' '}
                {activeBuild ? `(Stage: ${activeBuild.stage || activeBuild.status})` : ''}
              </h3>
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {activeBuild && (
                <button
                  type="button"
                  onClick={handleExportAndroidProject}
                  className="liquid-glass-btn"
                  style={{
                    width: 'auto',
                    padding: '8px 14px',
                    fontSize: 12,
                    minHeight: 36
                  }}
                >
                  <FolderArchive size={14} /> Export Android Gradle Project (.zip)
                </button>
              )}

              {activeBuild?.status === 'success' && activeBuild.apk_filename && (
                <a
                  href={downloadApkHref}
                  className="liquid-glass-btn"
                  style={{
                    width: 'auto',
                    padding: '8px 16px',
                    fontSize: 12.5,
                    minHeight: 36,
                    background: 'rgba(0, 255, 200, 0.22)'
                  }}
                >
                  <Download size={14} /> Download Verified APK ({activeBuild.apk_filename})
                </a>
              )}
            </div>
          </div>

          {exportStatus && (
            <div style={{ fontSize: 12, color: '#00ffc8' }}>{exportStatus}</div>
          )}

          {/* Real Build Stage Progress Bar */}
          {activeBuild && (
            <div
              style={{
                width: '100%',
                height: 8,
                background: 'rgba(0,0,0,0.4)',
                borderRadius: 999,
                overflow: 'hidden'
              }}
            >
              <div
                style={{
                  width: `${activeBuild.progress || (activeBuild.status === 'success' ? 100 : 35)}%`,
                  height: '100%',
                  background:
                    activeBuild.status === 'failed'
                      ? '#ff6b6b'
                      : activeBuild.status === 'success'
                      ? '#00ffc8'
                      : '#feca57',
                  transition: 'width 0.3s ease'
                }}
              />
            </div>
          )}

          {activeBuild?.error_summary && (
            <div
              style={{
                padding: '10px 14px',
                borderRadius: 12,
                background: 'rgba(255, 107, 107, 0.16)',
                border: '1px solid rgba(255, 107, 107, 0.35)',
                color: '#ff9f9f',
                fontSize: 12.5
              }}
            >
              <strong>Diagnostic Summary:</strong> {activeBuild.error_summary}
            </div>
          )}

          <div
            style={{
              flex: 1,
              background: 'rgba(0, 0, 0, 0.52)',
              borderRadius: 14,
              padding: 16,
              fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
              fontSize: 12,
              lineHeight: 1.55,
              color: '#cbd5e1',
              overflowY: 'auto',
              minHeight: 380,
              maxHeight: 500,
              whiteSpace: 'pre-wrap',
              border: '1px solid rgba(255,255,255,0.08)'
            }}
          >
            {activeBuild
              ? activeBuild.log || 'Build job queued. Initializing build stages...'
              : 'Select a build record or trigger a new compilation to inspect real-time build stage logs.'}
          </div>
        </div>
      </div>
    </div>
  );
};
