import React, { useState } from 'react';
import { Project } from '../types';
import { GlassButton } from '../components/GlassButton';
import { GlassModal } from '../components/GlassModal';
import { StatusBadge } from '../components/StatusBadge';
import { Plus, Trash2, FolderOpen, Terminal, Edit3, Copy } from 'lucide-react';

interface Props {
  projects: Project[];
  errorBanner?: string | null;
  onSelectProject: (p: Project) => void;
  onCreateProject: (name: string, type: 'html' | 'python') => Promise<void>;
  onRenameProject: (id: string, newName: string) => Promise<void>;
  onDuplicateProject: (id: string) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
}

export const Dashboard: React.FC<Props> = ({
  projects,
  errorBanner,
  onSelectProject,
  onCreateProject,
  onRenameProject,
  onDuplicateProject,
  onDeleteProject
}) => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [projectType, setProjectType] = useState<'html' | 'python'>('html');

  const [renameTarget, setRenameTarget] = useState<Project | null>(null);
  const [renameValue, setRenameValue] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectName.trim()) {
      setFormError('Please enter a project name.');
      return;
    }
    setFormError(null);
    await onCreateProject(projectName.trim(), projectType);
    setProjectName('');
    setIsCreateOpen(false);
  };

  const handleRenameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTarget || !renameValue.trim()) return;
    await onRenameProject(renameTarget.id, renameValue.trim());
    setRenameTarget(null);
    setRenameValue('');
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    await onDeleteProject(deleteTarget.id);
    setDeleteTarget(null);
  };

  return (
    <div style={{ width: '100%', maxWidth: 1080 }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 16,
          marginBottom: 28
        }}
      >
        <div>
          <h2 style={{ fontSize: 28, fontWeight: 700 }}>Workspace Projects</h2>
          <p style={{ color: 'rgba(255,255,255,0.72)', fontSize: 14 }}>
            Create, import, customize, and package HTML5 and Python applications for Android.
          </p>
        </div>
        <div style={{ width: 185 }}>
          <GlassButton
            onClick={() => {
              setFormError(null);
              setIsCreateOpen(true);
            }}
          >
            <Plus size={18} /> New Project
          </GlassButton>
        </div>
      </div>

      {errorBanner && (
        <div
          className="glass-panel"
          style={{
            padding: '12px 18px',
            marginBottom: 20,
            borderColor: 'rgba(255, 107, 107, 0.45)',
            color: '#ff6b6b',
            fontSize: 13
          }}
        >
          {errorBanner}
        </div>
      )}

      {projects.length === 0 ? (
        <div className="glass-panel" style={{ padding: 48, textAlign: 'center' }}>
          <div className="app-icon" style={{ marginBottom: 18 }}>
            <FolderOpen size={30} />
          </div>
          <h3 style={{ fontSize: 20, marginBottom: 8 }}>No Projects Yet</h3>
          <p style={{ color: 'rgba(255,255,255,0.68)', fontSize: 14, marginBottom: 24 }}>
            Create your first HTML5 or Python project to launch the code editor, live preview, and
            Android APK build studio.
          </p>
          <div style={{ width: 200, margin: '0 auto' }}>
            <GlassButton onClick={() => setIsCreateOpen(true)}>
              <Plus size={18} /> Create First Project
            </GlassButton>
          </div>
        </div>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: 20
          }}
        >
          {projects.map((p) => (
            <div
              key={p.id}
              className="glass-panel"
              style={{
                padding: 24,
                cursor: 'pointer',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                minHeight: 205,
                transition: 'transform 0.25s ease'
              }}
              onClick={() => onSelectProject(p)}
            >
              <div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start'
                  }}
                >
                  <div
                    className="app-icon"
                    style={{ width: 46, height: 46, margin: '0 0 14px 0', borderRadius: 13 }}
                  >
                    {p.type === 'python' ? <Terminal size={21} /> : <FolderOpen size={21} />}
                  </div>

                  <div
                    style={{ display: 'flex', gap: 6 }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      title="Rename Project"
                      onClick={() => {
                        setRenameTarget(p);
                        setRenameValue(p.name);
                      }}
                      style={{
                        background: 'rgba(255,255,255,0.08)',
                        border: '1px solid rgba(255,255,255,0.12)',
                        borderRadius: 8,
                        padding: 6,
                        color: 'rgba(255,255,255,0.75)',
                        cursor: 'pointer',
                        display: 'flex'
                      }}
                    >
                      <Edit3 size={14} />
                    </button>
                    <button
                      type="button"
                      title="Duplicate Project"
                      onClick={() => onDuplicateProject(p.id)}
                      style={{
                        background: 'rgba(255,255,255,0.08)',
                        border: '1px solid rgba(255,255,255,0.12)',
                        borderRadius: 8,
                        padding: 6,
                        color: 'rgba(255,255,255,0.75)',
                        cursor: 'pointer',
                        display: 'flex'
                      }}
                    >
                      <Copy size={14} />
                    </button>
                    <button
                      type="button"
                      title="Delete Project"
                      onClick={() => setDeleteTarget(p)}
                      style={{
                        background: 'rgba(255,107,107,0.12)',
                        border: '1px solid rgba(255,107,107,0.25)',
                        borderRadius: 8,
                        padding: 6,
                        color: '#ff6b6b',
                        cursor: 'pointer',
                        display: 'flex'
                      }}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <h3 className="truncate-text" style={{ fontSize: 18, marginBottom: 6 }}>
                  {p.name}
                </h3>

                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                  <StatusBadge status={p.type} label={p.type === 'python' ? 'Python' : 'HTML5 Web'} />
                  <StatusBadge
                    status={p.last_build_status || p.status || 'ready'}
                    label={
                      p.last_build_status
                        ? `Last Build: ${p.last_build_status}`
                        : p.status || 'Ready'
                    }
                  />
                </div>

                {p.package_id && (
                  <div
                    className="truncate-text"
                    style={{
                      fontSize: 12,
                      color: 'rgba(255,255,255,0.6)',
                      marginTop: 10,
                      fontFamily: 'monospace'
                    }}
                  >
                    {p.package_id} • v{p.version_name || '1.0.0'}
                  </div>
                )}
              </div>

              <div
                style={{
                  fontSize: 12,
                  color: 'rgba(255,255,255,0.5)',
                  marginTop: 14,
                  display: 'flex',
                  justifyContent: 'space-between'
                }}
              >
                <span>Modified: {new Date(p.updated_at).toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Project Modal */}
      <GlassModal
        isOpen={isCreateOpen}
        title="Create New Project"
        onClose={() => setIsCreateOpen(false)}
      >
        <form onSubmit={handleCreate}>
          <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 }}>
            Project Name
          </label>
          <input
            className="glass-input"
            placeholder="e.g. Storefront Portal"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            autoFocus
            style={{ marginBottom: 16 }}
          />

          <label style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', display: 'block', marginBottom: 6 }}>
            Runtime Architecture
          </label>
          <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
            <button
              type="button"
              onClick={() => setProjectType('html')}
              style={{
                flex: 1,
                padding: '12px 10px',
                borderRadius: 12,
                border: '1px solid rgba(255,255,255,0.22)',
                background: projectType === 'html' ? 'rgba(255,255,255,0.22)' : 'transparent',
                color: '#fff',
                cursor: 'pointer',
                fontWeight: 600
              }}
            >
              HTML5 / CSS / JS
            </button>
            <button
              type="button"
              onClick={() => setProjectType('python')}
              style={{
                flex: 1,
                padding: '12px 10px',
                borderRadius: 12,
                border: '1px solid rgba(255,255,255,0.22)',
                background: projectType === 'python' ? 'rgba(255,255,255,0.22)' : 'transparent',
                color: '#fff',
                cursor: 'pointer',
                fontWeight: 600
              }}
            >
              Python Bridge
            </button>
          </div>

          {formError && (
            <div style={{ color: '#ff6b6b', fontSize: 12, marginBottom: 12 }}>{formError}</div>
          )}

          <div style={{ display: 'flex', gap: 12 }}>
            <GlassButton type="submit">Create Project</GlassButton>
            <button
              type="button"
              onClick={() => setIsCreateOpen(false)}
              style={{
                flex: 1,
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.15)',
                borderRadius: 14,
                color: 'rgba(255,255,255,0.75)',
                cursor: 'pointer'
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      </GlassModal>

      {/* Rename Project Modal */}
      <GlassModal
        isOpen={Boolean(renameTarget)}
        title="Rename Project"
        onClose={() => setRenameTarget(null)}
      >
        <form onSubmit={handleRenameSubmit}>
          <input
            className="glass-input"
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            autoFocus
            style={{ marginBottom: 20 }}
          />
          <div style={{ display: 'flex', gap: 12 }}>
            <GlassButton type="submit">Save Name</GlassButton>
            <button
              type="button"
              onClick={() => setRenameTarget(null)}
              style={{
                flex: 1,
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.15)',
                borderRadius: 14,
                color: 'rgba(255,255,255,0.75)',
                cursor: 'pointer'
              }}
            >
              Cancel
            </button>
          </div>
        </form>
      </GlassModal>

      {/* Delete Confirmation Modal */}
      <GlassModal
        isOpen={Boolean(deleteTarget)}
        title="Delete Project"
        onClose={() => setDeleteTarget(null)}
      >
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.8)', marginBottom: 24, lineHeight: 1.5 }}>
          Are you sure you want to permanently delete{' '}
          <strong>{deleteTarget?.name}</strong> and all of its source files and build records?
        </p>
        <div style={{ display: 'flex', gap: 12 }}>
          <GlassButton
            type="button"
            onClick={handleConfirmDelete}
            style={{ background: 'rgba(255, 107, 107, 0.28)' }}
          >
            Delete Permanently
          </GlassButton>
          <button
            type="button"
            onClick={() => setDeleteTarget(null)}
            style={{
              flex: 1,
              background: 'transparent',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 14,
              color: 'rgba(255,255,255,0.75)',
              cursor: 'pointer'
            }}
          >
            Cancel
          </button>
        </div>
      </GlassModal>
    </div>
  );
};
