import React, { useState } from 'react';
import { Layers, Play, Sliders, Box, Code, Settings } from 'lucide-react';
import { GlassModal } from '../components/GlassModal';
import { GlassButton } from '../components/GlassButton';
import { API } from '../services/api';

interface Props {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedProjectName?: string;
}

export const MainLayout: React.FC<Props> = ({
  children,
  activeTab,
  setActiveTab,
  selectedProjectName
}) => {
  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [serverUrlInput, setServerUrlInput] = useState(API.getRemoteBackendUrl());
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Layers, disabled: false },
    { id: 'editor', label: 'Code & Files', icon: Code, disabled: !selectedProjectName },
    { id: 'customization', label: 'Customization', icon: Sliders, disabled: !selectedProjectName },
    { id: 'animations', label: 'Animations', icon: Play, disabled: !selectedProjectName },
    { id: 'build', label: 'Build Engine', icon: Box, disabled: !selectedProjectName }
  ];

  const handleSaveServerUrl = (e: React.FormEvent) => {
    e.preventDefault();
    API.setRemoteBackendUrl(serverUrlInput);
    setSavedNotice(
      serverUrlInput.trim()
        ? `Connected remote build server: ${serverUrlInput.trim()}`
        : 'Using local / on-device workspace engine.'
    );
    setTimeout(() => {
      setSavedNotice(null);
      setIsServerModalOpen(false);
    }, 900);
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', flexDirection: 'column' }}>
      <header className="studio-header">
        <div
          style={{ display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
          onClick={() => setActiveTab('dashboard')}
        >
          <div className="app-icon" style={{ width: 42, height: 42, margin: 0, borderRadius: 12 }}>
            <svg viewBox="0 0 24 24" style={{ width: 22, height: 22, fill: 'none' }}>
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <div>
            <h1 style={{ fontSize: 18, margin: 0, letterSpacing: '-0.3px' }}>APK STUDIO</h1>
            <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)' }}>
              {selectedProjectName ? `Active Project: ${selectedProjectName}` : 'No active project selected'}
            </span>
          </div>
        </div>

        <nav className="studio-nav" aria-label="Main Studio Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                disabled={item.disabled}
                onClick={() => setActiveTab(item.id)}
                style={{
                  background: isActive ? 'rgba(255,255,255,0.18)' : 'transparent',
                  border: '1px solid',
                  borderColor: isActive ? 'rgba(255,255,255,0.32)' : 'transparent',
                  borderRadius: 10,
                  color: item.disabled ? 'rgba(255,255,255,0.25)' : '#fff',
                  padding: '8px 14px',
                  cursor: item.disabled ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  fontSize: 13,
                  fontWeight: 500,
                  transition: 'all 0.2s',
                  whiteSpace: 'nowrap'
                }}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}

          <button
            type="button"
            title="Build Server & Connection Settings"
            onClick={() => {
              setServerUrlInput(API.getRemoteBackendUrl());
              setSavedNotice(null);
              setIsServerModalOpen(true);
            }}
            style={{
              background: API.getRemoteBackendUrl() ? 'rgba(0, 255, 200, 0.16)' : 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.2)',
              borderRadius: 10,
              color: '#fff',
              padding: '8px 12px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              fontSize: 12,
              fontWeight: 500
            }}
          >
            <Settings size={15} />
            <span>{API.getRemoteBackendUrl() ? 'Remote Server' : 'Engine Config'}</span>
          </button>
        </nav>
      </header>

      <main className="studio-main">{children}</main>

      <GlassModal
        isOpen={isServerModalOpen}
        title="Build Engine & Server Configuration"
        onClose={() => setIsServerModalOpen(false)}
      >
        <form onSubmit={handleSaveServerUrl}>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.75)', marginBottom: 14, lineHeight: 1.5 }}>
            APK STUDIO runs with a persistent On-Device Workspace inside the Android APK and syncs
            automatically with your Node.js/Docker Build Server when reachable. To delegate native
            Gradle APK compilation from a mobile device to a remote host, enter your server URL below:
          </p>
          <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', display: 'block', marginBottom: 6 }}>
            Remote Build Server URL (leave blank for Local / On-Device Mode)
          </label>
          <input
            className="glass-input"
            placeholder="e.g. http://192.168.1.50:4000"
            value={serverUrlInput}
            onChange={(e) => setServerUrlInput(e.target.value)}
            style={{ marginBottom: 16 }}
          />
          {savedNotice && (
            <div style={{ fontSize: 12, color: '#00ffc8', marginBottom: 12 }}>{savedNotice}</div>
          )}
          <div style={{ display: 'flex', gap: 10 }}>
            <GlassButton type="submit">Save Configuration</GlassButton>
            <button
              type="button"
              onClick={() => setIsServerModalOpen(false)}
              style={{
                flex: 1,
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.15)',
                borderRadius: 14,
                color: 'rgba(255,255,255,0.75)',
                cursor: 'pointer'
              }}
            >
              Close
            </button>
          </div>
        </form>
      </GlassModal>
    </div>
  );
};
