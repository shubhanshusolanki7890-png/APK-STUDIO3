import React from 'react';

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

export const GlassButton: React.FC<Props> = ({ children, className = '', ...props }) => {
  return (
    <button className={`liquid-glass-btn ${className}`} {...props}>
      {children}
    </button>
  );
};
