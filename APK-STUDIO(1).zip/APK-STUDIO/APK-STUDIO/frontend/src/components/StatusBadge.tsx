import React from 'react';

interface Props {
  status: string;
  label?: string;
}

export const StatusBadge: React.FC<Props> = ({ status, label }) => {
  const normalized = (status || 'ready').toLowerCase();
  let bg = 'rgba(255, 255, 255, 0.12)';
  let color = '#ffffff';
  let border = 'rgba(255, 255, 255, 0.25)';

  if (['success', 'built', 'supported', 'ready'].includes(normalized)) {
    bg = 'rgba(0, 255, 200, 0.15)';
    color = '#00ffc8';
    border = 'rgba(0, 255, 200, 0.35)';
  } else if (['building', 'queued', 'requires_modification', 'warn'].includes(normalized)) {
    bg = 'rgba(254, 202, 87, 0.16)';
    color = '#feca57';
    border = 'rgba(254, 202, 87, 0.38)';
  } else if (['failed', 'error', 'unsupported'].includes(normalized)) {
    bg = 'rgba(255, 107, 107, 0.18)';
    color = '#ff6b6b';
    border = 'rgba(255, 107, 107, 0.4)';
  }

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        fontSize: 11,
        fontWeight: 600,
        textTransform: 'uppercase',
        letterSpacing: '0.4px',
        padding: '3px 9px',
        borderRadius: 999,
        background: bg,
        color,
        border: `1px solid ${border}`
      }}
    >
      {label || status}
    </span>
  );
};
