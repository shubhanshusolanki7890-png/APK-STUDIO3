import React from 'react';

interface Props {
  isOpen: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}

export const GlassModal: React.FC<Props> = ({ isOpen, title, onClose, children }) => {
  if (!isOpen) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.65)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 100,
        padding: 16
      }}
    >
      <div
        className="window-container"
        onClick={(e) => e.stopPropagation()}
        style={{ textAlign: 'left' }}
      >
        <h2 style={{ fontSize: 21, marginBottom: 16, fontWeight: 700, textAlign: 'center' }}>
          {title}
        </h2>
        {children}
      </div>
    </div>
  );
};
