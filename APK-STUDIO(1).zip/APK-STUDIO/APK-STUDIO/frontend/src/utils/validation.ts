import { CustomizationSettings } from '../types';

export function validateCustomizationClient(settings: CustomizationSettings): string[] {
  const errors: string[] = [];

  if (!settings.app_name || !settings.app_name.trim()) {
    errors.push('Application name cannot be empty.');
  }

  const pkgRegex = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;
  if (!settings.package_id || !pkgRegex.test(settings.package_id.trim())) {
    errors.push("Android Package ID must have at least two segments (e.g. 'com.company.myapp') using letters, digits, and underscores.");
  }

  const verRegex = /^[0-9]+(\.[0-9]+){0,3}(-[a-zA-Z0-9._-]+)?$/;
  if (!settings.version_name || !verRegex.test(settings.version_name.trim())) {
    errors.push("Version Name must follow semantic format (e.g. '1.0.0').");
  }

  if (!Number.isInteger(Number(settings.version_code)) || Number(settings.version_code) < 1) {
    errors.push('Version Code must be a positive integer (>= 1).');
  }

  const hexRegex = /^#[0-9A-Fa-f]{6}$/;
  if (!hexRegex.test(settings.status_bar_color)) {
    errors.push('Status Bar Color must be a valid 6-digit hex color.');
  }
  if (!hexRegex.test(settings.nav_bar_color)) {
    errors.push('Navigation Bar Color must be a valid 6-digit hex color.');
  }

  return errors;
}
