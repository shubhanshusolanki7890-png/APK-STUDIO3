export function detectLanguageFromPath(filePath: string): string {
  const lower = filePath.toLowerCase();
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'HTML';
  if (lower.endsWith('.css')) return 'CSS';
  if (lower.endsWith('.js') || lower.endsWith('.mjs')) return 'JavaScript';
  if (lower.endsWith('.ts') || lower.endsWith('.tsx')) return 'TypeScript';
  if (lower.endsWith('.py')) return 'Python';
  if (lower.endsWith('.json')) return 'JSON';
  if (lower.endsWith('.xml')) return 'XML';
  if (lower.endsWith('.md')) return 'Markdown';
  return 'Plain Text';
}

export function getSyntaxAccentColor(language: string): string {
  switch (language) {
    case 'HTML':
      return '#ff9ff3';
    case 'CSS':
      return '#54a0ff';
    case 'JavaScript':
    case 'TypeScript':
      return '#feca57';
    case 'Python':
      return '#00ffc8';
    case 'JSON':
      return '#1dd1a1';
    default:
      return '#e2e8f0';
  }
}
