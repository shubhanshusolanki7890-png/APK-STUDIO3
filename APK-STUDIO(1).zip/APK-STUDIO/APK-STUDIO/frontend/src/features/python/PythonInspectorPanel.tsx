import React from 'react';
import { PythonInspectionResult } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { GlassButton } from '../../components/GlassButton';
import { Cpu, Wand2 } from 'lucide-react';

interface Props {
  inspection: PythonInspectionResult | null;
  onGenerateBridge: () => void;
  isGeneratingBridge: boolean;
}

export const PythonInspectorPanel: React.FC<Props> = ({
  inspection,
  onGenerateBridge,
  isGeneratingBridge
}) => {
  if (!inspection) return null;

  const tierLabel =
    inspection.classification === 'supported'
      ? 'Supported for Packaging'
      : inspection.classification === 'requires_modification'
      ? 'Requires Modification'
      : 'Unsupported Modules / Error';

  return (
    <div
      style={{
        padding: 14,
        borderRadius: 14,
        background: 'rgba(0, 0, 0, 0.32)',
        border: '1px solid rgba(255, 255, 255, 0.12)',
        marginBottom: 12,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 8
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Cpu size={16} color="#00ffc8" />
          <span style={{ fontSize: 13, fontWeight: 600 }}>
            Python Packaging Diagnostics ({inspection.entrypoint || 'No entrypoint'})
          </span>
        </div>
        <StatusBadge status={inspection.classification} label={tierLabel} />
      </div>

      {inspection.error && (
        <div style={{ fontSize: 12, color: '#ff6b6b' }}>{inspection.error}</div>
      )}

      {inspection.unsupported_modules && inspection.unsupported_modules.length > 0 && (
        <div style={{ fontSize: 12, color: '#ff6b6b' }}>
          <strong>Incompatible Modules:</strong>
          <ul style={{ paddingLeft: 18, marginTop: 4 }}>
            {inspection.unsupported_modules.map((u) => (
              <li key={u.module}>
                <code>{u.module}</code>: {u.reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {inspection.modification_reasons && inspection.modification_reasons.length > 0 && (
        <div style={{ fontSize: 12, color: '#feca57' }}>
          <strong>Required Modifications:</strong>
          <ul style={{ paddingLeft: 18, marginTop: 4 }}>
            {inspection.modification_reasons.map((m, i) => (
              <li key={i}>{m}</li>
            ))}
          </ul>
        </div>
      )}

      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 8,
          fontSize: 11,
          color: 'rgba(255,255,255,0.65)'
        }}
      >
        <span>
          Imports:{' '}
          {inspection.detected_imports.length > 0
            ? inspection.detected_imports.join(', ')
            : 'None'}{' '}
          | HTML Bridge: {inspection.has_html_bridge ? 'Present' : 'Missing'}
        </span>

        <div style={{ width: 'auto' }}>
          <GlassButton
            type="button"
            onClick={onGenerateBridge}
            disabled={isGeneratingBridge}
            style={{ padding: '6px 12px', minHeight: 32, fontSize: 12 }}
          >
            <Wand2 size={13} />{' '}
            {isGeneratingBridge ? 'Generating...' : 'Generate / Refresh HTML Bridge'}
          </GlassButton>
        </div>
      </div>
    </div>
  );
};
