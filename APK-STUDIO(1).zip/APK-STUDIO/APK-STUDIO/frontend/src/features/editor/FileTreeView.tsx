import React, { useState } from 'react';
import { FileTreeNode } from '../../types';
import { Folder, FolderOpen, FileCode, Image, Trash2 } from 'lucide-react';

interface Props {
  nodes: FileTreeNode[];
  activeFile: string;
  onSelectFile: (path: string) => void;
  onDeleteFile: (path: string) => void;
  depth?: number;
}

export const FileTreeView: React.FC<Props> = ({
  nodes,
  activeFile,
  onSelectFile,
  onDeleteFile,
  depth = 0
}) => {
  const [collapsedDirs, setCollapsedDirs] = useState<Record<string, boolean>>({});

  const toggleDir = (dirPath: string) => {
    setCollapsedDirs((prev) => ({ ...prev, [dirPath]: !prev[dirPath] }));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {nodes.map((node) => {
        const isCollapsed = Boolean(collapsedDirs[node.path]);
        const isSelected = !node.isDirectory && activeFile === node.path;

        return (
          <div key={node.path}>
            <div
              onClick={() =>
                node.isDirectory ? toggleDir(node.path) : onSelectFile(node.path)
              }
              style={{
                padding: '6px 8px',
                paddingLeft: 8 + depth * 14,
                fontSize: 13,
                borderRadius: 8,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 6,
                background: isSelected ? 'rgba(255, 255, 255, 0.16)' : 'transparent',
                color: node.isDirectory ? 'rgba(255, 255, 255, 0.85)' : '#fff'
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 7,
                  minWidth: 0,
                  flex: 1
                }}
              >
                {node.isDirectory ? (
                  isCollapsed ? (
                    <Folder size={14} color="#feca57" />
                  ) : (
                    <FolderOpen size={14} color="#feca57" />
                  )
                ) : node.isBinary ? (
                  <Image size={14} color="#54a0ff" />
                ) : (
                  <FileCode size={14} color="#00ffc8" />
                )}
                <span className="truncate-text" title={node.path}>
                  {node.name}
                </span>
              </div>

              {!node.isDirectory && node.path !== 'index.html' && (
                <button
                  type="button"
                  title={`Delete ${node.path}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteFile(node.path);
                  }}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'rgba(255,255,255,0.35)',
                    cursor: 'pointer',
                    padding: 2,
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  <Trash2 size={12} />
                </button>
              )}
            </div>

            {node.isDirectory && !isCollapsed && node.children && node.children.length > 0 && (
              <FileTreeView
                nodes={node.children}
                activeFile={activeFile}
                onSelectFile={onSelectFile}
                onDeleteFile={onDeleteFile}
                depth={depth + 1}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};
