import React, { useEffect, useState } from 'react';
import { PreviewConsoleEntry } from '../../types';
import { API } from '../../services/api';
import { Smartphone, RefreshCw, RotateCcw, Terminal, Trash2, Info } from 'lucide-react';

interface Props {
  projectId: string;
  previewKey: number;
  onRefresh: () => void;
}

const SCREEN_PRESETS = [
  { id: 'compact', label: 'Compact (320×560)', width: 320, height: 560 },
  { id: 'pixel', label: 'Android (360×640)', width: 360, height: 640 },
  { id: 'tablet', label: 'Tablet (520×680)', width: 520, height: 680 }
];

export const LivePreviewPane: React.FC<Props> = ({ projectId, previewKey, onRefresh }) => {
  const [presetId, setPresetId] = useState('compact');
  const [isLandscape, setIsLandscape] = useState(false);
  const [consoleLogs, setConsoleLogs] = useState<PreviewConsoleEntry[]>([]);
  const [showConsole, setShowConsole] = useState(true);
  const [showLimitations, setShowLimitations] = useState(false);

  const activePreset = SCREEN_PRESETS.find((p) => p.id === presetId) || SCREEN_PRESETS[0];
  const frameWidth = isLandscape ? Math.min(activePreset.height, 520) : activePreset.width;
  const frameHeight = isLandscape ? activePreset.width : activePreset.height;

  const isStandalone = API.isStandaloneWebViewMode();
  const remoteBase = API.getRemoteBackendUrl();
  const previewSrcUrl = remoteBase
    ? `${remoteBase}/preview/${projectId}/index.html?t=${previewKey}`
    : `/preview/${projectId}/index.html?t=${previewKey}`;
  const inlineSrcDoc = isStandalone ? API.compileLivePreviewSrcDoc(projectId) : undefined;

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.source === 'apk-studio-preview') {
        const entry: PreviewConsoleEntry = {
          id: `${Date.now()}-${Math.random()}`,
          level: event.data.level || 'info',
          message: String(event.data.message || ''),
          timestamp: event.data.timestamp || new Date().toISOString()
        };
        setConsoleLogs((prev) => [...prev.slice(-49), entry]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const errorCount = consoleLogs.filter((l) => l.level === 'error').length;

  return (
    <div
      className="glass-panel editor-preview-col"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: 18,
        gap: 12
      }}
    >
      {/* Top Preview Toolbar */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          flexWrap: 'wrap',
          gap: 8
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Smartphone size={16} color="#00ffc8" />
          <span style={{ fontSize: 14, fontWeight: 600 }}>Android Web Sandbox</span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <select
            className="glass-input"
            value={presetId}
            onChange={(e) => setPresetId(e.target.value)}
            style={{ width: 'auto', minHeight: 30, padding: '4px 8px', fontSize: 12 }}
          >
            {SCREEN_PRESETS.map((p) => (
              <option key={p.id} value={p.id} style={{ background: '#1f1c2c' }}>
                {p.label}
              </option>
            ))}
          </select>

          <button
            type="button"
            title="Rotate Orientation"
            onClick={() => setIsLandscape(!isLandscape)}
            style={{
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 8,
              color: '#fff',
              padding: 6,
              cursor: 'pointer',
              display: 'flex'
            }}
          >
            <RotateCcw size={14} />
          </button>

          <button
            type="button"
            title="Sandbox Notes & Limitations"
            onClick={() => setShowLimitations(!showLimitations)}
            style={{
              background: showLimitations ? 'rgba(0,255,200,0.2)' : 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 8,
              color: '#fff',
              padding: 6,
              cursor: 'pointer',
              display: 'flex'
            }}
          >
            <Info size={14} />
          </button>

          <button
            type="button"
            title="Refresh Preview"
            onClick={onRefresh}
            style={{
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 8,
              color: '#fff',
              padding: 6,
              cursor: 'pointer',
              display: 'flex'
            }}
          >
            <RefreshCw size={14} />
          </button>
        </div>
      </div>

      {/* Limitations Notice */}
      {showLimitations && (
        <div
          style={{
            width: '100%',
            padding: '10px 12px',
            borderRadius: 12,
            background: 'rgba(0, 0, 0, 0.38)',
            border: '1px solid rgba(255, 255, 255, 0.14)',
            fontSize: 11,
            color: 'rgba(255, 255, 255, 0.8)',
            lineHeight: 1.45
          }}
        >
          <strong>Preview Sandbox Notes:</strong> Local relative assets (CSS, JS, images, fonts)
          resolve directly from your project root. External APIs that block cross-origin requests
          (CORS) or native Android hardware APIs (vibration, camera, native SQLite) require running
          inside the compiled Android WebView APK.
        </div>
      )}

      {/* Device Frame */}
      <div
        style={{
          width: Math.min(frameWidth, 340),
          height: Math.min(frameHeight, 500),
          border: '7px solid #222',
          borderRadius: 32,
          overflow: 'hidden',
          background: '#fff',
          boxShadow: '0 16px 36px rgba(0,0,0,0.5)'
        }}
      >
        {isStandalone ? (
          <iframe
            key={previewKey}
            srcDoc={inlineSrcDoc}
            title="Live Android WebView Preview"
            style={{ width: '100%', height: '100%', border: 'none' }}
          />
        ) : (
          <iframe
            key={previewKey}
            src={previewSrcUrl}
            title="Live Android WebView Preview"
            style={{ width: '100%', height: '100%', border: 'none' }}
          />
        )}
      </div>

      {/* Live Preview Console Drawer */}
      <div
        style={{
          width: '100%',
          background: 'rgba(0, 0, 0, 0.42)',
          borderRadius: 12,
          border: '1px solid rgba(255, 255, 255, 0.1)',
          overflow: 'hidden'
        }}
      >
        <div
          onClick={() => setShowConsole(!showConsole)}
          style={{
            padding: '8px 12px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            borderBottom: showConsole ? '1px solid rgba(255,255,255,0.08)' : 'none'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
            <Terminal size={13} color="#00ffc8" />
            <span>Preview Console ({consoleLogs.length})</span>
            {errorCount > 0 && (
              <span
                style={{
                  background: 'rgba(255, 107, 107, 0.25)',
                  color: '#ff6b6b',
                  padding: '1px 6px',
                  borderRadius: 999,
                  fontSize: 10,
                  fontWeight: 700
                }}
              >
                {errorCount} error{errorCount > 1 ? 's' : ''}
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setConsoleLogs([]);
            }}
            title="Clear Console"
            style={{
              background: 'transparent',
              border: 'none',
              color: 'rgba(255,255,255,0.5)',
              cursor: 'pointer',
              display: 'flex'
            }}
          >
            <Trash2 size={12} />
          </button>
        </div>

        {showConsole && (
          <div
            style={{
              maxHeight: 110,
              overflowY: 'auto',
              padding: '8px 10px',
              fontFamily: 'monospace',
              fontSize: 11,
              display: 'flex',
              flexDirection: 'column',
              gap: 4
            }}
          >
            {consoleLogs.length === 0 ? (
              <span style={{ color: 'rgba(255,255,255,0.4)' }}>
                No console output or runtime errors captured yet.
              </span>
            ) : (
              consoleLogs.map((log) => (
                <div
                  key={log.id}
                  style={{
                    color:
                      log.level === 'error'
                        ? '#ff6b6b'
                        : log.level === 'warn'
                        ? '#feca57'
                        : '#00ffc8',
                    wordBreak: 'break-word'
                  }}
                >
                  [{log.level.toUpperCase()}] {log.message}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
