import React, { useEffect, useState } from 'react';
import { Project, CustomizationSettings, AnimationConfig } from '../types';
import { API } from '../services/api';
import { MainLayout } from '../layouts/MainLayout';
import { Dashboard } from '../pages/Dashboard';
import { ProjectEditor } from '../pages/ProjectEditor';
import { CustomizationStudio } from '../pages/CustomizationStudio';
import { AnimationStudio } from '../pages/AnimationStudio';
import { BuildStudio } from '../pages/BuildStudio';

export const App: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [customization, setCustomization] = useState<CustomizationSettings | null>(null);
  const [animations, setAnimations] = useState<AnimationConfig | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const refreshProjects = async () => {
    try {
      const list = await API.listProjects();
      setProjects(list);
      setErrorBanner(null);
    } catch (err: any) {
      setErrorBanner(err.message || 'Unable to load workspace projects.');
    }
  };

  useEffect(() => {
    refreshProjects();
  }, []);

  const handleSelectProject = async (p: Project) => {
    try {
      const data = await API.getProject(p.id);
      setSelectedProject(data.project);
      setCustomization(data.customization);
      setAnimations(data.animations);
      setActiveTab('editor');
    } catch (err: any) {
      setErrorBanner(err.message);
    }
  };

  const handleCreateProject = async (name: string, type: 'html' | 'python') => {
    try {
      const created = await API.createProject(name, type);
      await refreshProjects();
      await handleSelectProject(created);
    } catch (err: any) {
      setErrorBanner(err.message);
    }
  };

  const handleRenameProject = async (id: string, newName: string) => {
    try {
      const updated = await API.renameProject(id, newName);
      if (selectedProject?.id === id) {
        setSelectedProject(updated);
      }
      await refreshProjects();
    } catch (err: any) {
      setErrorBanner(err.message);
    }
  };

  const handleDuplicateProject = async (id: string) => {
    try {
      await API.duplicateProject(id);
      await refreshProjects();
    } catch (err: any) {
      setErrorBanner(err.message);
    }
  };

  const handleDeleteProject = async (id: string) => {
    try {
      await API.deleteProject(id);
      if (selectedProject?.id === id) {
        setSelectedProject(null);
        setCustomization(null);
        setAnimations(null);
        setActiveTab('dashboard');
      }
      await refreshProjects();
    } catch (err: any) {
      setErrorBanner(err.message);
    }
  };

  return (
    <MainLayout
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      selectedProjectName={selectedProject?.name}
    >
      {activeTab === 'dashboard' && (
        <Dashboard
          projects={projects}
          errorBanner={errorBanner}
          onSelectProject={handleSelectProject}
          onCreateProject={handleCreateProject}
          onRenameProject={handleRenameProject}
          onDuplicateProject={handleDuplicateProject}
          onDeleteProject={handleDeleteProject}
        />
      )}
      {activeTab === 'editor' && selectedProject && (
        <ProjectEditor project={selectedProject} />
      )}
      {activeTab === 'customization' && selectedProject && customization && (
        <CustomizationStudio
          projectId={selectedProject.id}
          initialSettings={customization}
          onUpdated={(updated) => {
            setCustomization(updated);
            refreshProjects();
          }}
        />
      )}
      {activeTab === 'animations' && selectedProject && animations && (
        <AnimationStudio
          projectId={selectedProject.id}
          initialAnimations={animations}
          onUpdated={(updated) => setAnimations(updated)}
        />
      )}
      {activeTab === 'build' && selectedProject && (
        <BuildStudio projectId={selectedProject.id} />
      )}
    </MainLayout>
  );
};
