import fs from 'fs';
import path from 'path';
import { validateCustomizationClient } from '../src/utils/validation';
import { detectLanguageFromPath } from '../src/utils/syntaxHighlight';
import { LocalEngine, buildZipUint8Array } from '../src/services/localEngine';

describe('Frontend Validation, Production Bundle, Android Assets & On-Device Engine', () => {
  it('validates customization settings on the client side', () => {
    const validSettings: any = {
      app_name: 'My Store',
      package_id: 'com.apkstudio.mystore',
      version_name: '1.0.0',
      version_code: 1,
      orientation: 'portrait',
      fullscreen: false,
      status_bar_color: '#1f1c2c',
      nav_bar_color: '#1f1c2c',
      light_status_bar: false,
      permissions: ['android.permission.INTERNET']
    };
    expect(validateCustomizationClient(validSettings).length).toBe(0);

    const invalidSettings: any = {
      ...validSettings,
      package_id: 'badpackage',
      version_code: 0
    };
    expect(validateCustomizationClient(invalidSettings).length).toBe(2);
  });

  it('detects programming languages accurately from file extensions', () => {
    expect(detectLanguageFromPath('index.html')).toBe('HTML');
    expect(detectLanguageFromPath('css/style.css')).toBe('CSS');
    expect(detectLanguageFromPath('js/app.js')).toBe('JavaScript');
    expect(detectLanguageFromPath('main.py')).toBe('Python');
  });

  it('verifies frontend production build (dist/index.html, dist/assets/index.js, dist/assets/index.css)', () => {
    const distDir = path.resolve(__dirname, '../dist');
    const indexHtmlPath = path.join(distDir, 'index.html');
    const indexJsPath = path.join(distDir, 'assets', 'index.js');
    const indexCssPath = path.join(distDir, 'assets', 'index.css');

    expect(fs.existsSync(indexHtmlPath)).toBe(true);
    expect(fs.existsSync(indexJsPath)).toBe(true);
    expect(fs.existsSync(indexCssPath)).toBe(true);

    const html = fs.readFileSync(indexHtmlPath, 'utf-8');
    expect(html.includes('/src/main.tsx')).toBe(false);
    expect(html).toContain('./assets/index.css');
    expect(html).toContain('./assets/index.js');
  });

  it('verifies Android WebView assets contain the real production React interface instead of the demo page', () => {
    const androidWebappDir = path.resolve(
      __dirname,
      '../../build-engine/android-template/app/src/main/assets/webapp'
    );
    const androidIndexPath = path.join(androidWebappDir, 'index.html');
    const androidJsPath = path.join(androidWebappDir, 'assets', 'index.js');
    const androidCssPath = path.join(androidWebappDir, 'assets', 'index.css');

    expect(fs.existsSync(androidIndexPath)).toBe(true);
    expect(fs.existsSync(androidJsPath)).toBe(true);
    expect(fs.existsSync(androidCssPath)).toBe(true);

    const html = fs.readFileSync(androidIndexPath, 'utf-8');
    expect(html.includes('Welcome to APK STUDIO App')).toBe(false);
    expect(html).toContain('<div id="root"></div>');
    expect(html).toContain('./assets/index.js');

    const jsBundle = fs.readFileSync(androidJsPath, 'utf-8');
    expect(jsBundle).toContain('Workspace Projects');
    expect(jsBundle).toContain('Customization Studio');
    expect(jsBundle).toContain('Animation Studio');
    expect(jsBundle).toContain('Compilation Engine');
  });

  it('executes On-Device LocalEngine workflows (projects, files, live preview srcdoc, Python inspector, and ZIP builder)', () => {
    const p = LocalEngine.createProject('Mobile WebView App', 'html');
    expect(p.name).toBe('Mobile WebView App');

    LocalEngine.saveFile(p.id, 'style.css', 'body { background: #112233; }');
    const srcDoc = LocalEngine.compileLivePreviewSrcDoc(p.id);
    expect(srcDoc).toContain('background: #112233;');
    expect(srcDoc).toContain('apk-studio-preview');

    const zipBytes = buildZipUint8Array({
      'index.html': '<h1>Test</h1>',
      'style.css': 'body {}'
    });
    expect(zipBytes[0]).toBe(0x50);
    expect(zipBytes[1]).toBe(0x4b);
    expect(zipBytes[2]).toBe(0x03);
    expect(zipBytes[3]).toBe(0x04);
  });
});
