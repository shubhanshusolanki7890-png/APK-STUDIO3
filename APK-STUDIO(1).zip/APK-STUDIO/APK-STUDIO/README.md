# APK STUDIO — Web (HTML5/CSS/JS) & Python to Android APK Builder

APK STUDIO is a full-stack application for creating, customizing, previewing, and packaging supported HTML5/CSS/JavaScript and Python web-hybrid projects into Android applications, built around an Apple-inspired **Liquid Glass UI**.

## 1. Directory Structure

All generic `ai_studio_code (*)` files from the original archive have been audited, deduplicated, repaired, and organized into a clean, modular structure:

```text
APK-STUDIO/
├── README.md
├── .gitignore
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── package.json
├── shared/
│   └── types/
│       └── project.types.ts
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── index.html
│   ├── src/
│   │   ├── main.tsx
│   │   ├── app/
│   │   │   └── App.tsx
│   │   ├── layouts/
│   │   │   └── MainLayout.tsx
│   │   ├── components/
│   │   │   ├── GlassButton.tsx
│   │   │   ├── GlassModal.tsx
│   │   │   └── StatusBadge.tsx
│   │   ├── pages/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── ProjectEditor.tsx
│   │   │   ├── CustomizationStudio.tsx
│   │   │   ├── AnimationStudio.tsx
│   │   │   └── BuildStudio.tsx
│   │   ├── features/
│   │   │   ├── editor/
│   │   │   │   ├── FileTreeView.tsx
│   │   │   │   └── LivePreviewPane.tsx
│   │   │   └── python/
│   │   │       └── PythonInspectorPanel.tsx
│   │   ├── hooks/
│   │   │   └── useUnsavedChanges.ts
│   │   ├── services/
│   │   │   └── api.ts
│   │   ├── utils/
│   │   │   ├── validation.ts
│   │   │   └── syntaxHighlight.ts
│   │   ├── styles/
│   │   │   └── index.css
│   │   └── types/
│   │       └── index.ts
│   └── tests/
│       └── validation.test.ts
├── backend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── src/
│   │   ├── config.ts
│   │   ├── app.ts
│   │   ├── server.ts
│   │   ├── routes/
│   │   │   ├── projects.routes.ts
│   │   │   ├── files.routes.ts
│   │   │   ├── builds.routes.ts
│   │   │   └── system.routes.ts
│   │   ├── controllers/
│   │   │   ├── projects.controller.ts
│   │   │   ├── files.controller.ts
│   │   │   ├── builds.controller.ts
│   │   │   └── system.controller.ts
│   │   ├── services/
│   │   │   ├── storage.service.ts
│   │   │   ├── archive.service.ts
│   │   │   ├── python.service.ts
│   │   │   └── build.service.ts
│   │   ├── middleware/
│   │   │   ├── errorHandler.ts
│   │   │   └── uploadLimits.ts
│   │   ├── database/
│   │   │   ├── db.ts
│   │   │   └── schema.sql
│   │   ├── validators/
│   │   │   └── project.validator.ts
│   │   └── utils/
│   │       ├── apkVerifier.ts
│   │       ├── fsUtils.ts
│   │       ├── httpFramework.ts
│   │       └── xmlEscape.ts
│   └── tests/
│       ├── archive.test.ts
│       ├── python.test.ts
│       ├── projects.test.ts
│       ├── customization.test.ts
│       └── build.test.ts
├── build-engine/
│   ├── android-template/
│   │   ├── build.gradle
│   │   ├── settings.gradle
│   │   ├── gradle.properties
│   │   ├── gradlew
│   │   ├── gradlew.bat
│   │   ├── gradle/wrapper/gradle-wrapper.properties
│   │   └── app/
│   │       ├── build.gradle
│   │       ├── proguard-rules.pro
│   │       └── src/main/
│   │           ├── AndroidManifest.xml
│   │           ├── java/com/apkstudio/app/MainActivity.java
│   │           └── res/
│   │               ├── drawable/ic_launcher_foreground.xml
│   │               ├── mipmap-anydpi-v26/ic_launcher.xml
│   │               └── values/{strings.xml,styles.xml,colors.xml}
│   ├── templates/
│   │   ├── html-starter/{index.html,style.css,script.js}
│   │   └── python-starter/{main.py,requirements.txt,index.html}
│   ├── scripts/
│   │   └── check-android-env.sh
│   └── services/
│       └── apkVerifier.ts
├── python-support/
│   ├── project_analyzer.py
│   └── webview_bridge_generator.py
├── docs/
│   ├── AUDIT_REPORT.md
│   ├── ARCHITECTURE.md
│   └── ANDROID_BUILD_SETUP.md
└── scripts/
    ├── setup.sh
    ├── start-backend.sh
    ├── start-frontend.sh
    ├── run-tests.sh
    ├── docker-up.sh
    ├── compile-ts.cjs
    └── run-tests.cjs
```

## 2. Requirements & Environment Setup

### Prerequisites
- **Node.js**: v18.0+ (v20 LTS recommended)
- **Python 3**: v3.9+ (used for SQLite persistence fallback, safe ZIP validation, and Python AST project inspection)
- **For Native Android APK Compilation**:
  - **OpenJDK 17** (`java` and `javac`)
  - **Android SDK** (`ANDROID_HOME` with `platforms;android-34`, `build-tools;34.0.0`, and `platform-tools`)
  - **Gradle 8.5+**

### Quick Start (Local Development)

1. Copy `.env.example` to `.env` and adjust paths if needed:
   ```bash
   cp .env.example .env
   ```
2. Install dependencies (when online):
   ```bash
   npm run setup
   ```
3. Compile TypeScript & JSX bundles:
   ```bash
   npm run build
   ```
4. Run the automated test suite:
   ```bash
   npm test
   ```
5. Check Android SDK / JDK toolchain readiness:
   ```bash
   npm run check:android
   ```
6. Start the server:
   ```bash
   npm start
   ```
   Or run the Vite dev server and backend in development mode:
   ```bash
   npm run dev:backend
   npm run dev:frontend
   ```

### Full Native Android Build via Docker

A complete `Dockerfile` and `docker-compose.yml` are included that automatically install **OpenJDK 17**, **Android SDK Platform 34**, **Build-Tools 34.0.0**, **Gradle 8.5**, **Python 3**, and **Node.js 20**:

```bash
docker-compose up --build
```

## 3. Generating and Downloading a Real APK

1. **Create or Open a Project** in the **Dashboard** (`HTML5 / CSS / JS` or `Python Bridge`).
2. **Import or Edit Code** in **Code & Files**:
   - Edit `index.html`, `style.css`, `script.js`, or `main.py` directly, or upload an individual HTML/asset file or a complete website `.zip` archive.
   - For Python projects, use the **Python Packaging Diagnostics** bar to inspect compatibility and click **Generate / Refresh HTML Bridge** if `index.html` is needed.
3. **Configure App Identity & Permissions** in **Customization**:
   - Set Application Name, Android Package ID (`com.company.app`), Version Name, Version Code, custom PNG Icon, Splash Screen settings, Orientation, Fullscreen, System Bar colors, Offline Cache behavior, and Android Manifest permissions.
4. **Configure Transitions & Effects** in **Animations**:
   - Choose a preset or customize splash animations, page transitions, button micro-interactions, pulse timing, and frosted glass blur. Click **Save & Apply Animation Configuration**.
5. **Compile or Export in Build Engine**:
   - Select **Debug APK** or **Release APK** and click **Compile Android APK**.
   - The pipeline validates your project, prepares the isolated Android Gradle project in `data/builds/<buildId>`, injects all manifest/resource/Java settings, bundles web assets, verifies the host Android toolchain, runs `./gradlew assembleDebug` (or `assembleRelease`), and verifies the output APK binary (`PK\x03\x04` signature, `AndroidManifest.xml`, and size > 1 KB).
   - Once verified, click **Download Verified APK**.
   - You can also click **Export Android Gradle Project (.zip)** on any build record to download the complete, pre-configured Android Studio project and compile it on another workstation.

## 4. Completed vs. Unsupported Features

### Completed Features
- Complete reorganization and renaming of all 55 files from generic `ai_studio_code (*)` names into a clean monorepo architecture.
- Full preservation and responsive mobile extension of the original Apple-inspired **Liquid Glass UI**.
- **Project Management**: Create, open, rename, duplicate (including deep file copy), and delete projects with persistent SQLite storage and Liquid Glass confirmation modals.
- **Import & Multi-file Code Editor**: Individual file imports, safe ZIP archive extraction (with Zip-Slip path traversal protection, symlink blocking, executable filtering, and single-root folder flattening), recursive folder tree navigation, file creation/deletion, syntax highlighting accents, and unsaved changes warnings.
- **Live Preview**: Responsive device frame presets (Compact, Android, Tablet), orientation rotation, live refresh, sandbox limitation documentation, and real-time **Preview Console** capturing `console.log`, `console.warn`, `console.error`, and uncaught runtime exceptions from the preview iframe.
- **App Customization Studio**: Working controls and strict validation for App Name, Package ID, Version Name/Code, custom PNG App Icon upload, Splash Screen, Orientation, Fullscreen, Keep Screen On, Pinch Zoom, Status/Nav Bar/Theme/Background colors, Offline Cache modes, and whitelisted Android permissions.
- **Animation Studio**: Working controls and presets for splash transitions, page transitions, button effects, pulse duration, and glass blur, persisted in SQLite and injected into both `MainActivity.java` and `apk_studio_animations.css`.
- **Real Android Build Pipeline & APK Verifier**: 7-stage pipeline with repaired `MainActivity.java`, adaptive/custom icons, Gradle wrapper scripts, host toolchain diagnostics, binary APK verification, and prepared Android Studio project `.zip` export.
- **Python Project Support**: 3-tier AST & `requirements.txt` classifier (`supported`, `requires_modification`, `unsupported`) and automatic HTML5 WebView bridge generator.

### Incomplete / Unsupported Features & Environment Limitations
- **Desktop-Only Python GUI Frameworks**: Python scripts that rely on desktop windowing systems (`tkinter`, `turtle`, `PyQt5/6`, `PySide2/6`, `wxPython`, `curses`, or `win32api`) cannot render inside an Android WebView and are flagged as `unsupported` by the analyzer.
- **Heavy Native C/Fortran Python Extensions without Prebuilt Android Wheels**: Packages requiring custom native compilation without Android ABI wheels must be built with Chaquopy or Pyodide wheels in Android Studio.
- **Host Environment Android SDK Requirement**: Native `.apk` binary compilation requires `javac` (JDK 17+), `ANDROID_HOME` (Android SDK Platform 34 & Build-Tools 34.0.0), and `gradle`. When running on a host or container where the Android SDK or `javac` is not installed, APK STUDIO completes Stages 1–4 (producing the complete, valid Android Studio Gradle project which can be downloaded via **Export Android Gradle Project (.zip)**) and accurately reports the missing SDK components at Stage 5 without faking build success.

## 5. Backend Deployment & API URL for Real APK Generation

APK STUDIO supports two operating modes (`frontend/src/services/api.ts`):

1. **Standalone On-Device Mode (`file:///android_asset/webapp/index.html`)**:
   - When running inside the installed Android APK without a configured backend server, the app uses its embedded **On-Device LocalEngine** (`localStorage` + binary ZIP extractor/builder + Python AST inspector + `srcdoc` live preview).
   - Because Android phones cannot run the 15 GB desktop Android SDK and Gradle daemon locally inside a WebView, standalone mode exports a complete, ready-to-compile **Android Studio Gradle Project (`.zip`)** (including `.github/workflows/build-apk.yml`).
2. **Remote Build Backend Mode (Required for Direct In-App `.apk` Compilation)**:
   - To compile uploaded HTML5 or Python projects directly into `.apk` binaries from inside the mobile app, deploy the included backend (`Dockerfile` / `docker-compose.yml`) on a workstation, local Wi-Fi host, or cloud container server (4 GB+ RAM recommended for Gradle):
     ```bash
     docker-compose up -d --build
     ```
   - Open the **APK STUDIO** app, tap **Engine Config** (`Settings`) in the top header bar, and enter your backend base URL (e.g. `http://192.168.1.50:4000` on LAN or `https://your-apk-studio-server.example.com`).
   - The frontend automatically routes requests to `<YOUR_URL>/api` (`GET /api/system/diagnostics`, `POST /api/projects`, `POST /api/projects/:projectId/builds`, `GET /api/builds/:buildId`, and `GET /api/builds/:buildId/download`). See `docs/BACKEND_DEPLOYMENT.md` for full deployment instructions.
